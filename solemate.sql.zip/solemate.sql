-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2024 at 10:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `solemate`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin-user`
--

CREATE TABLE `admin-user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(80) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin-user`
--

INSERT INTO `admin-user` (`user_id`, `user_name`, `password`, `created_at`, `modified_at`) VALUES
(5, 'anisha', '$2y$10$pvL86RUOaZSjJvEAk4p8lOsmFUOgxDOUWjRNrrhYrou4aDlXanFNq', '2024-10-29 10:47:47', '2024-10-29 10:47:47');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `brand_name`) VALUES
(101, 'NIKE'),
(102, 'PUMA'),
(103, 'Crocs'),
(104, 'ADIDAS'),
(105, 'CONVERSE'),
(106, 'NEW BALANCE'),
(107, 'Reebok');

-- --------------------------------------------------------

--
-- Table structure for table `cart_item`
--

CREATE TABLE `cart_item` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) DEFAULT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_phone_number` varchar(20) NOT NULL,
  `status` varchar(30) NOT NULL,
  `delivery_date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `total_amount`, `user_address`, `user_phone_number`, `status`, `delivery_date`) VALUES
(1, 12, '2024-12-04 12:33:08', 15995.00, 'pehani', '9388912712', 'Delivered', ''),
(2, 12, '2024-12-04 12:53:36', 15995.00, 'pehani', '8390123801', '', ''),
(4, 12, '2024-12-10 17:19:50', 11895.00, 'Manpur patwatoli near semraj ram park', '9523003682', 'Shipped', ''),
(5, 12, '2024-12-10 18:10:34', 22894.00, 'Manpur patwatoli near semraj ram park', '9523003682', '', ''),
(6, 12, '2024-12-10 18:10:53', 15995.00, 'Manpur patwatoli near semraj ram park', '9523003682', '', ''),
(7, 12, '2024-12-11 13:12:54', 10999.00, 'Manpur patwatoli near semraj ram park', '9523003682', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `created_at`, `modified_at`, `price`) VALUES
(1, 1, 102, 1, '2024-12-04 12:33:08', '2024-12-04 12:33:08', 15995),
(2, 2, 102, 1, '2024-12-04 12:53:36', '2024-12-04 12:53:36', 15995),
(6, 4, 101, 1, '2024-12-10 17:19:50', '2024-12-10 17:19:50', 11895),
(7, 5, 101, 1, '2024-12-10 18:10:34', '2024-12-10 18:10:34', 11895),
(8, 5, 202, 1, '2024-12-10 18:10:34', '2024-12-10 18:10:34', 10999),
(9, 6, 102, 1, '2024-12-10 18:10:53', '2024-12-10 18:10:53', 15995),
(10, 7, 202, 1, '2024-12-11 13:12:54', '2024-12-11 13:12:54', 10999);

-- --------------------------------------------------------

--
-- Table structure for table `payment-details`
--

CREATE TABLE `payment-details` (
  `id` int(11) NOT NULL,
  `order-id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `provider` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `created-at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified-at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'Pending',
  `payment_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `user_id`, `order_id`, `payment_method`, `total_amount`, `transaction_id`, `payment_status`, `payment_date`) VALUES
(1, 12, 77, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:24:37'),
(2, 12, 77, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:24:37'),
(3, 12, 78, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:29:47'),
(4, 12, 78, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:29:47'),
(5, 12, 79, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:34:33'),
(6, 12, 80, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:34:36'),
(7, 12, 81, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:34:38'),
(8, 12, 82, 'COD', 27890.00, NULL, 'Pending', '2024-12-03 16:35:33'),
(9, 12, 83, 'COD', 11895.00, NULL, 'Pending', '2024-12-03 16:36:13'),
(10, 12, 1, 'COD', 15995.00, NULL, 'Pending', '2024-12-03 16:50:54'),
(11, 12, 2, 'COD', 15995.00, NULL, 'Pending', '2024-12-03 17:11:26'),
(12, 12, 4, 'COD', 15995.00, NULL, 'Pending', '2024-12-03 17:35:00'),
(13, 12, 6, 'COD', 10999.00, NULL, 'Pending', '2024-12-03 18:04:51'),
(14, 12, 2, 'COD', 48985.00, NULL, 'Pending', '2024-12-03 18:06:51'),
(15, 12, 5, 'COD', 10999.00, NULL, 'Pending', '2024-12-03 18:21:48'),
(18, 12, 6, 'COD', 11895.00, NULL, 'Pending', '2024-12-04 16:35:57'),
(19, 12, 7, 'COD', 11895.00, NULL, 'Pending', '2024-12-04 16:36:16'),
(20, 12, 8, 'COD', 11895.00, NULL, 'Pending', '2024-12-04 16:36:40'),
(21, 12, 9, 'COD', 11895.00, NULL, 'Pending', '2024-12-04 16:37:35'),
(24, 12, 1, 'COD', 15995.00, NULL, 'Pending', '2024-12-04 18:03:08'),
(25, 12, 2, 'COD', 15995.00, NULL, 'Pending', '2024-12-04 18:23:36'),
(27, 12, 4, 'COD', 11895.00, NULL, 'Pending', '2024-12-10 22:49:50'),
(28, 12, 5, 'COD', 22894.00, NULL, 'Pending', '2024-12-10 23:40:34'),
(29, 12, 6, 'COD', 15995.00, NULL, 'Pending', '2024-12-10 23:40:53'),
(30, 12, 7, 'COD', 10999.00, NULL, 'Pending', '2024-12-11 18:42:54');

-- --------------------------------------------------------

--
-- Table structure for table `product category`
--

CREATE TABLE `product category` (
  `id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL,
  `created at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified  at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product category`
--

INSERT INTO `product category` (`id`, `name`, `created at`, `modified  at`) VALUES
(6, 'men', '2024-10-15 03:45:54', '2024-10-15 03:36:02'),
(7, 'unisex', '2024-10-18 04:28:19', '2024-10-18 04:28:19'),
(9, 'women', '2024-10-15 03:46:05', '2024-10-15 03:36:02');

-- --------------------------------------------------------

--
-- Table structure for table `productimages`
--

CREATE TABLE `productimages` (
  `image_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) NOT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productimages`
--

INSERT INTO `productimages` (`image_id`, `product_id`, `image_url`, `alt_text`, `created_at`) VALUES
(2, 601, 'uploads/66f2b084425c3-BB550 2(1).webp', 'BB550 2(1).webp', '2024-09-24 12:28:52'),
(3, 601, 'uploads/66f2b09632604-BB550 2(2).webp', 'BB550 2(2).webp', '2024-09-24 12:29:10'),
(4, 601, 'uploads/66f2b0a86eb0b-BB550  3(3).webp', 'BB550  3(3).webp', '2024-09-24 12:29:28'),
(5, 601, 'uploads/66f2b0b58c66a-BB550 2(4).webp', 'BB550 2(4).webp', '2024-09-24 12:29:41'),
(6, 602, 'uploads/66f2b0f499484-327.webp', '327.webp', '2024-09-24 12:30:44'),
(7, 602, 'uploads/66f2b101a13fa-327(2).webp', '327(2).webp', '2024-09-24 12:30:57'),
(8, 602, 'uploads/66f2b1105ea6c-327(3).webp', '327(3).webp', '2024-09-24 12:31:12'),
(9, 602, 'uploads/66f2b1196ff12-327(4).webp', '327(4).webp', '2024-09-24 12:31:21'),
(10, 603, 'uploads/66f2b18065d95-WMNS 327(1).webp', 'WMNS 327(1).webp', '2024-09-24 12:33:04'),
(11, 603, 'uploads/66f2b1934ab28-WMNS 327(2).webp', 'WMNS 327(2).webp', '2024-09-24 12:33:23'),
(12, 604, 'uploads/66f2b277652a4-530(1).webp', '530(1).webp', '2024-09-24 12:37:11'),
(13, 604, 'uploads/66f2b28052db9-530(2).webp', '530(2).webp', '2024-09-24 12:37:20'),
(14, 604, 'uploads/66f2b288e1ec6-530(3).webp', '530(3).webp', '2024-09-24 12:37:28'),
(15, 604, 'uploads/66f2b29448ec5-530(4).webp', '530(4).webp', '2024-09-24 12:37:40'),
(16, 605, 'uploads/66f2b2f25fbdd-WMNS(1).webp', 'WMNS(1).webp', '2024-09-24 12:39:14'),
(17, 605, 'uploads/66f2b3083e18a-WMNS 574(2).webp', 'WMNS 574(2).webp', '2024-09-24 12:39:36'),
(18, 605, 'uploads/66f2b3224971f-WMNS 574(3).webp', 'WMNS 574(3).webp', '2024-09-24 12:40:02'),
(19, 605, 'uploads/66f2b3b92fa60-WMNS 327(4).webp', 'WMNS 327(4).webp', '2024-09-24 12:42:33'),
(20, 606, 'uploads/66f2b3e748406-574(1) - Copy.webp', '574(1) - Copy.webp', '2024-09-24 12:43:19'),
(21, 606, 'uploads/66f2b3f716e67-574(2) - Copy.webp', '574(2) - Copy.webp', '2024-09-24 12:43:35'),
(22, 606, 'uploads/66f2b404a1f63-574(3).webp', '574(3).webp', '2024-09-24 12:43:48'),
(23, 606, 'uploads/66f2b42d17a54-574(4).webp', '574(4).webp', '2024-09-24 12:44:29'),
(24, 608, 'uploads/66f2b44e09a00-574 LEGACY(1).webp', '574 LEGACY(1).webp', '2024-09-24 12:45:02'),
(25, 608, 'uploads/66f2b45b0885b-574 LEGACY(2).webp', '574 LEGACY(2).webp', '2024-09-24 12:45:15'),
(26, 608, 'uploads/66f2b4c55c27c-574 LEGACY(3).webp', '574 LEGACY(3).webp', '2024-09-24 12:47:01'),
(27, 608, 'uploads/66f2b4d6c682e-574 LEGACY(4).webp', '574 LEGACY(4).webp', '2024-09-24 12:47:18'),
(29, 609, 'uploads/66f2b55e54e0d-WMN\'S BB550(1).webp', 'WMN\'S BB550(1).webp', '2024-09-24 12:49:34'),
(30, 609, 'uploads/66f2b56b76231-WMN\'S BB550(2).webp', 'WMN\'S BB550(2).webp', '2024-09-24 12:49:47'),
(31, 609, 'uploads/66f2b58cbb3ed-WMNS BB5500(4).webp', 'WMNS BB5500(4).webp', '2024-09-24 12:50:20'),
(32, 610, 'uploads/66f2b67187396-BB550 2(2).webp', 'BB550 2(2).webp', '2024-09-24 12:54:09'),
(33, 610, 'uploads/66f2b68419997-BB550  3(3).webp', 'BB550  3(3).webp', '2024-09-24 12:54:28'),
(34, 610, 'uploads/66f2b690c6497-BB550 2(4).webp', 'BB550 2(4).webp', '2024-09-24 12:54:40'),
(35, 610, 'uploads/66f2b6d6cc91f-BB550 2(1).webp', 'BB550 2(1).webp', '2024-09-24 12:55:50'),
(36, 611, 'uploads/66f2b72e93ea2-997R(1).webp', '997R(1).webp', '2024-09-24 12:57:18'),
(37, 611, 'uploads/66f2b73cdb5af-997R(2).webp', '997R(2).webp', '2024-09-24 12:57:32'),
(38, 611, 'uploads/66f2b74ab0ecb-997R(3).webp', '997R(3).webp', '2024-09-24 12:57:46'),
(39, 611, 'uploads/66f2b758ae66a-9977R(4).webp', '9977R(4).webp', '2024-09-24 12:58:00'),
(40, 101, 'uploads/66f2b881c3635-LUKA 3 PF MOTORSPORT(1).webp', 'LUKA 3 PF MOTORSPORT(1).webp', '2024-09-24 13:02:57'),
(41, 101, 'uploads/66f2b8ba69185-LUKA 3 PF MOTORSPORT(3).webp', 'LUKA 3 PF MOTORSPORT(3).webp', '2024-09-24 13:03:54'),
(42, 101, 'uploads/66f2b8c8da08a-LUKA 3 PF MOTORSPORT(4).webp', 'LUKA 3 PF MOTORSPORT(4).webp', '2024-09-24 13:04:08'),
(43, 102, 'uploads/66f2b8f4f1e07-AIR JORDAN 1 LOW 85(1) - Copy.webp', 'AIR JORDAN 1 LOW 85(1) - Copy.webp', '2024-09-24 13:04:52'),
(44, 102, 'uploads/66f2b90086f43-AIR JORDAN 1 LOW 85(2).webp', 'AIR JORDAN 1 LOW 85(2).webp', '2024-09-24 13:05:04'),
(45, 102, 'uploads/66f2b914a718d-AIR JORDAN 1 LOW 85(3).webp', 'AIR JORDAN 1 LOW 85(3).webp', '2024-09-24 13:05:24'),
(46, 102, 'uploads/66f2b91e7dfd8-AIR JORDAN 1 LOW 85(4).webp', 'AIR JORDAN 1 LOW 85(4).webp', '2024-09-24 13:05:34'),
(47, 103, 'uploads/66f2b946e8cf2-INTIATOR(1).webp', 'INTIATOR(1).webp', '2024-09-24 13:06:14'),
(48, 103, 'uploads/66f2b969af370-AIR JORDAN 1 LOW 85(2).webp', 'AIR JORDAN 1 LOW 85(2).webp', '2024-09-24 13:06:49'),
(49, 103, 'uploads/66f2b9865632c-INTIATOR(3).webp', 'INTIATOR(3).webp', '2024-09-24 13:07:18'),
(50, 103, 'uploads/66f2b99e55127-INTIATOR(4).webp', 'INTIATOR(4).webp', '2024-09-24 13:07:42'),
(51, 104, 'uploads/66f2b9d14e12d-FULL FORCE LOW(1).webp', 'FULL FORCE LOW(1).webp', '2024-09-24 13:08:33'),
(52, 104, 'uploads/66f2b9e3e14b6-FULL FORCE LOW(2).webp', 'FULL FORCE LOW(2).webp', '2024-09-24 13:08:51'),
(53, 104, 'uploads/66f2b9f196dca-FULL FORCE LOW(3).webp', 'FULL FORCE LOW(3).webp', '2024-09-24 13:09:05'),
(54, 104, 'uploads/66f2ba024f3d3-FULL FORCE LOW(4).webp', 'FULL FORCE LOW(4).webp', '2024-09-24 13:09:22'),
(55, 105, 'uploads/66f2ba3b506b0-AIR JORDAN 4 RETRO GS(1).webp', 'AIR JORDAN 4 RETRO GS(1).webp', '2024-09-24 13:10:19'),
(56, 105, 'uploads/66f2ba491f1b7-AIR JORDAN 4 RETRO GS(2).webp', 'AIR JORDAN 4 RETRO GS(2).webp', '2024-09-24 13:10:33'),
(57, 105, 'uploads/66f2ba55049ee-AIR JORDAN 4 RETRO GS(3).webp', 'AIR JORDAN 4 RETRO GS(3).webp', '2024-09-24 13:10:45'),
(58, 105, 'uploads/66f2ba69885e3-AIR JORDAN 4 RETRO GS(4).webp', 'AIR JORDAN 4 RETRO GS(4).webp', '2024-09-24 13:11:05'),
(59, 106, 'uploads/66f2ba91220dc-WMNS DUNK LOW LX(1).webp', 'WMNS DUNK LOW LX(1).webp', '2024-09-24 13:11:45'),
(60, 106, 'uploads/66f2ba9ed29ac-WMNS DUNK LOW LX(2).webp', 'WMNS DUNK LOW LX(2).webp', '2024-09-24 13:11:58'),
(61, 106, 'uploads/66f2baacef676-WMNS DUNK LOW LX(3).webp', 'WMNS DUNK LOW LX(3).webp', '2024-09-24 13:12:12'),
(62, 106, 'uploads/66f2bab95532a-WMNS DUNK LOW LX(4).webp', 'WMNS DUNK LOW LX(4).webp', '2024-09-24 13:12:25'),
(63, 107, 'uploads/66f2bb5e33094-AIR JORDAN 1 LOW RETRO GS(1).webp', 'AIR JORDAN 1 LOW RETRO GS(1).webp', '2024-09-24 13:15:10'),
(64, 107, 'uploads/66f2bb6905a1a-AIR JORDAN 1 LOW RETRO GS(2).webp', 'AIR JORDAN 1 LOW RETRO GS(2).webp', '2024-09-24 13:15:21'),
(65, 107, 'uploads/66f2bb796b655-AIR JORDAN 1 LOW RETRO GS(3).webp', 'AIR JORDAN 1 LOW RETRO GS(3).webp', '2024-09-24 13:15:37'),
(66, 107, 'uploads/66f2bb8a8feea-AIR JORDAN 1 LOW RETRO GS(4).webp', 'AIR JORDAN 1 LOW RETRO GS(4).webp', '2024-09-24 13:15:54'),
(67, 108, 'uploads/66f2bbb3e374c-DUNK LOW RETRO PREMIUM(1).webp', 'DUNK LOW RETRO PREMIUM(1).webp', '2024-09-24 13:16:35'),
(68, 108, 'uploads/66f2bbc14f996-DUNK LOW RETRO PREMIUM(2).webp', 'DUNK LOW RETRO PREMIUM(2).webp', '2024-09-24 13:16:49'),
(69, 108, 'uploads/66f2bbcfcc784-DUNK LOW RETRO PREMIUM(3).webp', 'DUNK LOW RETRO PREMIUM(3).webp', '2024-09-24 13:17:03'),
(70, 108, 'uploads/66f2bbdd4a1cc-DUNK LOW RETRO PREMIUM(4).webp', 'DUNK LOW RETRO PREMIUM(4).webp', '2024-09-24 13:17:17'),
(71, 109, 'uploads/66f2bc1b7a4c4-WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(1).webp', 'WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(1).webp', '2024-09-24 13:18:19'),
(72, 109, 'uploads/66f2bc31cffaf-WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(2).webp', 'WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(2).webp', '2024-09-24 13:18:41'),
(73, 109, 'uploads/66f2bc3db698e-WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(3).webp', 'WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(3).webp', '2024-09-24 13:18:53'),
(74, 109, 'uploads/66f2bc4ade915-WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(4).webp', 'WMN\'S AIR JORDAN 1 RETRO HIGH OG FIRST FLIGHT(4).webp', '2024-09-24 13:19:06'),
(75, 110, 'uploads/66f2bc8a9d4e0-NIKE AIRFORCE 1 HIGH \'07(1).jpg', 'NIKE AIRFORCE 1 HIGH \'07(1).jpg', '2024-09-24 13:20:10'),
(76, 110, 'uploads/66f2bc9a61ca7-NIKE AIRFORCE 1 HIGH \'07(2).jpg', 'NIKE AIRFORCE 1 HIGH \'07(2).jpg', '2024-09-24 13:20:26'),
(77, 110, 'uploads/66f2bca703022-NIKE AIRFORCE 1 HIGH \'07(3).jpg', 'NIKE AIRFORCE 1 HIGH \'07(3).jpg', '2024-09-24 13:20:39'),
(78, 110, 'uploads/66f2bcb4d15d3-NIKE AIRFORCE 1 HIGH \'07(4).jpg', 'NIKE AIRFORCE 1 HIGH \'07(4).jpg', '2024-09-24 13:20:52'),
(79, 111, 'uploads/66f2bcdaee12b-AIR FORCE 1 \'07 LV8(1).webp', 'AIR FORCE 1 \'07 LV8(1).webp', '2024-09-24 13:21:30'),
(80, 111, 'uploads/66f2bce487ff1-AIR FORCE 1 \'07 LV8(2).webp', 'AIR FORCE 1 \'07 LV8(2).webp', '2024-09-24 13:21:40'),
(81, 111, 'uploads/66f2bced9021b-AIR FORCE 1 \'07 LV8(3).webp', 'AIR FORCE 1 \'07 LV8(3).webp', '2024-09-24 13:21:49'),
(82, 111, 'uploads/66f2bcf759584-AIR FORCE 1 \'07 LV8(4).webp', 'AIR FORCE 1 \'07 LV8(4).webp', '2024-09-24 13:21:59'),
(83, 201, 'uploads/66f2bf3fbf73f-SHOE1XPUMA.jpg', 'SHOE1XPUMA.jpg', '2024-09-24 13:31:43'),
(84, 201, 'uploads/66f2bf63e467a-SHOE1PIC1XPUMA.jpg', 'SHOE1PIC1XPUMA.jpg', '2024-09-24 13:32:19'),
(85, 201, 'uploads/66f2bf6d6a992-SHOE1PIC2XPUMA.jpg', 'SHOE1PIC2XPUMA.jpg', '2024-09-24 13:32:29'),
(86, 201, 'uploads/66f2bf76ca020-SHOE1PIC3XPUMA.jpg', 'SHOE1PIC3XPUMA.jpg', '2024-09-24 13:32:38'),
(87, 202, 'uploads/66f2c019235d5-SHOE2XPUMA.jpg', 'SHOE2XPUMA.jpg', '2024-09-24 13:35:21'),
(88, 202, 'uploads/66f2c0221ba02-SHOE2PIC3XPUMA.jpg', 'SHOE2PIC3XPUMA.jpg', '2024-09-24 13:35:30'),
(89, 202, 'uploads/66f2c02a689ad-SHOE2PIC2XPUMA.jpg', 'SHOE2PIC2XPUMA.jpg', '2024-09-24 13:35:38'),
(90, 202, 'uploads/66f2c032a7c9e-SHOE2PIC1XPUMA.jpg', 'SHOE2PIC1XPUMA.jpg', '2024-09-24 13:35:46'),
(91, 203, 'uploads/66f2c0c43d2ad-SHOE3XPUMA.jpg', 'SHOE3XPUMA.jpg', '2024-09-24 13:38:12'),
(92, 203, 'uploads/66f2c0cf8f7b6-SHOE3PIC3XPUMA.jpg', 'SHOE3PIC3XPUMA.jpg', '2024-09-24 13:38:23'),
(93, 203, 'uploads/66f2c0daac915-SHOE3PIC2XPUMA.jpg', 'SHOE3PIC2XPUMA.jpg', '2024-09-24 13:38:34'),
(94, 203, 'uploads/66f2c0e95a178-SHOE3PIC1XPUMA.jpg', 'SHOE3PIC1XPUMA.jpg', '2024-09-24 13:38:49'),
(95, 204, 'uploads/66f2c128d50be-SHOE4XPUMA.jpg', 'SHOE4XPUMA.jpg', '2024-09-24 13:39:52'),
(96, 204, 'uploads/66f2c1393ab79-SHOE4PIC3XPUMA.jpg', 'SHOE4PIC3XPUMA.jpg', '2024-09-24 13:40:09'),
(97, 204, 'uploads/66f2c14655878-SHOE4PIC2XPUMA.jpg', 'SHOE4PIC2XPUMA.jpg', '2024-09-24 13:40:22'),
(98, 204, 'uploads/66f2c15290cd1-SHOE4PIC1XPUMA.jpg', 'SHOE4PIC1XPUMA.jpg', '2024-09-24 13:40:34'),
(99, 205, 'uploads/66f2c1869ae69-SHOE5XPUMA.jpg', 'SHOE5XPUMA.jpg', '2024-09-24 13:41:26'),
(100, 205, 'uploads/66f2c19624c7f-SHOE5PIC3XPUMA.jpg', 'SHOE5PIC3XPUMA.jpg', '2024-09-24 13:41:42'),
(101, 205, 'uploads/66f2c1a1c05a7-SHOE5PIC2XPUMA.jpg', 'SHOE5PIC2XPUMA.jpg', '2024-09-24 13:41:53'),
(102, 205, 'uploads/66f2c1ac3c94c-SHOE5PIC1XPUMA.jpg', 'SHOE5PIC1XPUMA.jpg', '2024-09-24 13:42:04'),
(103, 206, 'uploads/66f2c1d600161-SHOE6XPUMA.jpg', 'SHOE6XPUMA.jpg', '2024-09-24 13:42:46'),
(104, 206, 'uploads/66f2c1e5b6a69-SHOE6PIC3XPUMA.jpg', 'SHOE6PIC3XPUMA.jpg', '2024-09-24 13:43:01'),
(105, 206, 'uploads/66f2c1f8d6061-SHOE6PIC2XPUMA.jpg', 'SHOE6PIC2XPUMA.jpg', '2024-09-24 13:43:20'),
(106, 206, 'uploads/66f2c205deecb-SHOE6PIC1XPUMA.jpg', 'SHOE6PIC1XPUMA.jpg', '2024-09-24 13:43:33'),
(107, 207, 'uploads/66f2c4064a73f-SHOE7XPUMA.jpg', 'SHOE7XPUMA.jpg', '2024-09-24 13:52:06'),
(108, 207, 'uploads/66f2c419a5a10-SHOE7PIC3XPUMA.jpg', 'SHOE7PIC3XPUMA.jpg', '2024-09-24 13:52:25'),
(109, 207, 'uploads/66f2c4274ebb7-SHOE7PIC2XPUMA.jpg', 'SHOE7PIC2XPUMA.jpg', '2024-09-24 13:52:39'),
(110, 207, 'uploads/66f2c433887db-SHOE7PIC1XPUMA.jpg', 'SHOE7PIC1XPUMA.jpg', '2024-09-24 13:52:51'),
(111, 208, 'uploads/66f2c47426979-SHOE8XPUMA.jpg', 'SHOE8XPUMA.jpg', '2024-09-24 13:53:56'),
(112, 208, 'uploads/66f2c48bb08c0-SHOE8PIC3XPUMA.jpg', 'SHOE8PIC3XPUMA.jpg', '2024-09-24 13:54:19'),
(113, 208, 'uploads/66f2c4b0d785f-SHOE8PIC2XPUMA.jpg', 'SHOE8PIC2XPUMA.jpg', '2024-09-24 13:54:56'),
(114, 208, 'uploads/66f2c4c05f82e-SHOE8PIC1XPUMA.jpg', 'SHOE8PIC1XPUMA.jpg', '2024-09-24 13:55:12'),
(115, 209, 'uploads/66f2c4ce61d31-SHOE9XPUMA.jpg', 'SHOE9XPUMA.jpg', '2024-09-24 13:55:26'),
(116, 209, 'uploads/66f2c5031e7f8-SHOE9PIC3XPUMA.jpg', 'SHOE9PIC3XPUMA.jpg', '2024-09-24 13:56:19'),
(117, 209, 'uploads/66f2f5c7e6b13-SHOE1PIC2XPUMA.jpg', 'SHOE1PIC2XPUMA.jpg', '2024-09-24 17:24:23'),
(119, 209, 'uploads/66f2f65291c35-SHOE9PIC1XPUMA.jpg', 'SHOE9PIC1XPUMA.jpg', '2024-09-24 17:26:42'),
(120, 210, 'uploads/66f2f765c1401-SHOE10XPUMA.jpg', 'SHOE10XPUMA.jpg', '2024-09-24 17:31:17'),
(121, 210, 'uploads/66f2f793af58f-SHOE10PIC3XPUMA.jpg', 'SHOE10PIC3XPUMA.jpg', '2024-09-24 17:32:03'),
(122, 210, 'uploads/66f2f7f74f088-SHOE10PIC2XPUMA.jpg', 'SHOE10PIC2XPUMA.jpg', '2024-09-24 17:33:43'),
(123, 210, 'uploads/66f2f8017b91a-SHOE10PIC1XPUMA.jpg', 'SHOE10PIC1XPUMA.jpg', '2024-09-24 17:33:53'),
(124, 211, 'uploads/66f2f817730db-SHOE11XPUMA.jpg', 'SHOE11XPUMA.jpg', '2024-09-24 17:34:15'),
(125, 211, 'uploads/66f2f8207ab9e-SHOE11PIC3XPUMA.jpg', 'SHOE11PIC3XPUMA.jpg', '2024-09-24 17:34:24'),
(126, 211, 'uploads/66f2f829ea569-SHOE11PIC2XPUMA.jpg', 'SHOE11PIC2XPUMA.jpg', '2024-09-24 17:34:33'),
(127, 211, 'uploads/66f2f831e5d3e-SHOE11PIC1XPUMA.jpg', 'SHOE11PIC1XPUMA.jpg', '2024-09-24 17:34:41'),
(128, 401, 'uploads/66f2f8d07ff3b-SAMBA OG(1).webp', 'SAMBA OG(1).webp', '2024-09-24 17:37:20'),
(129, 401, 'uploads/66f2f8e98139f-SAMBA OG(2).webp', 'SAMBA OG(2).webp', '2024-09-24 17:37:45'),
(130, 401, 'uploads/66f2f8f58c842-SAMBA OG(3).webp', 'SAMBA OG(3).webp', '2024-09-24 17:37:57'),
(131, 401, 'uploads/66f2f8ff2f3c0-SAMBA OG(4).webp', 'SAMBA OG(4).webp', '2024-09-24 17:38:07'),
(132, 402, 'uploads/66f2f951eaf2b-WMNS CAMPUS 00S(1).webp', 'WMNS CAMPUS 00S(1).webp', '2024-09-24 17:39:29'),
(133, 402, 'uploads/66f2f95af336b-WMNS CAMPUS 00S(2).webp', 'WMNS CAMPUS 00S(2).webp', '2024-09-24 17:39:38'),
(134, 402, 'uploads/66f2f964e2cef-WMNS CAMPUS 00S(3).webp', 'WMNS CAMPUS 00S(3).webp', '2024-09-24 17:39:48'),
(135, 402, 'uploads/66f2f9708f2e1-WMNS CAMPUS 00S(4).webp', 'WMNS CAMPUS 00S(4).webp', '2024-09-24 17:40:00'),
(136, 403, 'uploads/66f2f99de4adb-CRAZY 1(1).webp', 'CRAZY 1(1).webp', '2024-09-24 17:40:45'),
(137, 403, 'uploads/66f2f9a7a8d6e-CRAZY 1(2).webp', 'CRAZY 1(2).webp', '2024-09-24 17:40:55'),
(138, 403, 'uploads/66f2f9b202391-CRAZY 1(3).webp', 'CRAZY 1(3).webp', '2024-09-24 17:41:06'),
(139, 403, 'uploads/66f2f9d1827eb-CRAZY 1(4).webp', 'CRAZY 1(4).webp', '2024-09-24 17:41:37'),
(140, 404, 'uploads/66f2fa00d8494-OZMILLEN(1).webp', 'OZMILLEN(1).webp', '2024-09-24 17:42:24'),
(141, 404, 'uploads/66f2fa2cd83b8-OZMILLEN(2).webp', 'OZMILLEN(2).webp', '2024-09-24 17:43:08'),
(142, 404, 'uploads/66f2fa37637b9-OZMILLEN(3).webp', 'OZMILLEN(3).webp', '2024-09-24 17:43:19'),
(143, 404, 'uploads/66f2fa41741ca-OZMILLEN(4).webp', 'OZMILLEN(4).webp', '2024-09-24 17:43:29'),
(144, 405, 'uploads/66f2fa5333555-KAIWA(1.webp', 'KAIWA(1.webp', '2024-09-24 17:43:47'),
(145, 405, 'uploads/66f2fa5f19a9a-KAIWA(2).webp', 'KAIWA(2).webp', '2024-09-24 17:43:59'),
(146, 405, 'uploads/66f2fa6e43fd7-KAIWA(3).webp', 'KAIWA(3).webp', '2024-09-24 17:44:14'),
(147, 405, 'uploads/66f2fa778eefc-KAIWA(4).webp', 'KAIWA(4).webp', '2024-09-24 17:44:23'),
(148, 406, 'uploads/66f2fa98c495f-SUPERSTAR XLG (1).webp', 'SUPERSTAR XLG (1).webp', '2024-09-24 17:44:56'),
(149, 406, 'uploads/66f2faa332723-SUPERSTAR XLG(2).webp', 'SUPERSTAR XLG(2).webp', '2024-09-24 17:45:07'),
(150, 406, 'uploads/66f2faacc6d9b-SUPERSTAR XLG(3).webp', 'SUPERSTAR XLG(3).webp', '2024-09-24 17:45:16'),
(151, 406, 'uploads/66f2fab67aedb-SUPERSTAR XLG(4).webp', 'SUPERSTAR XLG(4).webp', '2024-09-24 17:45:26'),
(152, 407, 'uploads/66f2faea0ef35-YEEZY 700 V3 AZAEL(1).webp', 'YEEZY 700 V3 AZAEL(1).webp', '2024-09-24 17:46:18'),
(153, 407, 'uploads/66f2faf5aeffb-YEEZY 700 V3 AZAEL(2).jpg', 'YEEZY 700 V3 AZAEL(2).jpg', '2024-09-24 17:46:29'),
(154, 407, 'uploads/66f2fb0535c81-YEEZY 700 V3 AZAEL(2).webp', 'YEEZY 700 V3 AZAEL(2).webp', '2024-09-24 17:46:45'),
(155, 407, 'uploads/66f2fb0de9b5d-YEEZY 700 V3 AZAEL(3).webp', 'YEEZY 700 V3 AZAEL(3).webp', '2024-09-24 17:46:53'),
(156, 408, 'uploads/66f2fb2e210b0-Yeezy Boost 700 Wave Runner (1).png', 'Yeezy Boost 700 Wave Runner (1).png', '2024-09-24 17:47:26'),
(157, 408, 'uploads/66f2fb4e8804e-Yeezy Boost 700 Wave Runner(2).jpeg', 'Yeezy Boost 700 Wave Runner(2).jpeg', '2024-09-24 17:47:58'),
(158, 408, 'uploads/66f2fb58ab456-Yeezy Boost 700 Wave Runner(3).jpeg', 'Yeezy Boost 700 Wave Runner(3).jpeg', '2024-09-24 17:48:08'),
(159, 408, 'uploads/66f2fb61bc023-Yeezy Boost 700 Wave Runner(4).jpeg', 'Yeezy Boost 700 Wave Runner(4).jpeg', '2024-09-24 17:48:17'),
(160, 409, 'uploads/66f2fb8f225ee-NMD_S1(1).webp', 'NMD_S1(1).webp', '2024-09-24 17:49:03'),
(161, 409, 'uploads/66f2fb9a2f910-NMD_S1(2).webp', 'NMD_S1(2).webp', '2024-09-24 17:49:14'),
(162, 409, 'uploads/66f2fba25e128-NMD_S1(3).webp', 'NMD_S1(3).webp', '2024-09-24 17:49:22'),
(163, 409, 'uploads/66f2fbac336a3-NMD_S1(4).webp', 'NMD_S1(4).webp', '2024-09-24 17:49:32'),
(164, 410, 'uploads/66f2fbd8ee932-YEEZY 500 BONE WHITE(1).webp', 'YEEZY 500 BONE WHITE(1).webp', '2024-09-24 17:50:16'),
(165, 410, 'uploads/66f2fbe2795e9-YEEZY 500 BONE WHITE(2).webp', 'YEEZY 500 BONE WHITE(2).webp', '2024-09-24 17:50:26'),
(166, 410, 'uploads/66f2fbeb84612-YEEZY 500 BONE WHITE(3).webp', 'YEEZY 500 BONE WHITE(3).webp', '2024-09-24 17:50:35'),
(167, 410, 'uploads/66f2fbf4becc6-YEEZY 500 BONE WHITE(4).webp', 'YEEZY 500 BONE WHITE(4).webp', '2024-09-24 17:50:44'),
(168, 501, 'uploads/66f2fc72584be-converse1.jpg', 'converse1.jpg', '2024-09-24 17:52:50'),
(169, 501, 'uploads/66f2fc9545003-converse1pic2.jpg', 'converse1pic2.jpg', '2024-09-24 17:53:25'),
(170, 501, 'uploads/66f2fc9f90a49-converse1pic3.jpg', 'converse1pic3.jpg', '2024-09-24 17:53:35'),
(185, 503, 'uploads/66f30175598f6-converse2.jpg', 'converse2.jpg', '2024-09-24 18:14:13'),
(186, 503, 'uploads/66f3017e9ef6a-converse2pic2.jpg', 'converse2pic2.jpg', '2024-09-24 18:14:22'),
(187, 503, 'uploads/66f30187a9cd7-converse2pic3.jpg', 'converse2pic3.jpg', '2024-09-24 18:14:31'),
(188, 504, 'uploads/66f3019a519cb-converse3.jpg', 'converse3.jpg', '2024-09-24 18:14:50'),
(189, 504, 'uploads/66f301a3cbc7d-converse3pic2.jpg', 'converse3pic2.jpg', '2024-09-24 18:14:59'),
(190, 504, 'uploads/66f301ac48696-converse3pic3.jpg', 'converse3pic3.jpg', '2024-09-24 18:15:08'),
(191, 505, 'uploads/66f301d1f1a14-converse4.jpg', 'converse4.jpg', '2024-09-24 18:15:45'),
(192, 505, 'uploads/66f301d9c3fe8-converse4pic2.jpg', 'converse4pic2.jpg', '2024-09-24 18:15:53'),
(193, 505, 'uploads/66f301e204198-converse4pic3.jpg', 'converse4pic3.jpg', '2024-09-24 18:16:02'),
(194, 506, 'uploads/66f30228a9c99-converse5.jpg', 'converse5.jpg', '2024-09-24 18:17:12'),
(195, 506, 'uploads/66f3023470d32-converse5pic2.jpg', 'converse5pic2.jpg', '2024-09-24 18:17:24'),
(196, 506, 'uploads/66f3023c8e29a-converse5pic3.jpg', 'converse5pic3.jpg', '2024-09-24 18:17:32'),
(197, 507, 'uploads/66f3025868f26-converse6.jpg', 'converse6.jpg', '2024-09-24 18:18:00'),
(198, 507, 'uploads/66f30260ce131-converse6pic2.jpg', 'converse6pic2.jpg', '2024-09-24 18:18:08'),
(199, 507, 'uploads/66f3026c23de6-converse6pic3.jpg', 'converse6pic3.jpg', '2024-09-24 18:18:20'),
(200, 508, 'uploads/66f30285df795-converse7.jpg', 'converse7.jpg', '2024-09-24 18:18:45'),
(201, 508, 'uploads/66f3028ea64a5-converse7pic2.jpg', 'converse7pic2.jpg', '2024-09-24 18:18:54'),
(202, 508, 'uploads/66f302e10108e-converse7pic3.jpg', 'converse7pic3.jpg', '2024-09-24 18:20:17'),
(203, 509, 'uploads/66f302eae910b-converse8.jpg', 'converse8.jpg', '2024-09-24 18:20:26'),
(204, 509, 'uploads/66f302f397f77-converse8pic2.jpg', 'converse8pic2.jpg', '2024-09-24 18:20:35'),
(205, 509, 'uploads/66f302fc3e6f5-converse8pic3.jpg', 'converse8pic3.jpg', '2024-09-24 18:20:44'),
(206, 510, 'uploads/66f30325c0d81-converse9.jpg', 'converse9.jpg', '2024-09-24 18:21:25'),
(207, 510, 'uploads/66f30330558f1-converse9pic2.jpg', 'converse9pic2.jpg', '2024-09-24 18:21:36'),
(208, 510, 'uploads/66f30339801e4-converse9pic3.jpg', 'converse9pic3.jpg', '2024-09-24 18:21:45'),
(209, 511, 'uploads/66f3035502606-converse10.jpg', 'converse10.jpg', '2024-09-24 18:22:13'),
(210, 511, 'uploads/66f3035d74f0d-converse10pic2.jpg', 'converse10pic2.jpg', '2024-09-24 18:22:21'),
(211, 511, 'uploads/66f30365a141c-converse10pic3.jpg', 'converse10pic3.jpg', '2024-09-24 18:22:29'),
(215, 512, 'uploads/66f3048274985-512(1).jpg', '512(1).jpg', '2024-09-24 18:27:14'),
(216, 512, 'uploads/66f3048a85022-512(2).jpg', '512(2).jpg', '2024-09-24 18:27:22'),
(217, 512, 'uploads/66f3049333a29-512(3).jpg', '512(3).jpg', '2024-09-24 18:27:31'),
(218, 512, 'uploads/66f3049c1df06-512(4).jpg', '512(4).jpg', '2024-09-24 18:27:40'),
(219, 212, 'uploads/670e1d63c9790-WMNS MAYZE EMBROIDERY(1).jpg', 'WMNS MAYZE EMBROIDERY(1).jpg', '2024-10-15 07:44:35'),
(220, 212, 'uploads/670e1d89e1f6b-WMNS MAYZE EMBROIDERY(2).jpg', 'WMNS MAYZE EMBROIDERY(2).jpg', '2024-10-15 07:45:13'),
(221, 212, 'uploads/670e1d9b20237-WMNS MAYZE EMBROIDERY(3).jpg', 'WMNS MAYZE EMBROIDERY(3).jpg', '2024-10-15 07:45:31'),
(222, 212, 'uploads/670e1daa8940e-WMNS MAYZE EMBROIDERY(4).jpg', 'WMNS MAYZE EMBROIDERY(4).jpg', '2024-10-15 07:45:46'),
(223, 213, 'uploads/670e1dd372409-WMNS MAYRA (1).jpg', 'WMNS MAYRA (1).jpg', '2024-10-15 07:46:27'),
(224, 213, 'uploads/670e1ddeec0e4-WMNS MAYRA (2).jpg', 'WMNS MAYRA (2).jpg', '2024-10-15 07:46:38'),
(225, 213, 'uploads/670e1de92b331-WMNS MAYRA (3).jpg', 'WMNS MAYRA (3).jpg', '2024-10-15 07:46:49'),
(226, 213, 'uploads/670e1df439561-WMNS MAYRA (4).jpg', 'WMNS MAYRA (4).jpg', '2024-10-15 07:47:00'),
(227, 214, 'uploads/670e1e17bcc4f-WMNS RS-X SOFT SNEKERS(1).jpg', 'WMNS RS-X SOFT SNEKERS(1).jpg', '2024-10-15 07:47:35'),
(228, 214, 'uploads/670e1e216ecee-WMNS RS-X SOFT SNEKERS(2).jpg', 'WMNS RS-X SOFT SNEKERS(2).jpg', '2024-10-15 07:47:45'),
(229, 214, 'uploads/670e1e2aa70f0-WMNS RS-X SOFT SNEKERS(3).jpg', 'WMNS RS-X SOFT SNEKERS(3).jpg', '2024-10-15 07:47:54'),
(230, 214, 'uploads/670e1e345ec68-WMNS RS-X SOFT SNEKERS(4).jpg', 'WMNS RS-X SOFT SNEKERS(4).jpg', '2024-10-15 07:48:04'),
(231, 215, 'uploads/670e1e476c651-WMNS MAYZE LTH(1).jpg', 'WMNS MAYZE LTH(1).jpg', '2024-10-15 07:48:23'),
(232, 215, 'uploads/670e1e51200c9-WMNS MAYZE LTH(2).jpg', 'WMNS MAYZE LTH(2).jpg', '2024-10-15 07:48:33'),
(233, 215, 'uploads/670e1e5e73ace-WMNS MAYZE LTH(3).jpg', 'WMNS MAYZE LTH(3).jpg', '2024-10-15 07:48:46'),
(234, 215, 'uploads/670e1e68be8bd-WMNS MAYZE LTH(4).jpg', 'WMNS MAYZE LTH(4).jpg', '2024-10-15 07:48:56'),
(235, 216, 'uploads/670e1e7dd3f2b-WMNS CA PRO PRM(1).jpg', 'WMNS CA PRO PRM(1).jpg', '2024-10-15 07:49:17'),
(236, 216, 'uploads/670e1e873d9ea-WMNS CA PRO PRM(2).jpg', 'WMNS CA PRO PRM(2).jpg', '2024-10-15 07:49:27'),
(237, 216, 'uploads/670e1e91951ab-WMNS CA PRO PRM(3).jpg', 'WMNS CA PRO PRM(3).jpg', '2024-10-15 07:49:37'),
(238, 216, 'uploads/670e1e9c6e79d-WMNS CA PRO PRM(4).jpg', 'WMNS CA PRO PRM(4).jpg', '2024-10-15 07:49:48'),
(239, 217, 'uploads/670e1f8607751-WMNS CARINA 2.0 LUX(1).jpg', 'WMNS CARINA 2.0 LUX(1).jpg', '2024-10-15 07:53:42'),
(240, 217, 'uploads/670e1f997b0de-WMNS CARINA 2.0 LUX(2)0.jpg', 'WMNS CARINA 2.0 LUX(2)0.jpg', '2024-10-15 07:54:01'),
(241, 217, 'uploads/670e1fa988fe8-WMNS CARINA 2.0 LUX(3).jpg', 'WMNS CARINA 2.0 LUX(3).jpg', '2024-10-15 07:54:17'),
(242, 217, 'uploads/670e1fb584216-WMNS CARINA 2.0 LUX(4).jpg', 'WMNS CARINA 2.0 LUX(4).jpg', '2024-10-15 07:54:29'),
(243, 218, 'uploads/670e1fc9808ea-WMNS BLSTR(1).jpg', 'WMNS BLSTR(1).jpg', '2024-10-15 07:54:49'),
(244, 218, 'uploads/670e1fd2e93c3-WMNS BLSTR(2).jpg', 'WMNS BLSTR(2).jpg', '2024-10-15 07:54:58'),
(245, 218, 'uploads/670e1fdcbfcfe-WMNS BLSTR(3).jpg', 'WMNS BLSTR(3).jpg', '2024-10-15 07:55:08'),
(246, 218, 'uploads/670e1fe7f2fa5-WMNS BLSTR(4).jpg', 'WMNS BLSTR(4).jpg', '2024-10-15 07:55:19'),
(247, 219, 'uploads/670e200fa3a91-WMNS KARMEN II MID(1).jpg', 'WMNS KARMEN II MID(1).jpg', '2024-10-15 07:55:59'),
(248, 219, 'uploads/670e20198229d-WMNS KARMEN II MID(2).jpg', 'WMNS KARMEN II MID(2).jpg', '2024-10-15 07:56:09'),
(249, 219, 'uploads/670e2022cd43c-WMNS KARMEN II MID(3).jpg', 'WMNS KARMEN II MID(3).jpg', '2024-10-15 07:56:18'),
(250, 219, 'uploads/670e202d7aa0d-WMNS KARMEN II MID(4).jpg', 'WMNS KARMEN II MID(4).jpg', '2024-10-15 07:56:29'),
(251, 220, 'uploads/670e2041bf950-WMNS CALI COURT LTH(1).jpg', 'WMNS CALI COURT LTH(1).jpg', '2024-10-15 07:56:49'),
(252, 220, 'uploads/670e204b43798-WMNS CALI COURT LTH(2).jpg', 'WMNS CALI COURT LTH(2).jpg', '2024-10-15 07:56:59'),
(253, 220, 'uploads/670e2055946d7-WMNS CALI COURT LTH(3).jpg', 'WMNS CALI COURT LTH(3).jpg', '2024-10-15 07:57:09'),
(254, 220, 'uploads/670e205f6f0d1-WMNS CALI COURT LTH(4).jpg', 'WMNS CALI COURT LTH(4).jpg', '2024-10-15 07:57:19'),
(255, 221, 'uploads/670e2081ccf1b-WMNS MAYZE STACK(1).jpg', 'WMNS MAYZE STACK(1).jpg', '2024-10-15 07:57:53'),
(256, 221, 'uploads/670e208a90c57-WMNS MAYZE STACK(2).jpg', 'WMNS MAYZE STACK(2).jpg', '2024-10-15 07:58:02'),
(257, 221, 'uploads/670e2093c67bf-WMNS MAYZE STACK(3).jpg', 'WMNS MAYZE STACK(3).jpg', '2024-10-15 07:58:11'),
(258, 221, 'uploads/670e209df185a-WMNS MAYZE STACK(4).jpg', 'WMNS MAYZE STACK(4).jpg', '2024-10-15 07:58:21'),
(259, 301, 'uploads/6712167ec0671-CROCS UNISEX ADULT CLOGS BAYA BEIGE(1).jpg', 'CROCS UNISEX ADULT CLOGS BAYA BEIGE(1).jpg', '2024-10-18 08:04:14'),
(260, 301, 'uploads/671216ab4b4f0-CROCS UNISEX ADULT CLOGS BAYA BEIGE(2).jpg', 'CROCS UNISEX ADULT CLOGS BAYA BEIGE(2).jpg', '2024-10-18 08:04:59'),
(261, 301, 'uploads/671216b48d7b8-CROCS UNISEX ADULT CLOGS BAYA BEIGE(3).jpg', 'CROCS UNISEX ADULT CLOGS BAYA BEIGE(3).jpg', '2024-10-18 08:05:08'),
(262, 301, 'uploads/671216bd7cafa-CROCS UNISEX ADULT CLOGS BAYA BEIGE(4).jpg', 'CROCS UNISEX ADULT CLOGS BAYA BEIGE(4).jpg', '2024-10-18 08:05:17'),
(263, 302, 'uploads/671216e08d3b2-CROCS UNISEX ADULT CROCBAND CLOGS BLACK(1).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS BLACK(1).jpg', '2024-10-18 08:05:52'),
(264, 302, 'uploads/671216ea032c1-CROCS UNISEX ADULT CROCBAND CLOGS BLACK(2).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS BLACK(2).jpg', '2024-10-18 08:06:02'),
(265, 302, 'uploads/671216f73a9d9-CROCS UNISEX ADULT CROCBAND CLOGS BLACK(3).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS BLACK(3).jpg', '2024-10-18 08:06:15'),
(266, 302, 'uploads/67121700dada0-CROCS UNISEX ADULT CROCBAND CLOGS BLACK(4).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS BLACK(4).jpg', '2024-10-18 08:06:24'),
(267, 303, 'uploads/6712189384a66-CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(1).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(1).jpg', '2024-10-18 08:13:07'),
(268, 303, 'uploads/671218a01f717-CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(2).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(2).jpg', '2024-10-18 08:13:20'),
(269, 303, 'uploads/671218aa92ea0-CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(3).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(3).jpg', '2024-10-18 08:13:30'),
(270, 303, 'uploads/671218b458fb9-CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(4).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS CHARCOAL OCEAN(4).jpg', '2024-10-18 08:13:40'),
(271, 304, 'uploads/671218dd360fb-CROCS UNISEX ADULT CROCBAND CLOGS WHITE(1).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS WHITE(1).jpg', '2024-10-18 08:14:21'),
(272, 304, 'uploads/671218e7545ed-CROCS UNISEX ADULT CROCBAND CLOGS WHITE(2).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS WHITE(2).jpg', '2024-10-18 08:14:31'),
(273, 304, 'uploads/671218f0e7874-CROCS UNISEX ADULT CROCBAND CLOGS WHITE(3).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS WHITE(3).jpg', '2024-10-18 08:14:40'),
(274, 304, 'uploads/671218fb667b1-CROCS UNISEX ADULT CROCBAND CLOGS WHITE(4).jpg', 'CROCS UNISEX ADULT CROCBAND CLOGS WHITE(4).jpg', '2024-10-18 08:14:51'),
(275, 305, 'uploads/6712191302eac-CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(1).jpg', 'CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(1).jpg', '2024-10-18 08:15:15'),
(276, 305, 'uploads/6712191f892d9-CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(2).jpg', 'CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(2).jpg', '2024-10-18 08:15:27'),
(277, 305, 'uploads/6712192c5aa5b-CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(3).jpg', 'CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(3).jpg', '2024-10-18 08:15:40'),
(278, 305, 'uploads/67121936a9321-CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(4).jpg', 'CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE(4).jpg', '2024-10-18 08:15:50'),
(279, 306, 'uploads/671219484a0b9-CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(1).jpg', 'CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(1).jpg', '2024-10-18 08:16:08'),
(280, 306, 'uploads/67121952c49b3-CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(2).jpg', 'CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(2).jpg', '2024-10-18 08:16:18'),
(281, 306, 'uploads/6712195d01507-CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(3).jpg', 'CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(3).jpg', '2024-10-18 08:16:29'),
(282, 306, 'uploads/671219672648a-CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(4).jpg', 'CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK(4).jpg', '2024-10-18 08:16:39'),
(283, 307, 'uploads/6712198184c05-CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(1).jpg', 'CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(1).jpg', '2024-10-18 08:17:05'),
(284, 307, 'uploads/6712199539bee-CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(2).jpg', 'CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(2).jpg', '2024-10-18 08:17:25'),
(285, 307, 'uploads/671219a059647-CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(3).jpg', 'CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(3).jpg', '2024-10-18 08:17:36'),
(286, 307, 'uploads/671219ac8256a-CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(4).jpg', 'CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE(4).jpg', '2024-10-18 08:17:48'),
(287, 308, 'uploads/671219bf8d25d-CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(1).jpg', 'CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(1).jpg', '2024-10-18 08:18:07'),
(288, 308, 'uploads/671219cb64af2-CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(2).jpg', 'CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(2).jpg', '2024-10-18 08:18:19'),
(289, 308, 'uploads/671219d70cbcd-CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(3).jpg', 'CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(3).jpg', '2024-10-18 08:18:31'),
(290, 308, 'uploads/671219e9530c2-CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(4).jpg', 'CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY(4).jpg', '2024-10-18 08:18:49'),
(291, 309, 'uploads/671219ff0e575-CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(1).jpg', 'CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(1).jpg', '2024-10-18 08:19:11'),
(292, 309, 'uploads/67121a0a3021e-CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(2).jpg', 'CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(2).jpg', '2024-10-18 08:19:22'),
(293, 309, 'uploads/67121a15103d2-CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(3).jpg', 'CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(3).jpg', '2024-10-18 08:19:33'),
(294, 309, 'uploads/67121a29b7931-CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(4).jpg', 'CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN(4).jpg', '2024-10-18 08:19:53'),
(295, 310, 'uploads/67121a524b65e-CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(1).jpg', 'CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(1).jpg', '2024-10-18 08:20:34'),
(296, 310, 'uploads/67121a636b579-CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(2).jpg', 'CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(2).jpg', '2024-10-18 08:20:51'),
(297, 310, 'uploads/67121a722af4d-CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(3).jpg', 'CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(3).jpg', '2024-10-18 08:21:06'),
(298, 310, 'uploads/67121a7e5c604-CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(44).jpg', 'CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY(44).jpg', '2024-10-18 08:21:18'),
(299, 311, 'uploads/67121ac4120fe-CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(1).jpg', 'CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(1).jpg', '2024-10-18 08:22:28'),
(300, 311, 'uploads/67121add8c1b0-CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(2).jpg', 'CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(2).jpg', '2024-10-18 08:22:53'),
(301, 311, 'uploads/67121aec8044f-CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(3).jpg', 'CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(3).jpg', '2024-10-18 08:23:08'),
(302, 311, 'uploads/67121af845dd4-CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(4).jpg', 'CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET(4).jpg', '2024-10-18 08:23:20'),
(303, 312, 'uploads/67121b0c51ba2-CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(1).jpg', 'CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(1).jpg', '2024-10-18 08:23:40'),
(304, 312, 'uploads/67121b1649eeb-CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(2).jpg', 'CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(2).jpg', '2024-10-18 08:23:50'),
(305, 312, 'uploads/67121b215d089-CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(3).jpg', 'CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(3).jpg', '2024-10-18 08:24:01'),
(306, 312, 'uploads/67121b2bb8289-CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(4).jpg', 'CROCS UNISEX BAYABAND CLOG ELECTRIC PINK(4).jpg', '2024-10-18 08:24:11'),
(307, 313, 'uploads/67121b43f24c8-CROCS UNISEX BAYABAND CLOG LEMON WHITE(1).jpg', 'CROCS UNISEX BAYABAND CLOG LEMON WHITE(1).jpg', '2024-10-18 08:24:35'),
(308, 313, 'uploads/67121b4f81b55-CROCS UNISEX BAYABAND CLOG LEMON WHITE(2).jpg', 'CROCS UNISEX BAYABAND CLOG LEMON WHITE(2).jpg', '2024-10-18 08:24:47'),
(309, 313, 'uploads/67121b59b2470-CROCS UNISEX BAYABAND CLOG LEMON WHITE(3).jpg', 'CROCS UNISEX BAYABAND CLOG LEMON WHITE(3).jpg', '2024-10-18 08:24:57'),
(310, 313, 'uploads/67121b6547420-CROCS UNISEX BAYABAND CLOG LEMON WHITE(4).jpg', 'CROCS UNISEX BAYABAND CLOG LEMON WHITE(4).jpg', '2024-10-18 08:25:09'),
(311, 314, 'uploads/67121b7ed8071-CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(1).jpg', 'CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(1).jpg', '2024-10-18 08:25:34'),
(312, 314, 'uploads/67121b8a5ef02-CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(2).jpg', 'CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(2).jpg', '2024-10-18 08:25:46'),
(313, 314, 'uploads/67121b9719a1c-CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(3).jpg', 'CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(3).jpg', '2024-10-18 08:25:59'),
(314, 314, 'uploads/67121ba6bb570-CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(4).jpg', 'CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO(4).jpg', '2024-10-18 08:26:14'),
(315, 315, 'uploads/67121bbfc0e8e-CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(1).jpg', 'CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(1).jpg', '2024-10-18 08:26:39'),
(316, 315, 'uploads/67121bcaed8af-CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(2).jpg', 'CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(2).jpg', '2024-10-18 08:26:50'),
(317, 315, 'uploads/67121bd6c7847-CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(3).jpg', 'CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(3).jpg', '2024-10-18 08:27:02'),
(318, 315, 'uploads/67121be056a40-CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(4).jpg', 'CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE(4).jpg', '2024-10-18 08:27:12'),
(319, 316, 'uploads/67121bf29779a-CROCS UNISEX BAYABAND CLOG PEPPER NAVY(1).jpg', 'CROCS UNISEX BAYABAND CLOG PEPPER NAVY(1).jpg', '2024-10-18 08:27:30'),
(320, 316, 'uploads/67121bfc3aa87-CROCS UNISEX BAYABAND CLOG PEPPER NAVY(2).jpg', 'CROCS UNISEX BAYABAND CLOG PEPPER NAVY(2).jpg', '2024-10-18 08:27:40'),
(321, 316, 'uploads/67121c072d258-CROCS UNISEX BAYABAND CLOG PEPPER NAVY(3).jpg', 'CROCS UNISEX BAYABAND CLOG PEPPER NAVY(3).jpg', '2024-10-18 08:27:51'),
(322, 316, 'uploads/67121c11a87ea-CROCS UNISEX BAYABAND CLOG PEPPER NAVY(4).jpg', 'CROCS UNISEX BAYABAND CLOG PEPPER NAVY(4).jpg', '2024-10-18 08:28:01'),
(323, 317, 'uploads/67121c270245c-CROCS UNISEX BAYABAND CLOG SLATE GREY(1).jpg', 'CROCS UNISEX BAYABAND CLOG SLATE GREY(1).jpg', '2024-10-18 08:28:23'),
(324, 317, 'uploads/67121c34aadde-CROCS UNISEX BAYABAND CLOG SLATE GREY(2).jpg', 'CROCS UNISEX BAYABAND CLOG SLATE GREY(2).jpg', '2024-10-18 08:28:36'),
(325, 317, 'uploads/67121c404b0bb-CROCS UNISEX BAYABAND CLOG SLATE GREY(3).jpg', 'CROCS UNISEX BAYABAND CLOG SLATE GREY(3).jpg', '2024-10-18 08:28:48'),
(326, 317, 'uploads/67121c4e03f34-CROCS UNISEX BAYABAND CLOG SLATE GREY(4).jpg', 'CROCS UNISEX BAYABAND CLOG SLATE GREY(4).jpg', '2024-10-18 08:29:02'),
(327, 318, 'uploads/67121c696e982-CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(1).jpg', 'CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(1).jpg', '2024-10-18 08:29:29'),
(328, 318, 'uploads/67121c761a1e1-CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(2).jpg', 'CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(2).jpg', '2024-10-18 08:29:42'),
(329, 318, 'uploads/67121c80f2f34-CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(3).jpg', 'CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(3).jpg', '2024-10-18 08:29:52'),
(330, 318, 'uploads/67121c8fe43f3-CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(4).jpg', 'CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT(4).jpg', '2024-10-18 08:30:07'),
(331, 319, 'uploads/67121ca4f21e5-CROCS UNISEX BAYABAND CLOG WHITE NAVY(1).jpg', 'CROCS UNISEX BAYABAND CLOG WHITE NAVY(1).jpg', '2024-10-18 08:30:28'),
(332, 319, 'uploads/67121cb1a2d60-CROCS UNISEX BAYABAND CLOG WHITE NAVY(2).jpg', 'CROCS UNISEX BAYABAND CLOG WHITE NAVY(2).jpg', '2024-10-18 08:30:41'),
(333, 319, 'uploads/67121cbc9acc3-CROCS UNISEX BAYABAND CLOG WHITE NAVY(3).jpg', 'CROCS UNISEX BAYABAND CLOG WHITE NAVY(3).jpg', '2024-10-18 08:30:52'),
(334, 319, 'uploads/67121cc6b303c-CROCS UNISEX BAYABAND CLOG WHITE NAVY(4).jpg', 'CROCS UNISEX BAYABAND CLOG WHITE NAVY(4).jpg', '2024-10-18 08:31:02'),
(335, 320, 'uploads/67121cd4b8398-CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(1).jpg', 'CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(1).jpg', '2024-10-18 08:31:16'),
(336, 320, 'uploads/67121cddf06e0-CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(2).jpg', 'CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(2).jpg', '2024-10-18 08:31:25'),
(337, 320, 'uploads/67121ce809466-CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(3).jpg', 'CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(3).jpg', '2024-10-18 08:31:36'),
(338, 320, 'uploads/67121cf1b77f1-CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(4).jpg', 'CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI(4).jpg', '2024-10-18 08:31:45'),
(339, 321, 'uploads/67121d02f1562-CROCS UNISEX OFF GRID CLOG BLACK(1).jpg', 'CROCS UNISEX OFF GRID CLOG BLACK(1).jpg', '2024-10-18 08:32:02'),
(340, 321, 'uploads/67121d0c1d601-CROCS UNISEX OFF GRID CLOG BLACK(2).jpg', 'CROCS UNISEX OFF GRID CLOG BLACK(2).jpg', '2024-10-18 08:32:12'),
(341, 321, 'uploads/67121d156760e-CROCS UNISEX OFF GRID CLOG BLACK(3).jpg', 'CROCS UNISEX OFF GRID CLOG BLACK(3).jpg', '2024-10-18 08:32:21'),
(342, 321, 'uploads/67121d1e4f07f-CROCS UNISEX OFF GRID CLOG BLACK(4).jpg', 'CROCS UNISEX OFF GRID CLOG BLACK(4).jpg', '2024-10-18 08:32:30'),
(343, 322, 'uploads/67122088d0112-CROCS UNISEX OFF GRID CLOG LIGHT GREY(1).jpg', 'CROCS UNISEX OFF GRID CLOG LIGHT GREY(1).jpg', '2024-10-18 08:47:04'),
(344, 322, 'uploads/671220929c406-CROCS UNISEX OFF GRID CLOG LIGHT GREY(2).jpg', 'CROCS UNISEX OFF GRID CLOG LIGHT GREY(2).jpg', '2024-10-18 08:47:14'),
(345, 322, 'uploads/6712209c94c26-CROCS UNISEX OFF GRID CLOG LIGHT GREY(3).jpg', 'CROCS UNISEX OFF GRID CLOG LIGHT GREY(3).jpg', '2024-10-18 08:47:24'),
(346, 322, 'uploads/671220a57035d-CROCS UNISEX OFF GRID CLOG LIGHT GREY(4).jpg', 'CROCS UNISEX OFF GRID CLOG LIGHT GREY(4).jpg', '2024-10-18 08:47:33'),
(347, 323, 'uploads/671220be29c94-CROCS UNISEX OFF GRID CLOG WHITE(1).jpg', 'CROCS UNISEX OFF GRID CLOG WHITE(1).jpg', '2024-10-18 08:47:58'),
(348, 323, 'uploads/671220c83df77-CROCS UNISEX OFF GRID CLOG WHITE(2).jpg', 'CROCS UNISEX OFF GRID CLOG WHITE(2).jpg', '2024-10-18 08:48:08'),
(349, 323, 'uploads/671220d38377d-CROCS UNISEX OFF GRID CLOG WHITE(3).jpg', 'CROCS UNISEX OFF GRID CLOG WHITE(3).jpg', '2024-10-18 08:48:19'),
(350, 323, 'uploads/671220dd022f7-CROCS UNISEX OFF GRID CLOG WHITE(4).jpg', 'CROCS UNISEX OFF GRID CLOG WHITE(4).jpg', '2024-10-18 08:48:29'),
(351, 324, 'uploads/671221588a7d3-CROCS UNISEX BAYA II SLIDE BLACK(1).jpg', 'CROCS UNISEX BAYA II SLIDE BLACK(1).jpg', '2024-10-18 08:50:32'),
(352, 324, 'uploads/6712216116761-CROCS UNISEX BAYA II SLIDE BLACK(2).jpg', 'CROCS UNISEX BAYA II SLIDE BLACK(2).jpg', '2024-10-18 08:50:41'),
(353, 324, 'uploads/671221688c2d6-CROCS UNISEX BAYA II SLIDE BLACK(3).jpg', 'CROCS UNISEX BAYA II SLIDE BLACK(3).jpg', '2024-10-18 08:50:48'),
(354, 324, 'uploads/671221719148f-CROCS UNISEX BAYA II SLIDE BLACK(4).jpg', 'CROCS UNISEX BAYA II SLIDE BLACK(4).jpg', '2024-10-18 08:50:57'),
(355, 325, 'uploads/671221842b404-CROCS UNISEX BAYA II SLIDE COBBLESTONE(1).jpg', 'CROCS UNISEX BAYA II SLIDE COBBLESTONE(1).jpg', '2024-10-18 08:51:16'),
(356, 325, 'uploads/6712218c99d30-CROCS UNISEX BAYA II SLIDE COBBLESTONE(2).jpg', 'CROCS UNISEX BAYA II SLIDE COBBLESTONE(2).jpg', '2024-10-18 08:51:24'),
(357, 325, 'uploads/67122196ae6ec-CROCS UNISEX BAYA II SLIDE COBBLESTONE(3).jpg', 'CROCS UNISEX BAYA II SLIDE COBBLESTONE(3).jpg', '2024-10-18 08:51:34'),
(358, 325, 'uploads/6712219f95bd5-CROCS UNISEX BAYA II SLIDE COBBLESTONE(4).jpg', 'CROCS UNISEX BAYA II SLIDE COBBLESTONE(4).jpg', '2024-10-18 08:51:43'),
(359, 326, 'uploads/671221da526aa-CROCS UNISEX BAYA II SLIDE NAVY(1).jpg', 'CROCS UNISEX BAYA II SLIDE NAVY(1).jpg', '2024-10-18 08:52:42'),
(360, 326, 'uploads/671221e4d4036-CROCS UNISEX BAYA II SLIDE NAVY(2).jpg', 'CROCS UNISEX BAYA II SLIDE NAVY(2).jpg', '2024-10-18 08:52:52'),
(361, 326, 'uploads/671221ee97976-CROCS UNISEX BAYA II SLIDE NAVY(3).jpg', 'CROCS UNISEX BAYA II SLIDE NAVY(3).jpg', '2024-10-18 08:53:02'),
(362, 326, 'uploads/671221f68f073-CROCS UNISEX BAYA II SLIDE NAVY(44).jpg', 'CROCS UNISEX BAYA II SLIDE NAVY(44).jpg', '2024-10-18 08:53:10'),
(363, 327, 'uploads/671222096d5cb-CROCS UNISEX BAYA II SLIDE WHITE(1).jpg', 'CROCS UNISEX BAYA II SLIDE WHITE(1).jpg', '2024-10-18 08:53:29'),
(364, 327, 'uploads/67122212abb56-CROCS UNISEX BAYA II SLIDE WHITE(2).jpg', 'CROCS UNISEX BAYA II SLIDE WHITE(2).jpg', '2024-10-18 08:53:38'),
(365, 327, 'uploads/67122220cd429-CROCS UNISEX BAYA II SLIDE WHITE(3).jpg', 'CROCS UNISEX BAYA II SLIDE WHITE(3).jpg', '2024-10-18 08:53:52'),
(366, 327, 'uploads/67122229ccae8-CROCS UNISEX BAYA II SLIDE WHITE(4).jpg', 'CROCS UNISEX BAYA II SLIDE WHITE(4).jpg', '2024-10-18 08:54:01'),
(367, 328, 'uploads/6712223c9415a-CROCS UNISEX BAYA SANDAL COBBLESTONE(1).jpg', 'CROCS UNISEX BAYA SANDAL COBBLESTONE(1).jpg', '2024-10-18 08:54:20'),
(368, 328, 'uploads/671222452639a-CROCS UNISEX BAYA SANDAL COBBLESTONE(2).jpg', 'CROCS UNISEX BAYA SANDAL COBBLESTONE(2).jpg', '2024-10-18 08:54:29'),
(369, 328, 'uploads/6712224f3326c-CROCS UNISEX BAYA SANDAL COBBLESTONE(3).jpg', 'CROCS UNISEX BAYA SANDAL COBBLESTONE(3).jpg', '2024-10-18 08:54:39'),
(370, 328, 'uploads/6712228507f88-CROCS UNISEX BAYA SANDAL COBBLESTONE(4).jpg', 'CROCS UNISEX BAYA SANDAL COBBLESTONE(4).jpg', '2024-10-18 08:55:33'),
(371, 329, 'uploads/67122299a9d3b-CROCS UNISEX BAYA SANDAL NAVY(1).jpg', 'CROCS UNISEX BAYA SANDAL NAVY(1).jpg', '2024-10-18 08:55:53'),
(372, 329, 'uploads/671222a29572e-CROCS UNISEX BAYA SANDAL NAVY(2).jpg', 'CROCS UNISEX BAYA SANDAL NAVY(2).jpg', '2024-10-18 08:56:02'),
(373, 329, 'uploads/671222ab9dba5-CROCS UNISEX BAYA SANDAL NAVY(3).jpg', 'CROCS UNISEX BAYA SANDAL NAVY(3).jpg', '2024-10-18 08:56:11'),
(374, 329, 'uploads/671222b58f39c-CROCS UNISEX BAYA SANDAL NAVY(4).jpg', 'CROCS UNISEX BAYA SANDAL NAVY(4).jpg', '2024-10-18 08:56:21'),
(375, 330, 'uploads/671222c6cb3cf-CROCS UNISEX BAYA SANDAL WHITE(1).jpg', 'CROCS UNISEX BAYA SANDAL WHITE(1).jpg', '2024-10-18 08:56:38'),
(376, 330, 'uploads/671222d464924-CROCS UNISEX BAYA SANDAL WHITE(2).jpg', 'CROCS UNISEX BAYA SANDAL WHITE(2).jpg', '2024-10-18 08:56:52'),
(377, 330, 'uploads/671222dea6e5b-CROCS UNISEX BAYA SANDAL WHITE(3).jpg', 'CROCS UNISEX BAYA SANDAL WHITE(3).jpg', '2024-10-18 08:57:02'),
(378, 330, 'uploads/671222e95de25-CROCS UNISEX BAYA SANDAL WHITE(4).jpg', 'CROCS UNISEX BAYA SANDAL WHITE(4).jpg', '2024-10-18 08:57:13'),
(379, 331, 'uploads/671222f8dba53-CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(1).jpg', 'CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(1).jpg', '2024-10-18 08:57:28'),
(380, 331, 'uploads/6712230410f88-CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(2).jpg', 'CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(2).jpg', '2024-10-18 08:57:40'),
(381, 331, 'uploads/6712230d45923-CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(3).jpg', 'CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(3).jpg', '2024-10-18 08:57:49'),
(382, 331, 'uploads/67122315b2216-CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(4).jpg', 'CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO(4).jpg', '2024-10-18 08:57:57'),
(383, 332, 'uploads/67122325ecbe0-CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(1).jpg', 'CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(1).jpg', '2024-10-18 08:58:13'),
(384, 332, 'uploads/67122331dd9ce-CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(2).jpg', 'CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(2).jpg', '2024-10-18 08:58:25'),
(385, 332, 'uploads/6712233b50a5d-CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(3).jpg', 'CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(3).jpg', '2024-10-18 08:58:35'),
(386, 332, 'uploads/67122344e47f2-CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(4).jpg', 'CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE(4).jpg', '2024-10-18 08:58:44'),
(387, 333, 'uploads/671223558c6e7-CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(1).jpg', 'CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(1).jpg', '2024-10-18 08:59:01'),
(388, 333, 'uploads/671223601e6e4-CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(2).jpg', 'CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(2).jpg', '2024-10-18 08:59:12'),
(389, 333, 'uploads/6712236b0dda0-CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(3).jpg', 'CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(3).jpg', '2024-10-18 08:59:23'),
(390, 333, 'uploads/67122373191c2-CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(4).jpg', 'CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT(4).jpg', '2024-10-18 08:59:31'),
(391, 334, 'uploads/6712238548912-CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(1).jpg', 'CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(1).jpg', '2024-10-18 08:59:49'),
(392, 334, 'uploads/6712238e0b1b7-CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(2).jpg', 'CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(2).jpg', '2024-10-18 08:59:58'),
(393, 334, 'uploads/67122397a756d-CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(3).jpg', 'CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(3).jpg', '2024-10-18 09:00:07'),
(394, 334, 'uploads/671223a424842-CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(3).jpg', 'CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN(3).jpg', '2024-10-18 09:00:20'),
(396, 335, 'uploads/671223bd6d46c-CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(1).jpg', 'CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(1).jpg', '2024-10-18 09:00:45'),
(397, 335, 'uploads/671223c7481ae-CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(2).jpg', 'CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(2).jpg', '2024-10-18 09:00:55'),
(398, 335, 'uploads/671223d15c55a-CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(3).jpg', 'CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(3).jpg', '2024-10-18 09:01:05'),
(399, 335, 'uploads/671223dd4c047-CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(4).jpg', 'CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK(4).jpg', '2024-10-18 09:01:17'),
(400, 336, 'uploads/671223f2aaa19-CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(1).jpg', 'CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(1).jpg', '2024-10-18 09:01:38'),
(401, 336, 'uploads/671223fbe479e-CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(2).jpg', 'CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(2).jpg', '2024-10-18 09:01:47'),
(402, 336, 'uploads/67122404987a8-CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(3).jpg', 'CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(3).jpg', '2024-10-18 09:01:56'),
(403, 336, 'uploads/6712240de5d6f-CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(4).jpg', 'CROCS UNISEX BAYABAND SLIDE NAVY PEPPER(4).jpg', '2024-10-18 09:02:05'),
(404, 337, 'uploads/6712241ce792c-CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(1).jpg', 'CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(1).jpg', '2024-10-18 09:02:20'),
(405, 337, 'uploads/671224276e017-CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(2).jpg', 'CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(2).jpg', '2024-10-18 09:02:31'),
(406, 337, 'uploads/671224303d1d7-CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(3).jpg', 'CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(3).jpg', '2024-10-18 09:02:40'),
(407, 337, 'uploads/67122439f0e2f-CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(4).jpg', 'CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH(4).jpg', '2024-10-18 09:02:49'),
(408, 338, 'uploads/67122442e46f3-CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(1).jpg', 'CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(1).jpg', '2024-10-18 09:02:58'),
(409, 338, 'uploads/6712244c5e2d0-CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(2).jpg', 'CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(2).jpg', '2024-10-18 09:03:08'),
(410, 338, 'uploads/671224556d876-CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(3).jpg', 'CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(3).jpg', '2024-10-18 09:03:17'),
(411, 338, 'uploads/67122461f0b4f-CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(4).jpg', 'CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY(4).jpg', '2024-10-18 09:03:29'),
(412, 222, 'uploads/67123e3e66395-AXELION REFRESH RUNNING WHITE(1).jpg', 'AXELION REFRESH RUNNING WHITE(1).jpg', '2024-10-18 10:53:50'),
(413, 222, 'uploads/67123e4bad2bf-AXELION REFRESH RUNNING WHITE(2).jpg', 'AXELION REFRESH RUNNING WHITE(2).jpg', '2024-10-18 10:54:03'),
(414, 222, 'uploads/67123e53b394a-AXELION REFRESH RUNNING WHITE(3).jpg', 'AXELION REFRESH RUNNING WHITE(3).jpg', '2024-10-18 10:54:11'),
(415, 222, 'uploads/67123e5bca42a-AXELION REFRESH RUNNING WHITE(4).jpg', 'AXELION REFRESH RUNNING WHITE(4).jpg', '2024-10-18 10:54:19'),
(416, 223, 'uploads/6712403cdfe11-AXELION REFRESH RUNNING(1).jpg', 'AXELION REFRESH RUNNING(1).jpg', '2024-10-18 11:02:20'),
(417, 223, 'uploads/67124045e65ec-AXELION REFRESH RUNNING(2).jpg', 'AXELION REFRESH RUNNING(2).jpg', '2024-10-18 11:02:29'),
(418, 223, 'uploads/6712404f23ed1-AXELION REFRESH RUNNING(3).jpg', 'AXELION REFRESH RUNNING(3).jpg', '2024-10-18 11:02:39'),
(419, 223, 'uploads/671240574412d-AXELION REFRESH RUNNING(4).jpg', 'AXELION REFRESH RUNNING(4).jpg', '2024-10-18 11:02:47'),
(420, 224, 'uploads/6712406b851c3-ST RUNNER V4 L(1).jpg', 'ST RUNNER V4 L(1).jpg', '2024-10-18 11:03:07');
INSERT INTO `productimages` (`image_id`, `product_id`, `image_url`, `alt_text`, `created_at`) VALUES
(421, 224, 'uploads/67124074c8aa8-ST RUNNER V4 L(2).jpg', 'ST RUNNER V4 L(2).jpg', '2024-10-18 11:03:16'),
(422, 224, 'uploads/671240ce94435-ST RUNNER V4 L(3).jpg', 'ST RUNNER V4 L(3).jpg', '2024-10-18 11:04:46'),
(423, 224, 'uploads/671240d9e363b-ST RUNNER V4 L(4).jpg', 'ST RUNNER V4 L(4).jpg', '2024-10-18 11:04:57'),
(424, 225, 'uploads/67124123e8b00-HYPNOTIC LS RES(1).jpg', 'HYPNOTIC LS RES(1).jpg', '2024-10-18 11:06:11'),
(425, 225, 'uploads/67124130a3256-HYPNOTIC LS RES(2).jpg', 'HYPNOTIC LS RES(2).jpg', '2024-10-18 11:06:24'),
(426, 225, 'uploads/6712413b8c7e4-HYPNOTIC LS RES(3).jpg', 'HYPNOTIC LS RES(3).jpg', '2024-10-18 11:06:35'),
(427, 225, 'uploads/67124144a6c29-HYPNOTIC LS RES(4).jpg', 'HYPNOTIC LS RES(4).jpg', '2024-10-18 11:06:44'),
(428, 226, 'uploads/671241584f2bf-SMASH SPRINT INDOOR SHOE(1).jpg', 'SMASH SPRINT INDOOR SHOE(1).jpg', '2024-10-18 11:07:04'),
(429, 226, 'uploads/671241622098e-SMASH SPRINT INDOOR SHOE(2).jpg', 'SMASH SPRINT INDOOR SHOE(2).jpg', '2024-10-18 11:07:14'),
(430, 226, 'uploads/6712416c54318-SMASH SPRINT INDOOR SHOE(3).jpg', 'SMASH SPRINT INDOOR SHOE(3).jpg', '2024-10-18 11:07:24'),
(431, 226, 'uploads/6712417652da2-SMASH SPRINT INDOOR SHOE(4).jpg', 'SMASH SPRINT INDOOR SHOE(4).jpg', '2024-10-18 11:07:34'),
(432, 227, 'uploads/671241cae5d91-ULTRARIDE WALKING(1).jpg', 'ULTRARIDE WALKING(1).jpg', '2024-10-18 11:08:58'),
(433, 227, 'uploads/671241d512a0a-ULTRARIDE WALKING(2).jpg', 'ULTRARIDE WALKING(2).jpg', '2024-10-18 11:09:09'),
(434, 227, 'uploads/671241de007a9-ULTRARIDE WALKING(3).jpg', 'ULTRARIDE WALKING(3).jpg', '2024-10-18 11:09:18'),
(435, 227, 'uploads/671241ea6ada1-ULTRARIDE WALKING(4).jpg', 'ULTRARIDE WALKING(4).jpg', '2024-10-18 11:09:30'),
(436, 228, 'uploads/671241fb2530c-ULTRARIDE RUNNING(1).jpg', 'ULTRARIDE RUNNING(1).jpg', '2024-10-18 11:09:47'),
(437, 228, 'uploads/67124207badf8-ULTRARIDE RUNNING(2).jpg', 'ULTRARIDE RUNNING(2).jpg', '2024-10-18 11:09:59'),
(438, 228, 'uploads/67124215aff51-ULTRARIDE RUNNING(3).jpg', 'ULTRARIDE RUNNING(3).jpg', '2024-10-18 11:10:13'),
(439, 228, 'uploads/671242203176c-ULTRARIDE RUNNING(4).jpg', 'ULTRARIDE RUNNING(4).jpg', '2024-10-18 11:10:24'),
(440, 229, 'uploads/6712428b16bc5-MIRAGE SPORT TECH UNISEX(1).jpg', 'MIRAGE SPORT TECH UNISEX(1).jpg', '2024-10-18 11:12:11'),
(441, 229, 'uploads/67124296c10bf-MIRAGE SPORT TECH UNISEX(2).jpg', 'MIRAGE SPORT TECH UNISEX(2).jpg', '2024-10-18 11:12:22'),
(442, 229, 'uploads/6712429fda44d-MIRAGE SPORT TECH UNISEX(3).jpg', 'MIRAGE SPORT TECH UNISEX(3).jpg', '2024-10-18 11:12:31'),
(443, 229, 'uploads/671242a8abc00-MIRAGE SPORT TECH UNISEX(4).jpg', 'MIRAGE SPORT TECH UNISEX(4).jpg', '2024-10-18 11:12:40'),
(444, 230, 'uploads/671242c07ff0b-ANZARUN FS 2.0(1).jpg', 'ANZARUN FS 2.0(1).jpg', '2024-10-18 11:13:04'),
(445, 230, 'uploads/671242ce32efc-ANZARUN FS 2.0(2).jpg', 'ANZARUN FS 2.0(2).jpg', '2024-10-18 11:13:18'),
(446, 230, 'uploads/671242d6bcd44-ANZARUN FS 2.0(3).jpg', 'ANZARUN FS 2.0(3).jpg', '2024-10-18 11:13:26'),
(447, 230, 'uploads/671242e00f6a3-ANZARUN FS 2.0(4).jpg', 'ANZARUN FS 2.0(4).jpg', '2024-10-18 11:13:36'),
(448, 231, 'uploads/671242f8b9d81-CLUB II YEAR OF SPORTS(1).jpg', 'CLUB II YEAR OF SPORTS(1).jpg', '2024-10-18 11:14:00'),
(449, 231, 'uploads/67124301410b9-CLUB II YEAR OF SPORTS(2).jpg', 'CLUB II YEAR OF SPORTS(2).jpg', '2024-10-18 11:14:09'),
(450, 231, 'uploads/6712430a30dfe-CLUB II YEAR OF SPORTS(3).jpg', 'CLUB II YEAR OF SPORTS(3).jpg', '2024-10-18 11:14:18'),
(451, 231, 'uploads/67124314e80ec-CLUB II YEAR OF SPORTS(4).jpg', 'CLUB II YEAR OF SPORTS(4).jpg', '2024-10-18 11:14:28'),
(452, 112, 'uploads/671244fc067f7-AIR MAX IMPACT 4(1).jpg', 'AIR MAX IMPACT 4(1).jpg', '2024-10-18 11:22:36'),
(453, 112, 'uploads/67124505d2ef2-AIR MAX IMPACT 4(2).jpg', 'AIR MAX IMPACT 4(2).jpg', '2024-10-18 11:22:45'),
(454, 112, 'uploads/6712450d466be-AIR MAX IMPACT 4(3).jpg', 'AIR MAX IMPACT 4(3).jpg', '2024-10-18 11:22:53'),
(455, 112, 'uploads/671245160626e-AIR MAX IMPACT 4(4).jpg', 'AIR MAX IMPACT 4(4).jpg', '2024-10-18 11:23:02'),
(456, 113, 'uploads/6712452fa1d83-JORDAN LUKA 2 PF(1).jpg', 'JORDAN LUKA 2 PF(1).jpg', '2024-10-18 11:23:27'),
(457, 113, 'uploads/671245376d37d-JORDAN LUKA 2 PF(2).jpg', 'JORDAN LUKA 2 PF(2).jpg', '2024-10-18 11:23:35'),
(458, 113, 'uploads/6712453fe816b-JORDAN LUKA 2 PF(3).jpg', 'JORDAN LUKA 2 PF(3).jpg', '2024-10-18 11:23:43'),
(459, 113, 'uploads/67124548174ff-JORDAN LUKA 2 PF(4).jpg', 'JORDAN LUKA 2 PF(4).jpg', '2024-10-18 11:23:52'),
(460, 114, 'uploads/6712455b501f6-JORDAN MAX AURA 5(1).jpg', 'JORDAN MAX AURA 5(1).jpg', '2024-10-18 11:24:11'),
(461, 114, 'uploads/671245b910459-JORDAN MAX AURA 5(2).jpg', 'JORDAN MAX AURA 5(2).jpg', '2024-10-18 11:25:45'),
(462, 114, 'uploads/671245c0b8cc0-JORDAN MAX AURA 5(3).jpg', 'JORDAN MAX AURA 5(3).jpg', '2024-10-18 11:25:52'),
(463, 114, 'uploads/671245c8b92f5-JORDAN MAX AURA 5(4).jpg', 'JORDAN MAX AURA 5(4).jpg', '2024-10-18 11:26:00'),
(464, 115, 'uploads/671245fe55e4d-JORDAN MVP (1).jpg', 'JORDAN MVP (1).jpg', '2024-10-18 11:26:54'),
(465, 115, 'uploads/67124606a6014-JORDAN MVP (2).jpg', 'JORDAN MVP (2).jpg', '2024-10-18 11:27:02'),
(466, 115, 'uploads/6712460f8e791-JORDAN MVP (3).jpg', 'JORDAN MVP (3).jpg', '2024-10-18 11:27:11'),
(467, 115, 'uploads/67124617e1185-JORDAN MVP (4).jpg', 'JORDAN MVP (4).jpg', '2024-10-18 11:27:19'),
(468, 116, 'uploads/6712462a666fc-VOMERO 1(1).jpg', 'VOMERO 1(1).jpg', '2024-10-18 11:27:38'),
(469, 116, 'uploads/67124632b9f03-VOMERO 1(2).jpg', 'VOMERO 1(2).jpg', '2024-10-18 11:27:46'),
(470, 116, 'uploads/6712463abb043-VOMERO 1(3).jpg', 'VOMERO 1(3).jpg', '2024-10-18 11:27:54'),
(471, 116, 'uploads/6712464354459-VOMERO 1(4).jpg', 'VOMERO 1(4).jpg', '2024-10-18 11:28:03'),
(472, 117, 'uploads/67124661bb182-JOURNEY  RUN(1).jpg', 'JOURNEY  RUN(1).jpg', '2024-10-18 11:28:33'),
(473, 117, 'uploads/6712466b07f2e-JOURNEY  RUN(2).jpg', 'JOURNEY  RUN(2).jpg', '2024-10-18 11:28:43'),
(474, 117, 'uploads/67124674a020b-JOURNEY  RUN(3).jpg', 'JOURNEY  RUN(3).jpg', '2024-10-18 11:28:52'),
(475, 117, 'uploads/6712467d6e70d-JOURNEY  RUN(4).jpg', 'JOURNEY  RUN(4).jpg', '2024-10-18 11:29:01'),
(476, 118, 'uploads/6712468f23bd6-MOTIVA(1).jpg', 'MOTIVA(1).jpg', '2024-10-18 11:29:19'),
(477, 118, 'uploads/67124699e2923-MOTIVA(2).jpg', 'MOTIVA(2).jpg', '2024-10-18 11:29:29'),
(478, 118, 'uploads/671246a341b9b-MOTIVA(3).jpg', 'MOTIVA(3).jpg', '2024-10-18 11:29:39'),
(479, 118, 'uploads/671246abe08e1-MOTIVA(4).jpg', 'MOTIVA(4).jpg', '2024-10-18 11:29:47'),
(480, 119, 'uploads/671246bd467f5-AIR ZOOM STRUCTURE(1).jpg', 'AIR ZOOM STRUCTURE(1).jpg', '2024-10-18 11:30:05'),
(481, 119, 'uploads/671246c603bcd-AIR ZOOM STRUCTURE(2).jpg', 'AIR ZOOM STRUCTURE(2).jpg', '2024-10-18 11:30:14'),
(482, 119, 'uploads/671246d09584c-AIR ZOOM STRUCTURE(3).jpg', 'AIR ZOOM STRUCTURE(3).jpg', '2024-10-18 11:30:24'),
(483, 119, 'uploads/671246d8d60bb-AIR ZOOM STRUCTURE(4).jpg', 'AIR ZOOM STRUCTURE(4).jpg', '2024-10-18 11:30:32'),
(484, 120, 'uploads/671246ebbc20f-RUN SWIFT 3(1).jpg', 'RUN SWIFT 3(1).jpg', '2024-10-18 11:30:51'),
(485, 120, 'uploads/671246f4e76bf-RUN SWIFT 3(2).jpg', 'RUN SWIFT 3(2).jpg', '2024-10-18 11:31:00'),
(486, 120, 'uploads/671246fd1ce24-RUN SWIFT 3(3).jpg', 'RUN SWIFT 3(3).jpg', '2024-10-18 11:31:09'),
(487, 120, 'uploads/671247073dc9b-RUN SWIFT 3(4).jpg', 'RUN SWIFT 3(4).jpg', '2024-10-18 11:31:19'),
(488, 121, 'uploads/671247170788d-AIR MAX SYSTEM(1).jpg', 'AIR MAX SYSTEM(1).jpg', '2024-10-18 11:31:35'),
(489, 121, 'uploads/6712471f0a91b-AIR MAX SYSTEM(2).jpg', 'AIR MAX SYSTEM(2).jpg', '2024-10-18 11:31:43'),
(490, 121, 'uploads/6712472724d10-AIR MAX SYSTEM(3).jpg', 'AIR MAX SYSTEM(3).jpg', '2024-10-18 11:31:51'),
(491, 121, 'uploads/6712472ed2b9b-AIR MAX SYSTEM(4).jpg', 'AIR MAX SYSTEM(4).jpg', '2024-10-18 11:31:58'),
(492, 612, 'uploads/67124e273b2ee-1440(1).jpg', '1440(1).jpg', '2024-10-18 12:01:43'),
(493, 612, 'uploads/67124e3289081-1440(2).jpg', '1440(2).jpg', '2024-10-18 12:01:54'),
(494, 612, 'uploads/67124e3b50a61-1440(3).jpg', '1440(3).jpg', '2024-10-18 12:02:03'),
(495, 612, 'uploads/67124e44db325-1440(4).jpg', '1440(4).jpg', '2024-10-18 12:02:12'),
(496, 613, 'uploads/67124e59d0610-574 S(1).jpg', '574 S(1).jpg', '2024-10-18 12:02:33'),
(497, 613, 'uploads/67124e62ee267-574 S(2).jpg', '574 S(2).jpg', '2024-10-18 12:02:42'),
(498, 613, 'uploads/67124e6c4e7f8-574 S(3).jpg', '574 S(3).jpg', '2024-10-18 12:02:52'),
(499, 613, 'uploads/67124e755ebb2-574 S(4).jpg', '574 S(4).jpg', '2024-10-18 12:03:01'),
(500, 614, 'uploads/67124e8727cd2-1080 V13(1).jpg', '1080 V13(1).jpg', '2024-10-18 12:03:19'),
(501, 614, 'uploads/67124e90ad23b-1080 V13(2).jpg', '1080 V13(2).jpg', '2024-10-18 12:03:28'),
(502, 614, 'uploads/67124e9a88a05-1080 V13(3).jpg', '1080 V13(3).jpg', '2024-10-18 12:03:38'),
(503, 614, 'uploads/67124ea400d99-1080 V13(4).jpg', '1080 V13(4).jpg', '2024-10-18 12:03:48'),
(504, 615, 'uploads/67124eb53701c-MORE TR MINDFUL(1).jpg', 'MORE TR MINDFUL(1).jpg', '2024-10-18 12:04:05'),
(505, 615, 'uploads/67124ebebbc80-MORE TR MINDFUL(2).jpg', 'MORE TR MINDFUL(2).jpg', '2024-10-18 12:04:14'),
(506, 615, 'uploads/67124ec86f729-MORE TR MINDFUL(3).jpg', 'MORE TR MINDFUL(3).jpg', '2024-10-18 12:04:24'),
(507, 615, 'uploads/67124ed49e76b-MORE TR MINDFUL(4).jpg', 'MORE TR MINDFUL(4).jpg', '2024-10-18 12:04:36'),
(508, 616, 'uploads/67124ee687cc9-880G(1).jpg', '880G(1).jpg', '2024-10-18 12:04:54'),
(509, 616, 'uploads/67124eef320ef-880G(2).jpg', '880G(2).jpg', '2024-10-18 12:05:03'),
(510, 616, 'uploads/67124ef84c2ca-880G(3).jpg', '880G(3).jpg', '2024-10-18 12:05:12'),
(511, 616, 'uploads/67124f00ab407-880G(4).jpg', '880G(4).jpg', '2024-10-18 12:05:20'),
(512, 617, 'uploads/67124f169edf4-997r(1).jpg', '997r(1).jpg', '2024-10-18 12:05:42'),
(513, 617, 'uploads/67124f2004627-997r(2).jpg', '997r(2).jpg', '2024-10-18 12:05:52'),
(514, 617, 'uploads/67124f28d25d6-997r(3).jpg', '997r(3).jpg', '2024-10-18 12:06:00'),
(515, 617, 'uploads/67124f32e7365-997r(4).jpg', '997r(4).jpg', '2024-10-18 12:06:10'),
(516, 618, 'uploads/67124f43eeefd-327(1).jpg', '327(1).jpg', '2024-10-18 12:06:27'),
(517, 618, 'uploads/67124f4f93ce4-327(2).jpg', '327(2).jpg', '2024-10-18 12:06:39'),
(518, 618, 'uploads/67124f58c7de9-327(3).jpg', '327(3).jpg', '2024-10-18 12:06:48'),
(519, 618, 'uploads/67124f62e3db4-327(4).jpg', '327(4).jpg', '2024-10-18 12:06:58'),
(520, 619, 'uploads/67124f74c0c16-520(1).jpg', '520(1).jpg', '2024-10-18 12:07:16'),
(521, 619, 'uploads/67124f7e82ce7-520(2).jpg', '520(2).jpg', '2024-10-18 12:07:26'),
(524, 620, 'uploads/67124f9cf0a6f-430(1).jpg', '430(1).jpg', '2024-10-18 12:07:56'),
(525, 620, 'uploads/67124fa5b3d58-430(2).jpg', '430(2).jpg', '2024-10-18 12:08:05'),
(526, 620, 'uploads/67124fae22c65-430(3).jpg', '430(3).jpg', '2024-10-18 12:08:14'),
(527, 620, 'uploads/67124fb713760-430(4).jpg', '430(4).jpg', '2024-10-18 12:08:23'),
(531, 622, 'uploads/6712542262d5b-WMNS 997R(1).webp', 'WMNS 997R(1).webp', '2024-10-18 12:27:14'),
(578, 123, 'uploads/AIR FORCE 1 \'07(1).webp', NULL, '2024-10-20 15:07:31'),
(579, 123, 'uploads/AIR FORCE 1 \'07(2).webp', NULL, '2024-10-20 15:07:31'),
(580, 123, 'uploads/AIR FORCE 1 \'07(3).webp', NULL, '2024-10-20 15:07:31'),
(581, 123, 'uploads/AIR FORCE 1 \'07(4).webp', NULL, '2024-10-20 15:07:31'),
(582, 124, 'uploads/AIR MAX 1 \'87(1).webp', NULL, '2024-10-20 15:07:31'),
(583, 124, 'uploads/AIR MAX 1 \'87(2).webp', NULL, '2024-10-20 15:07:31'),
(584, 124, 'uploads/AIR MAX 1 \'87(3).webp', NULL, '2024-10-20 15:07:31'),
(585, 124, 'uploads/AIR MAX 1 \'87(4).webp', NULL, '2024-10-20 15:07:31'),
(586, 122, 'uploads/BLAZER LOW \'77 VINTAGE(1).webp', NULL, '2024-10-20 15:07:31'),
(587, 122, 'uploads/BLAZER LOW \'77 VINTAGE(2).webp', NULL, '2024-10-20 15:07:31'),
(588, 122, 'uploads/BLAZER LOW \'77 VINTAGE(3).webp', NULL, '2024-10-20 15:07:31'),
(589, 122, 'uploads/BLAZER LOW \'77 VINTAGE(4).webp', NULL, '2024-10-20 15:07:31'),
(590, 129, 'uploads/WMNS AIR MAX 97(1).jpg', NULL, '2024-10-20 15:07:31'),
(591, 129, 'uploads/WMNS AIR MAX 97(2).jpg', NULL, '2024-10-20 15:07:31'),
(592, 129, 'uploads/WMNS AIR MAX 97(3).jpg', NULL, '2024-10-20 15:07:31'),
(593, 129, 'uploads/WMNS AIR MAX 97(4).jpg', NULL, '2024-10-20 15:07:31'),
(594, 125, 'uploads/WMNS AIR MAX EXCEE(1).jpg', NULL, '2024-10-20 15:07:31'),
(595, 125, 'uploads/WMNS AIR MAX EXCEE(2).jpg', NULL, '2024-10-20 15:07:31'),
(596, 125, 'uploads/WMNS AIR MAX EXCEE(3).jpg', NULL, '2024-10-20 15:07:31'),
(597, 125, 'uploads/WMNS AIR MAX EXCEE(4).jpg', NULL, '2024-10-20 15:07:31'),
(598, 131, 'uploads/WMNS GAMMA FORCE(1).jpg', NULL, '2024-10-20 15:07:31'),
(599, 131, 'uploads/WMNS GAMMA FORCE(2).jpg', NULL, '2024-10-20 15:07:31'),
(600, 131, 'uploads/WMNS GAMMA FORCE(3).jpg', NULL, '2024-10-20 15:07:31'),
(601, 131, 'uploads/WMNS GAMMA FORCE(4).jpg', NULL, '2024-10-20 15:07:31'),
(602, 128, 'uploads/WMNS W BLAZER LOW \'77 JUMBO(1).jpg', NULL, '2024-10-20 15:07:31'),
(603, 128, 'uploads/WMNS W BLAZER LOW \'77 JUMBO(2).jpg', NULL, '2024-10-20 15:07:31'),
(604, 128, 'uploads/WMNS W BLAZER LOW \'77 JUMBO(3).jpg', NULL, '2024-10-20 15:07:31'),
(605, 128, 'uploads/WMNS W BLAZER LOW \'77 JUMBO(4).jpg', NULL, '2024-10-20 15:07:31'),
(606, 126, 'uploads/WMNS W BLAZER LOW PLATFORM(1).jpg', NULL, '2024-10-20 15:07:31'),
(607, 126, 'uploads/WMNS W BLAZER LOW PLATFORM(2).jpg', NULL, '2024-10-20 15:07:31'),
(608, 126, 'uploads/WMNS W BLAZER LOW PLATFORM(3).jpg', NULL, '2024-10-20 15:07:31'),
(609, 126, 'uploads/WMNS W BLAZER LOW PLATFORM(4).jpg', NULL, '2024-10-20 15:07:31'),
(610, 127, 'uploads/WMNS W COURT VIDSION LO(1).jpg', NULL, '2024-10-20 15:07:31'),
(611, 127, 'uploads/WMNS W COURT VIDSION LO(2).jpg', NULL, '2024-10-20 15:07:31'),
(612, 127, 'uploads/WMNS W COURT VIDSION LO(3).jpg', NULL, '2024-10-20 15:07:31'),
(613, 127, 'uploads/WMNS W COURT VIDSION LO(4).jpg', NULL, '2024-10-20 15:07:31'),
(614, 130, 'uploads/WMNS W METCON 8(1).jpg', NULL, '2024-10-20 15:07:31'),
(615, 130, 'uploads/WMNS W METCON 8(2).jpg', NULL, '2024-10-20 15:07:31'),
(616, 417, 'uploads/BREAKNET 2.0(1).jpg', NULL, '2024-10-20 15:27:02'),
(617, 417, 'uploads/BREAKNET 2.0(2).jpg', NULL, '2024-10-20 15:27:02'),
(618, 417, 'uploads/BREAKNET 2.0(3).jpg', NULL, '2024-10-20 15:27:02'),
(619, 417, 'uploads/BREAKNET 2.0(4).jpg', NULL, '2024-10-20 15:27:02'),
(620, 411, 'uploads/KANTANA (1).jpg', NULL, '2024-10-20 15:27:02'),
(621, 411, 'uploads/KANTANA(2).jpg', NULL, '2024-10-20 15:27:02'),
(622, 411, 'uploads/KANTANA(3).jpg', NULL, '2024-10-20 15:27:02'),
(623, 411, 'uploads/KANTANA(4).jpg', NULL, '2024-10-20 15:27:02'),
(624, 418, 'uploads/PURECOMFORT(1).jpg', NULL, '2024-10-20 15:27:03'),
(625, 418, 'uploads/PURECOMFORT(2).jpg', NULL, '2024-10-20 15:27:03'),
(626, 418, 'uploads/PURECOMFORT(3).jpg', NULL, '2024-10-20 15:27:03'),
(627, 418, 'uploads/PURECOMFORT(4).jpg', NULL, '2024-10-20 15:27:03'),
(628, 416, 'uploads/WMNS ALPHARESPONSE(1).jpg', NULL, '2024-10-20 15:27:03'),
(629, 416, 'uploads/WMNS ALPHARESPONSE(2).jpg', NULL, '2024-10-20 15:27:03'),
(630, 416, 'uploads/WMNS ALPHARESPONSE(3).jpg', NULL, '2024-10-20 15:27:03'),
(631, 416, 'uploads/WMNS ALPHARESPONSE(4).jpg', NULL, '2024-10-20 15:27:03'),
(632, 414, 'uploads/WMNS BRAVADA 2.0(1).jpg', NULL, '2024-10-20 15:27:03'),
(633, 414, 'uploads/WMNS BRAVADA 2.0(2).jpg', NULL, '2024-10-20 15:27:03'),
(634, 414, 'uploads/WMNS BRAVADA 2.0(3).jpg', NULL, '2024-10-20 15:27:03'),
(635, 414, 'uploads/WMNS BRAVADA 2.0(4).jpg', NULL, '2024-10-20 15:27:03'),
(636, 415, 'uploads/WMNS GRAND COURT 2.0(1).jpg', NULL, '2024-10-20 15:27:03'),
(637, 415, 'uploads/WMNS GRAND COURT 2.0(2).jpg', NULL, '2024-10-20 15:27:03'),
(638, 415, 'uploads/WMNS GRAND COURT 2.0(3).jpg', NULL, '2024-10-20 15:27:03'),
(639, 415, 'uploads/WMNS GRAND COURT 2.0(64).jpg', NULL, '2024-10-20 15:27:03'),
(640, 413, 'uploads/WMNS RACER TR21(1).jpg', NULL, '2024-10-20 15:27:03'),
(641, 413, 'uploads/WMNS RACER TR21(2).jpg', NULL, '2024-10-20 15:27:03'),
(642, 412, 'uploads/ZX 2K BOOST 2.0(1).webp', NULL, '2024-10-20 15:27:03'),
(643, 412, 'uploads/ZX 2K BOOST 2.0(2).webp', NULL, '2024-10-20 15:27:03'),
(644, 412, 'uploads/ZX 2K BOOST 2.0(3).webp', NULL, '2024-10-20 15:27:03'),
(645, 412, 'uploads/ZX 2K BOOST 2.0(4).webp', NULL, '2024-10-20 15:27:03'),
(646, 423, 'uploads/BARRICADE 13 M(1).jpg', NULL, '2024-10-20 15:35:44'),
(647, 423, 'uploads/BARRICADE 13 M(2).jpg', NULL, '2024-10-20 15:35:44'),
(648, 423, 'uploads/BARRICADE 13 M(3).jpg', NULL, '2024-10-20 15:35:44'),
(649, 423, 'uploads/BARRICADE 13 M(4).jpg', NULL, '2024-10-20 15:35:44'),
(650, 421, 'uploads/COURUN AVANT M RUNNING(1).jpg', NULL, '2024-10-20 15:35:44'),
(651, 421, 'uploads/COURUN AVANT M RUNNING(2).jpg', NULL, '2024-10-20 15:35:44'),
(652, 421, 'uploads/COURUN AVANT M RUNNING(3).jpg', NULL, '2024-10-20 15:35:44'),
(653, 421, 'uploads/COURUN AVANT M RUNNING(4).jpg', NULL, '2024-10-20 15:35:44'),
(654, 419, 'uploads/FLUIDFLOW 3.0(1).jpg', NULL, '2024-10-20 15:35:44'),
(655, 419, 'uploads/FLUIDFLOW 3.0(2).jpg', NULL, '2024-10-20 15:35:44'),
(656, 419, 'uploads/FLUIDFLOW 3.0(3).jpg', NULL, '2024-10-20 15:35:44'),
(657, 419, 'uploads/FLUIDFLOW 3.0(4).jpg', NULL, '2024-10-20 15:35:44'),
(658, 424, 'uploads/IVP ULTRA BOOST OG(1).jpg', NULL, '2024-10-20 15:35:44'),
(659, 424, 'uploads/IVP ULTRA BOOST OG(2).jpg', NULL, '2024-10-20 15:35:44'),
(660, 424, 'uploads/IVP ULTRA BOOST OG(3).jpg', NULL, '2024-10-20 15:35:44'),
(661, 424, 'uploads/IVP ULTRA BOOST OG(4).jpg', NULL, '2024-10-20 15:35:44'),
(662, 420, 'uploads/RESPONSE RUNNING(1).jpg', NULL, '2024-10-20 15:35:44'),
(663, 420, 'uploads/RESPONSE RUNNING(2).jpg', NULL, '2024-10-20 15:35:44'),
(664, 420, 'uploads/RESPONSE RUNNING(3).jpg', NULL, '2024-10-20 15:35:44'),
(665, 420, 'uploads/RESPONSE RUNNING(4).jpg', NULL, '2024-10-20 15:35:44'),
(666, 426, 'uploads/SWITCH FWD M(1).jpg', NULL, '2024-10-20 15:35:44'),
(667, 426, 'uploads/SWITCH FWD M(2).jpg', NULL, '2024-10-20 15:35:44'),
(668, 426, 'uploads/SWITCH FWD M(3).jpg', NULL, '2024-10-20 15:35:44'),
(669, 426, 'uploads/SWITCH FWD M(4).jpg', NULL, '2024-10-20 15:35:44'),
(670, 425, 'uploads/SWITCH MOVE U(1).jpg', NULL, '2024-10-20 15:35:44'),
(671, 425, 'uploads/SWITCH MOVE U(2).jpg', NULL, '2024-10-20 15:35:44'),
(672, 425, 'uploads/SWITCH MOVE U(3).jpg', NULL, '2024-10-20 15:35:44'),
(673, 425, 'uploads/SWITCH MOVE U(4).jpg', NULL, '2024-10-20 15:35:44'),
(674, 422, 'uploads/X_PLRBOOST(1).jpg', NULL, '2024-10-20 15:35:44'),
(675, 422, 'uploads/X_PLRBOOST(2).jpg', NULL, '2024-10-20 15:35:44'),
(676, 422, 'uploads/X_PLRBOOST(3).jpg', NULL, '2024-10-20 15:43:02'),
(677, 422, 'uploads/X_PLRBOOST(4).jpg', NULL, '2024-10-20 15:43:02'),
(678, 514, 'uploads/WMN\'S CHUCK 70 PLUS X-HI(1).webp', NULL, '2024-10-20 15:49:54'),
(679, 514, 'uploads/WMN\'S CHUCK 70 PLUS X-HI(2).webp', NULL, '2024-10-20 15:49:54'),
(680, 514, 'uploads/WMN\'S CHUCK 70 PLUS X-HI(3).webp', NULL, '2024-10-20 15:49:54'),
(681, 514, 'uploads/WMN\'S CHUCK 70 PLUS X-HI(4).webp', NULL, '2024-10-20 15:49:54'),
(682, 520, 'uploads/WMN\'S CHUCK TAYLOR ALL STAR MOVE PLATFORM(1).webp', NULL, '2024-10-20 15:49:54'),
(683, 520, 'uploads/WMN\'S CHUCK TAYLOR ALL STAR MOVE PLATFORM(2).webp', NULL, '2024-10-20 15:49:54'),
(684, 520, 'uploads/WMN\'S CHUCK TAYLOR ALL STAR MOVE PLATFORM(3).webp', NULL, '2024-10-20 15:49:54'),
(685, 520, 'uploads/WMN\'S CHUCK TAYLOR ALL STAR MOVE PLATFORM(4).webp', NULL, '2024-10-20 15:49:54'),
(686, 518, 'uploads/WMN\'S RUN STAR LEGACY CX SEASONAL COLOR(1).webp', NULL, '2024-10-20 15:49:54'),
(687, 518, 'uploads/WMN\'S RUN STAR LEGACY CX SEASONAL COLOR(2).webp', NULL, '2024-10-20 15:49:54'),
(688, 518, 'uploads/WMN\'S RUN STAR LEGACY CX SEASONAL COLOR(3).webp', NULL, '2024-10-20 15:49:54'),
(689, 518, 'uploads/WMN\'S RUN STAR LEGACY CX SEASONAL COLOR(4).webp', NULL, '2024-10-20 15:49:54'),
(690, 516, 'uploads/WMNS CHUCK 70 AT-CX FUTURE COMFORT(1).webp', NULL, '2024-10-20 15:49:54'),
(691, 516, 'uploads/WMNS CHUCK 70 AT-CX FUTURE COMFORT(2).webp', NULL, '2024-10-20 15:49:54'),
(692, 516, 'uploads/WMNS CHUCK 70 AT-CX FUTURE COMFORT(3).webp', NULL, '2024-10-20 15:49:54'),
(693, 516, 'uploads/WMNS CHUCK 70 AT-CX FUTURE COMFORT(4).webp', NULL, '2024-10-20 15:49:54'),
(694, 517, 'uploads/WMNS CHUCK 70 SEASONAL COLOR(1).webp', NULL, '2024-10-20 15:49:54'),
(695, 517, 'uploads/WMNS CHUCK 70 SEASONAL COLOR(2).webp', NULL, '2024-10-20 15:49:54'),
(696, 517, 'uploads/WMNS CHUCK 70 SEASONAL COLOR(3).webp', NULL, '2024-10-20 15:49:54'),
(697, 517, 'uploads/WMNS CHUCK 70 SEASONAL COLOR(4).webp', NULL, '2024-10-20 15:49:54'),
(698, 515, 'uploads/WMNS CHUCK 70 SEASONAL(1).webp', NULL, '2024-10-20 15:49:54'),
(699, 515, 'uploads/WMNS CHUCK 70 SEASONAL(2).webp', NULL, '2024-10-20 15:49:54'),
(700, 515, 'uploads/WMNS CHUCK 70 SEASONAL(3).webp', NULL, '2024-10-20 15:49:54'),
(701, 515, 'uploads/WMNS CHUCK 70 SEASONAL(4).webp', NULL, '2024-10-20 15:49:54'),
(702, 521, 'uploads/WMNS CHUCK TAYLOR ALL STAR RAVE(1).webp', NULL, '2024-10-20 15:49:54'),
(703, 521, 'uploads/WMNS CHUCK TAYLOR ALL STAR RAVE(2).webp', NULL, '2024-10-20 15:49:54'),
(704, 521, 'uploads/WMNS CHUCK TAYLOR ALL STAR RAVE(3).webp', NULL, '2024-10-20 15:49:54'),
(705, 521, 'uploads/WMNS CHUCK TAYLOR ALL STAR RAVE(4).webp', NULL, '2024-10-20 15:49:54'),
(706, 519, 'uploads/WMNS RUN STAR HIKE PLATFORM(1).webp', NULL, '2024-10-20 15:49:54'),
(707, 519, 'uploads/WMNS RUN STAR HIKE PLATFORM(2).webp', NULL, '2024-10-20 15:49:54'),
(708, 519, 'uploads/WMNS RUN STAR HIKE PLATFORM(3).webp', NULL, '2024-10-20 15:49:54'),
(709, 519, 'uploads/WMNS RUN STAR HIKE PLATFORM(4).webp', NULL, '2024-10-20 15:49:54'),
(710, 513, 'uploads/x TRANSFORMERS CHUCK TAYLOR ALL STAR AUTOBOTS(1).webp', NULL, '2024-10-20 15:49:54'),
(711, 513, 'uploads/x TRANSFORMERS CHUCK TAYLOR ALL STAR AUTOBOTS(2).webp', NULL, '2024-10-20 15:49:54'),
(712, 513, 'uploads/x TRANSFORMERS CHUCK TAYLOR ALL STAR AUTOBOTS(3).webp', NULL, '2024-10-20 15:49:54'),
(713, 513, 'uploads/x TRANSFORMERS CHUCK TAYLOR ALL STAR AUTOBOTS(4).webp', NULL, '2024-10-20 15:49:54'),
(714, 713, 'uploads/WMN\'S CL NYLON(1).webp', NULL, '2024-10-20 16:01:28'),
(715, 713, 'uploads/WMN\'S CL NYLON(2).webp', NULL, '2024-10-20 16:01:28'),
(716, 713, 'uploads/WMN\'S CL NYLON(3).webp', NULL, '2024-10-20 16:01:28'),
(717, 716, 'uploads/WMN\'S CLASSIC LEATHER SP EXTRA(1).webp', NULL, '2024-10-20 16:01:28'),
(718, 716, 'uploads/WMN\'S CLASSIC LEATHER SP EXTRA(2).webp', NULL, '2024-10-20 16:01:28'),
(719, 716, 'uploads/WMN\'S CLASSIC LEATHER SP EXTRA(3).webp', NULL, '2024-10-20 16:01:28'),
(720, 711, 'uploads/WMN\'S CLASSIC LEATHER(1).webp', NULL, '2024-10-20 16:01:28'),
(721, 711, 'uploads/WMN\'S CLASSIC LEATHER(2).webp', NULL, '2024-10-20 16:01:28'),
(722, 711, 'uploads/WMN\'S CLASSIC LEATHER(3).webp', NULL, '2024-10-20 16:01:28'),
(723, 711, 'uploads/WMN\'S CLASSIC LEATHER(4).webp', NULL, '2024-10-20 16:01:28'),
(724, 712, 'uploads/WMN\'S CLUB C 85(1).webp', NULL, '2024-10-20 16:01:28'),
(725, 712, 'uploads/WMN\'S CLUB C 85(2).webp', NULL, '2024-10-20 16:01:28'),
(726, 712, 'uploads/WMN\'S CLUB C 85(3).webp', NULL, '2024-10-20 16:01:28'),
(727, 712, 'uploads/WMN\'S CLUB C 85(4).webp', NULL, '2024-10-20 16:01:28'),
(728, 715, 'uploads/WMN\'S CLUB C GEO MID(1).webp', NULL, '2024-10-20 16:01:28'),
(729, 715, 'uploads/WMN\'S CLUB C GEO MID(2).webp', NULL, '2024-10-20 16:01:28'),
(730, 715, 'uploads/WMN\'S CLUB C GEO MID(3).webp', NULL, '2024-10-20 16:01:28'),
(731, 715, 'uploads/WMN\'S CLUB C GEO MID(4).webp', NULL, '2024-10-20 16:01:28'),
(732, 714, 'uploads/WMN\'S F S HI CLASSICS(1).webp', NULL, '2024-10-20 16:01:28'),
(733, 714, 'uploads/WMN\'S F S HI CLASSICS(2).webp', NULL, '2024-10-20 16:01:28'),
(734, 714, 'uploads/WMN\'S F S HI CLASSICS(3).webp', NULL, '2024-10-20 16:01:28'),
(735, 714, 'uploads/WMN\'S F S HI CLASSICS(4).webp', NULL, '2024-10-20 16:01:28'),
(736, 702, 'uploads/BB 4000 II(1).webp', NULL, '2024-10-20 16:10:28'),
(737, 702, 'uploads/BB 4000 II(2).webp', NULL, '2024-10-20 16:10:28'),
(738, 702, 'uploads/BB 4000 II(3).webp', NULL, '2024-10-20 16:10:28'),
(739, 702, 'uploads/BB 4000 II(4).webp', NULL, '2024-10-20 16:10:28'),
(740, 708, 'uploads/CLASSIC LEARHER HEXALITE +(1).webp', NULL, '2024-10-20 16:10:28'),
(741, 708, 'uploads/CLASSIC LEARHER HEXALITE +(2).webp', NULL, '2024-10-20 16:10:28'),
(742, 708, 'uploads/CLASSIC LEARHER HEXALITE +(3).webp', NULL, '2024-10-20 16:10:28'),
(743, 708, 'uploads/CLASSIC LEARHER HEXALITE +(4).webp', NULL, '2024-10-20 16:10:28'),
(744, 703, 'uploads/CLASSIC LEATHER(1.webp', NULL, '2024-10-20 16:10:28'),
(745, 703, 'uploads/CLASSIC LEATHER(2).webp', NULL, '2024-10-20 16:10:28'),
(746, 703, 'uploads/CLASSIC LEATHER(3).webp', NULL, '2024-10-20 16:10:28'),
(747, 703, 'uploads/CLASSIC LEATHER(4).webp', NULL, '2024-10-20 16:10:28'),
(748, 704, 'uploads/CLASSIC NYLON PLUS(1).webp', NULL, '2024-10-20 16:10:28'),
(749, 704, 'uploads/CLASSIC NYLON PLUS(2).webp', NULL, '2024-10-20 16:10:28'),
(750, 704, 'uploads/CLASSIC NYLON PLUS(3).webp', NULL, '2024-10-20 16:10:28'),
(751, 704, 'uploads/CLASSIC NYLON PLUS(4).webp', NULL, '2024-10-20 16:10:28'),
(752, 701, 'uploads/CLUB C REVENGE VINTAGE(1).webp', NULL, '2024-10-20 16:10:28'),
(753, 701, 'uploads/CLUB C REVENGE VINTAGE(2).webp', NULL, '2024-10-20 16:10:28'),
(754, 701, 'uploads/CLUB C REVENGE VINTAGE(3).webp', NULL, '2024-10-20 16:10:28'),
(755, 701, 'uploads/CLUB C REVENGE VINTAGE(4).webp', NULL, '2024-10-20 16:10:28'),
(756, 710, 'uploads/EAMES CLASSIC LEATHER(1).webp', NULL, '2024-10-20 16:10:28'),
(757, 710, 'uploads/EAMES CLASSIC LEATHER(2).webp', NULL, '2024-10-20 16:10:28'),
(758, 710, 'uploads/EAMES CLASSIC LEATHER(3).webp', NULL, '2024-10-20 16:10:28'),
(759, 710, 'uploads/EAMES CLASSIC LEATHER(4).webp', NULL, '2024-10-20 16:10:28'),
(760, 706, 'uploads/LT COURT(1).webp', NULL, '2024-10-20 16:10:28'),
(761, 706, 'uploads/LT COURT(2).webp', NULL, '2024-10-20 16:10:28'),
(762, 706, 'uploads/LT COURT(3).webp', NULL, '2024-10-20 16:10:28'),
(763, 706, 'uploads/LT COURT(4).webp', NULL, '2024-10-20 16:10:28'),
(764, 709, 'uploads/PANINI QUESTION MID(1).webp', NULL, '2024-10-20 16:10:28'),
(765, 709, 'uploads/PANINI QUESTION MID(2).webp', NULL, '2024-10-20 16:10:28'),
(766, 709, 'uploads/PANINI QUESTION MID(3).webp', NULL, '2024-10-20 16:10:28'),
(767, 709, 'uploads/PANINI QUESTION MID(4).webp', NULL, '2024-10-20 16:10:28'),
(768, 705, 'uploads/QUESTION MID(1).webp', NULL, '2024-10-20 16:10:28'),
(769, 705, 'uploads/QUESTION MID(2).webp', NULL, '2024-10-20 16:10:28'),
(770, 705, 'uploads/QUESTION MID(3).webp', NULL, '2024-10-20 16:10:28'),
(771, 705, 'uploads/QUESTION MID(4).webp', NULL, '2024-10-20 16:10:28'),
(772, 719, 'uploads/COURTFLEX M White(1).jpg', NULL, '2024-10-20 16:15:41'),
(773, 719, 'uploads/COURTFLEX M White(2).jpg', NULL, '2024-10-20 16:15:41'),
(774, 719, 'uploads/COURTFLEX M White(3).jpg', NULL, '2024-10-20 16:15:41'),
(775, 719, 'uploads/COURTFLEX M White(4).jpg', NULL, '2024-10-20 16:15:41'),
(776, 718, 'uploads/Craze Runner M Vectornavy Smokyindi (1).jpg', NULL, '2024-10-20 16:15:41'),
(777, 718, 'uploads/Craze Runner M Vectornavy Smokyindi (2).jpg', NULL, '2024-10-20 16:15:41'),
(778, 718, 'uploads/Craze Runner M Vectornavy Smokyindi (3).jpg', NULL, '2024-10-20 16:15:41'),
(779, 718, 'uploads/Craze Runner M Vectornavy Smokyindi (4).jpg', NULL, '2024-10-20 16:15:41'),
(780, 723, 'uploads/Liquifect 90 (1).jpg', NULL, '2024-10-20 16:15:41'),
(781, 723, 'uploads/Liquifect 90 (2).jpg', NULL, '2024-10-20 16:15:41'),
(782, 723, 'uploads/Liquifect 90 (3).jpg', NULL, '2024-10-20 16:15:41'),
(783, 723, 'uploads/Liquifect 90 (4).jpg', NULL, '2024-10-20 16:15:41'),
(784, 721, 'uploads/MAINLAND M(1).jpg', NULL, '2024-10-20 16:15:41'),
(785, 721, 'uploads/MAINLAND M(2).jpg', NULL, '2024-10-20 16:15:41'),
(786, 721, 'uploads/MAINLAND M(3).jpg', NULL, '2024-10-20 16:15:41'),
(787, 721, 'uploads/MAINLAND M(4).jpg', NULL, '2024-10-20 16:15:41'),
(788, 720, 'uploads/Rmsora1640 (1).jpg', NULL, '2024-10-20 16:15:41'),
(789, 720, 'uploads/Rmsora1640 (2).jpg', NULL, '2024-10-20 16:15:41'),
(790, 720, 'uploads/Rmsora1640 (3).jpg', NULL, '2024-10-20 16:15:41'),
(791, 720, 'uploads/Rmsora1640 (4).jpg', NULL, '2024-10-20 16:15:41'),
(792, 717, 'uploads/TRUE COURT(1).jpg', NULL, '2024-10-20 16:15:41'),
(793, 717, 'uploads/TRUE COURT(2).jpg', NULL, '2024-10-20 16:15:41'),
(794, 717, 'uploads/TRUE COURT(3).jpg', NULL, '2024-10-20 16:15:41'),
(795, 717, 'uploads/TRUE COURT(4).jpg', NULL, '2024-10-20 16:15:41'),
(796, 722, 'uploads/Zig Elusion Energy(1).jpg', NULL, '2024-10-20 16:15:41'),
(797, 722, 'uploads/Zig Elusion Energy(2).jpg', NULL, '2024-10-20 16:15:42'),
(798, 722, 'uploads/Zig Elusion Energy(3).jpg', NULL, '2024-10-20 16:15:42'),
(799, 722, 'uploads/Zig Elusion Energy(4).jpg', NULL, '2024-10-20 16:15:42'),
(800, 234, 'uploads/LEADCAT 2.0 BB LAVA(1).webp', NULL, '2024-10-20 16:22:25'),
(801, 234, 'uploads/LEADCAT 2.0 BB LAVA(2).webp', NULL, '2024-10-20 16:22:25'),
(802, 234, 'uploads/LEADCAT 2.0 BB LAVA(3).webp', NULL, '2024-10-20 16:22:25'),
(803, 234, 'uploads/LEADCAT 2.0 BB LAVA(4).webp', NULL, '2024-10-20 16:22:25'),
(804, 236, 'uploads/MAPF1 Leadcat 2.0 Logo IN (1).jpg', NULL, '2024-10-20 16:22:25'),
(805, 236, 'uploads/MAPF1 Leadcat 2.0 Logo IN (2).jpg', NULL, '2024-10-20 16:22:25'),
(806, 236, 'uploads/MAPF1 Leadcat 2.0 Logo IN (3).jpg', NULL, '2024-10-20 16:22:25'),
(807, 236, 'uploads/MAPF1 Leadcat 2.0 Logo IN (4).jpg', NULL, '2024-10-20 16:22:25'),
(808, 235, 'uploads/Marine Slide(1).jpg', NULL, '2024-10-20 16:22:25'),
(809, 235, 'uploads/Marine Slide(2).jpg', NULL, '2024-10-20 16:22:25'),
(810, 235, 'uploads/Marine Slide(3).jpg', NULL, '2024-10-20 16:22:25'),
(811, 235, 'uploads/Marine Slide(4).jpg', NULL, '2024-10-20 16:22:25'),
(812, 233, 'uploads/MB.03 SLIDE(1).webp', NULL, '2024-10-20 16:22:25'),
(813, 233, 'uploads/MB.03 SLIDE(2).webp', NULL, '2024-10-20 16:22:25'),
(814, 233, 'uploads/MB.03 SLIDE(3).webp', NULL, '2024-10-20 16:22:25'),
(815, 233, 'uploads/MB.03 SLIDE(4).webp', NULL, '2024-10-20 16:22:25'),
(816, 237, 'uploads/Royal Challengers Bangalore (1).jpg', NULL, '2024-10-20 16:22:25'),
(817, 237, 'uploads/Royal Challengers Bangalore (2).jpg', NULL, '2024-10-20 16:22:25'),
(818, 237, 'uploads/Royal Challengers Bangalore (3).jpg', NULL, '2024-10-20 16:22:25'),
(819, 237, 'uploads/Royal Challengers Bangalore (4).jpg', NULL, '2024-10-20 16:22:25'),
(820, 232, 'uploads/SHIBUI CAT(1).webp', NULL, '2024-10-20 16:22:25'),
(821, 232, 'uploads/SHIBUI CAT(2).webp', NULL, '2024-10-20 16:22:25'),
(822, 232, 'uploads/SHIBUI CAT(3).webp', NULL, '2024-10-20 16:22:25'),
(823, 232, 'uploads/SHIBUI CAT(4).webp', NULL, '2024-10-20 16:22:25'),
(824, 136, 'uploads/AIR MORE UPTEMPO(1).webp', NULL, '2024-10-20 16:41:04'),
(825, 136, 'uploads/AIR MORE UPTEMPO(2).webp', NULL, '2024-10-20 16:41:04'),
(826, 136, 'uploads/AIR MORE UPTEMPO(3).webp', NULL, '2024-10-20 16:41:04'),
(827, 136, 'uploads/AIR MORE UPTEMPO(4).webp', NULL, '2024-10-20 16:41:04'),
(828, 134, 'uploads/CALM SANDALS(1).webp', NULL, '2024-10-20 16:41:04'),
(829, 134, 'uploads/CALM SANDALS(2).webp', NULL, '2024-10-20 16:41:04'),
(830, 134, 'uploads/CALM SANDALS(3).webp', NULL, '2024-10-20 16:41:04'),
(831, 134, 'uploads/CALM SANDALS(4).webp', NULL, '2024-10-20 16:41:04'),
(832, 133, 'uploads/CALM(1).webp', NULL, '2024-10-20 16:41:04'),
(833, 133, 'uploads/CALM(2).webp', NULL, '2024-10-20 16:41:04'),
(834, 133, 'uploads/CALM(3).webp', NULL, '2024-10-20 16:41:04'),
(835, 133, 'uploads/CALM(4).webp', NULL, '2024-10-20 16:41:04'),
(836, 135, 'uploads/OFFCOURT ADJUST(1).webp', NULL, '2024-10-20 16:41:04'),
(837, 135, 'uploads/OFFCOURT ADJUST(2).webp', NULL, '2024-10-20 16:41:04'),
(838, 135, 'uploads/OFFCOURT ADJUST(3).webp', NULL, '2024-10-20 16:41:04'),
(839, 135, 'uploads/OFFCOURT ADJUST(4).webp', NULL, '2024-10-20 16:41:04'),
(840, 137, 'uploads/OFFCOURT(1).webp', NULL, '2024-10-20 16:41:04'),
(841, 137, 'uploads/OFFCOURT(2).webp', NULL, '2024-10-20 16:41:04'),
(842, 137, 'uploads/OFFCOURT(3).webp', NULL, '2024-10-20 16:41:04'),
(843, 137, 'uploads/OFFCOURT(4).webp', NULL, '2024-10-20 16:41:04'),
(844, 132, 'uploads/VICTORI ONE(1).webp', NULL, '2024-10-20 16:41:04'),
(845, 132, 'uploads/VICTORI ONE(2).webp', NULL, '2024-10-20 16:41:04'),
(846, 132, 'uploads/VICTORI ONE(3).webp', NULL, '2024-10-20 16:41:04'),
(847, 132, 'uploads/VICTORI ONE(4).webp', NULL, '2024-10-20 16:41:04'),
(848, 724, 'uploads/CLASSICS BEATNIK(1).webp', NULL, '2024-10-20 16:41:04'),
(849, 724, 'uploads/CLASSICS BEATNIK(2).webp', NULL, '2024-10-20 16:41:04'),
(850, 724, 'uploads/CLASSICS BEATNIK(3).webp', NULL, '2024-10-20 16:41:04'),
(851, 724, 'uploads/CLASSICS BEATNIK(4).webp', NULL, '2024-10-20 16:41:04'),
(852, 725, 'uploads/RBK Fulgere(1).jpg', NULL, '2024-10-20 16:41:04'),
(853, 725, 'uploads/RBK Fulgere(2).jpg', NULL, '2024-10-20 16:41:04'),
(854, 725, 'uploads/RBK Fulgere(3).jpg', NULL, '2024-10-20 16:41:04'),
(855, 725, 'uploads/RBK Fulgere(4).jpg', NULL, '2024-10-20 16:41:04'),
(856, 726, 'uploads/Rise Slide U Open(1).jpg', NULL, '2024-10-20 16:41:04'),
(857, 726, 'uploads/Rise Slide U Open(2).jpg', NULL, '2024-10-20 16:41:04'),
(858, 726, 'uploads/Rise Slide U Open(3).jpg', NULL, '2024-10-20 16:41:04'),
(859, 726, 'uploads/Rise Slide U Open(4).jpg', NULL, '2024-10-20 16:41:04'),
(860, 727, 'uploads/Softnetic(1).jpg', NULL, '2024-10-20 16:41:04'),
(861, 727, 'uploads/Softnetic(2).jpg', NULL, '2024-10-20 16:41:04'),
(862, 727, 'uploads/Softnetic(3).jpg', NULL, '2024-10-20 16:41:04'),
(863, 727, 'uploads/Softnetic(4).jpg', NULL, '2024-10-20 16:41:04'),
(864, 427, 'uploads/ADIFOM IIINFINITY MULES(1).webp', NULL, '2024-10-20 16:41:04'),
(865, 427, 'uploads/ADIFOM IIINFINITY MULES(2).webp', NULL, '2024-10-20 16:41:04'),
(866, 427, 'uploads/ADIFOM IIINFINITY MULES(3).webp', NULL, '2024-10-20 16:41:04'),
(867, 427, 'uploads/ADIFOM IIINFINITY MULES(4).webp', NULL, '2024-10-20 16:41:04'),
(868, 433, 'uploads/Adilette Boost(1).jpg', NULL, '2024-10-20 16:41:04'),
(869, 433, 'uploads/Adilette Boost(2).jpg', NULL, '2024-10-20 16:41:04'),
(870, 433, 'uploads/Adilette Boost(3).jpg', NULL, '2024-10-20 16:41:04'),
(871, 433, 'uploads/Adilette Boost(4).jpg', NULL, '2024-10-20 16:41:04'),
(872, 431, 'uploads/ADILETTE CLOGS(1).webp', NULL, '2024-10-20 16:41:04'),
(873, 431, 'uploads/ADILETTE CLOGS(2).webp', NULL, '2024-10-20 16:41:04'),
(874, 431, 'uploads/ADILETTE CLOGS(3).webp', NULL, '2024-10-20 16:41:04'),
(875, 431, 'uploads/ADILETTE CLOGS(4).webp', NULL, '2024-10-20 16:41:04'),
(876, 430, 'uploads/ADILETTE LITE(1).webp', NULL, '2024-10-20 16:41:04'),
(877, 430, 'uploads/ADILETTE LITE(2).webp', NULL, '2024-10-20 16:41:04'),
(878, 430, 'uploads/ADILETTE LITE(3).webp', NULL, '2024-10-20 16:41:04'),
(879, 430, 'uploads/ADILETTE LITE(4).webp', NULL, '2024-10-20 16:41:04'),
(880, 429, 'uploads/ADILETTE(1).webp', NULL, '2024-10-20 16:41:04'),
(881, 429, 'uploads/ADILETTE(2).webp', NULL, '2024-10-20 16:41:04'),
(882, 429, 'uploads/ADILETTE(3).webp', NULL, '2024-10-20 16:41:04'),
(883, 429, 'uploads/ADILETTE(4).webp', NULL, '2024-10-20 16:41:04'),
(884, 432, 'uploads/Contaro (1).jpg', NULL, '2024-10-20 16:41:04'),
(885, 432, 'uploads/Contaro (2).jpg', NULL, '2024-10-20 16:41:04'),
(886, 432, 'uploads/Contaro (3).jpg', NULL, '2024-10-20 16:41:04'),
(887, 432, 'uploads/Contaro (4).jpg', NULL, '2024-10-20 16:41:04'),
(888, 428, 'uploads/ISLAND CLUB ADILETTE 22(1).webp', NULL, '2024-10-20 16:41:04'),
(889, 428, 'uploads/ISLAND CLUB ADILETTE 22(2).webp', NULL, '2024-10-20 16:41:04'),
(890, 428, 'uploads/ISLAND CLUB ADILETTE 22(3).jpg', NULL, '2024-10-20 16:41:04'),
(891, 428, 'uploads/ISLAND CLUB ADILETTE 22(4).jpg', NULL, '2024-10-20 16:41:04'),
(892, 603, 'uploads/WMNS 327(1).webp', NULL, '2024-10-30 02:11:34'),
(893, 603, 'uploads/WMNS 327(2).webp', NULL, '2024-10-30 02:11:34'),
(894, 603, 'uploads/WMNS 327(3).webp', NULL, '2024-10-30 02:11:34'),
(895, 603, 'uploads/WMNS 327(4).webp', NULL, '2024-10-30 02:11:34'),
(896, 624, 'uploads/WMNS 550(1).webp', NULL, '2024-10-30 02:11:34'),
(897, 624, 'uploads/WMNS 550(2).webp', NULL, '2024-10-30 02:11:34'),
(898, 624, 'uploads/WMNS 550(3).webp', NULL, '2024-10-30 02:11:34'),
(899, 624, 'uploads/WMNS 550(4).webp', NULL, '2024-10-30 02:11:34'),
(900, 627, 'uploads/WMNS 574 OLIVE(1).webp', NULL, '2024-10-30 02:11:34'),
(901, 627, 'uploads/WMNS 574 OLIVE(2).webp', NULL, '2024-10-30 02:11:34'),
(902, 627, 'uploads/WMNS 574 OLIVE(3).webp', NULL, '2024-10-30 02:11:34'),
(903, 627, 'uploads/WMNS 574 OLIVE(4).webp', NULL, '2024-10-30 02:11:34'),
(904, 605, 'uploads/WMNS 574(1).webp', NULL, '2024-10-30 02:11:34'),
(905, 605, 'uploads/WMNS 574(2).webp', NULL, '2024-10-30 02:11:34'),
(906, 605, 'uploads/WMNS 574(3).webp', NULL, '2024-10-30 02:11:34'),
(907, 605, 'uploads/WMNS 574(4).webp', NULL, '2024-10-30 02:11:34'),
(908, 623, 'uploads/WMNS 9060(1).webp', NULL, '2024-10-30 02:11:34'),
(909, 623, 'uploads/WMNS 9060(2).webp', NULL, '2024-10-30 02:11:34'),
(910, 623, 'uploads/WMNS 9060(3).webp', NULL, '2024-10-30 02:11:34'),
(911, 623, 'uploads/WMNS 9060(4).webp', NULL, '2024-10-30 02:11:34'),
(912, 622, 'uploads/WMNS 997R(1).webp', NULL, '2024-10-30 02:11:34'),
(913, 622, 'uploads/WMNS 997R(2).webp', NULL, '2024-10-30 02:11:34'),
(914, 622, 'uploads/WMNS 997R(3).webp', NULL, '2024-10-30 02:11:34'),
(915, 622, 'uploads/WMNS 997R(4).webp', NULL, '2024-10-30 02:11:34'),
(916, 625, 'uploads/WMNS BB550(1).webp', NULL, '2024-10-30 02:11:34'),
(917, 625, 'uploads/WMNS BB550(2).webp', NULL, '2024-10-30 02:11:34'),
(918, 625, 'uploads/WMNS BB550(3).webp', NULL, '2024-10-30 02:11:34'),
(919, 625, 'uploads/WMNS BB550(4).webp', NULL, '2024-10-30 02:11:34'),
(922, 735, 'uploads/trscxaijo1lomo_photo1.png', 'trscxaijo1lomo_photo1', '2024-12-16 20:03:03'),
(923, 735, 'uploads/trscxaijo1lomo_photo4.jpeg.jpg', 'trscxaijo1lomo_photo4.jpeg', '2024-12-16 20:03:03'),
(924, 735, 'uploads/trscxaijo1lomo_photo5.jpeg.jpg', 'trscxaijo1lomo_photo5.jpeg', '2024-12-16 20:03:03'),
(925, 735, 'uploads/trscxaijo1lomo_photo2.jpeg.jpg', 'trscxaijo1lomo_photo2.jpeg', '2024-12-16 20:03:03'),
(926, 736, 'uploads/19089475_41665609_600.jpg', '19089475_41665609_600', '2024-12-16 20:07:30'),
(927, 736, 'uploads/19089475_41667232_600.jpg', '19089475_41667232_600', '2024-12-16 20:07:30'),
(928, 736, 'uploads/19089475_41666295_600.jpg', '19089475_41666295_600', '2024-12-16 20:07:30'),
(929, 736, 'uploads/19089475_41667231_600.jpg', '19089475_41667231_600', '2024-12-16 20:07:30'),
(930, 737, 'uploads/15624504_28291154_600.jpg', '15624504_28291154_600', '2024-12-16 20:10:20'),
(931, 737, 'uploads/15624504_28291155_600.jpg', '15624504_28291155_600', '2024-12-16 20:10:20'),
(932, 737, 'uploads/15624504_28291156_600.jpg', '15624504_28291156_600', '2024-12-16 20:10:20'),
(934, 738, 'uploads/AIR_ZOOM_ALPHAFLY_NEXT.jpeg.jpg', 'AIR+ZOOM+ALPHAFLY+NEXT%+3+PRM (1).jpeg', '2024-12-16 20:12:21'),
(935, 738, 'uploads/AIR_ZOOM_ALPHAFLY_NEXT.jpg(2)', 'AIR+ZOOM+ALPHAFLY+NEXT%+3+PRM (2).jpeg', '2024-12-16 20:12:21'),
(936, 738, 'uploads/AIR+ZOOM_ALPHAFLY_NEXT.jpg(3)', 'AIR+ZOOM+ALPHAFLY+NEXT%+3+PRM (3).jpeg', '2024-12-16 20:12:21'),
(937, 738, 'uploads/AIR_ZOOM_ALPHAFLY_NEXT.jpeg.jpg(4)', 'AIR+ZOOM+ALPHAFLY+NEXT%+3+PRM.jpeg', '2024-12-16 20:12:21'),
(938, 739, 'uploads/16860816_35808370_600.jpg', '16860816_35808370_600', '2024-12-16 20:14:35'),
(939, 739, 'uploads/16860816_35809076_600.jpg', '16860816_35809076_600', '2024-12-16 20:14:35'),
(940, 739, 'uploads/16860816_35809078_600.jpg', '16860816_35809078_600', '2024-12-16 20:14:35'),
(941, 739, 'uploads/16860816_35807706_600.jpg', '16860816_35807706_600', '2024-12-16 20:14:35'),
(980, 737, 'uploads/15624504_28288460_600.jpg', '15624504_28288460_600', '2024-12-16 20:10:20');

-- --------------------------------------------------------

--
-- Table structure for table `product inventory`
--

CREATE TABLE `product inventory` (
  `id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `Brand_name` varchar(30) NOT NULL,
  `product_id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `model` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `original_price` decimal(10,2) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `stock` varchar(10) NOT NULL,
  `arrival_date` date NOT NULL DEFAULT curdate(),
  `is_new` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Brand_name`, `product_id`, `brand_id`, `model`, `description`, `original_price`, `about`, `category_id`, `type`, `stock`, `arrival_date`, `is_new`) VALUES
('Nike', 101, 101, 'LUKA 3PF “MOTORSPORTS”', 'Manufacturer : Nike\nCountry of Origin : Vietnam\nImported By : Nike India Pvt. Ltd.\nWeight : 1.10 KG\nGeneric Name : Shoes\nUnit of Measurement : 1 Pair\nMarketed By : Superkicks India Pvt. Ltd.\nArticle Code : FQ1285-170\n', 11895.00, 'Basketball Shoes\r\nOn the court, Luka sets his own pace. But put him behind the wheel and it’s a whole different story. Inspired by MJ and Luka’s mutual love of fast vehicles, this Luka 3 will have you reaching for your seatbelt with a design that nods to screeching tires and burning rubber. A touch of Elephant Print roots the design to Jordan heritage while lightweight, responsive foam helps you speed up and slow down so you can make space and score.\r\n\r\nLocked In Support\r\nContainment is key when you\'re tearing down court. A strong yet flexible plate runs up the sidewall to help keep your foot secure as you shift gears. To reduce the shoe\'s weight, we removed excess areas of the plate, keeping only what was needed. The result? Locked in support in one lightweight package.\r\nCushioning 3.0\r\nAcceleration is all about explosive movement, and for that you need cushioning that\'s springy and supportive. Full-length Cushlon 3.0 foam helps you smoothly transition from heel to toe as you drive to the bucket, adding responsive energy to every step. Lightweight Comfort\r\nA seamless molded upper with medial cutout helps provide lightweight comfort and structure without feeling too tight at the forefoot. Pair that with a lighter plate and you have a shoe built to help you move as fast as you see the game.\r\nLook Fast, Feel Fast\r\nBuilt with speed in mind, these shoes draw inspiration from Luka\'s love of cars and spinning tires to give you lightning-fast style. Racing stripes adorn the pull tab while tire-like details decorate the outsole.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 102, 101, 'AIR JORDAN 1 LOW 85', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FB9933-100\r\n', 15995.00, 'Inspired by the original that debuted in 1985, the Air Jordan 1 Low offers a clean, classic look that\'s familiar yet always fresh. With an iconic design that pairs perfectly with any \'fit, these kicks ensure you\'ll always be on point.\r\n\r\nEncapsulated Air-Sole unit provides lightweight cushioning.\r\nGenuine leather in the upper offers durability and a premium look.\r\nSolid rubber outsole enhances traction on a variety of surfaces.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 103, 101, 'INTIATOR', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : HJ7683-072\r\n', 8495.00, 'Put in miles with the comfortable support of the Nike Initiator. It has a breathable upper and a soft, cushioned design to help you hit your stride with confidence.\r\n\r\nSupportive overlays help center your foot in the shoe.\r\nSoft lining enhances comfort.\r\nFoam midsole delivers a soft, cushioned ride.\r\nFlex grooves in the outsole help you move freely.\r\n\r\nMore Details\r\n•	Reflective details\r\n•	Not intended for use as Personal Protective Equipment (PPE)\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 104, 101, 'FULL FORCE LOW', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FB1362-101\r\n\r\n', 8495.00, 'A new shoe with old-school appeal—your retro dreams just came true. This pared-back design references the classic AF1, then leans into \'80s style with throwback stitching and varsity-inspired colors. Not everything has to be a throwback, though—modern comfort and durability make them easy to wear anytime, anywhere. Time to throw them on and go full force.\r\n\r\nLeather upper ages to soft perfection.\r\nChoose from a variety of varsity-inspired colorways to match every mood and look.\r\nExposed foam lets you feel the softness running fully underfoot.\r\n\r\nMore Details\r\n•	Foam midsole\r\n•	Rubber outsole\r\n\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 105, 101, 'AIR JORDAN 4 RETRO GS', 'Manufacturer : Nike\r\nCountry of Origin : China\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FQ8213-001\r\n\r\n\r\n', 11295.00, 'ABOUT PRODUCT\r\nBig Kids\' Shoes\r\nHere\'s your AJ4 done up in classic colors. It\'s built to the original specs and constructed with full-grain leather and textiles. And all your favorite AJ4 elements are there too, like the floating eyestays and the mesh-inspired side panels and tongue.\r\n\r\nNike Air technology absorbs impact for cushioning with every step.\r\nRubber in the outsole gives you everyday traction.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 106, 101, 'WMNS DUNK LOW LX', 'Manufacturer : Nike India Pvt. Ltd.\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FV3642-010\r\n', 11895.00, 'Celebrate dance in these Dunks. Pinstripes and decorative details let you own the floor in style. With its iconic hoops design, lightweight cushioning and a padded collar let you take your game anywhere—in comfort.\r\n\r\nMore Details\r\n•	2 sets of laces\r\n•	Foam midsole\r\n•	Rubber outsole\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 107, 101, 'AIR JORDAN 1 LOW RETRO (GS)', 'Manufacturer : Nike\r\nCountry of Origin : Indonesia\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : HF0410-001\r\n', 8995.00, 'This AJ1 is something special. Vivid Black Raspberry accents pop against the black and Summit White upper. A gleaming Volt Tint outsole and special glow-in-the-dark details will make all the adults wish they had kicks as cool as yours. Plus, this pair comes with cosmic hoops-themed stickers!', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 108, 101, 'DUNK LOW RETRO PREMIUM', 'Manufacturer : NIKE\r\nCountry of Origin : China\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FZ1670-001\r\n', 10795.00, 'The \'80s b-ball icon returns with crisp leather and throwback hoops flair. Channeling vintage style back onto the streets, its padded, low-cut collar lets you take your game anywhere—in comfort.\r\n\r\nLeather upper softens and gains vintage character with wear.\r\nFoam midsole offers lightweight, responsive cushioning.\r\nRubber outsole with classic hoops pivot circle adds durability and traction.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 109, 101, 'WMN\'S AIR JORDAN 1 RETRO HIGH OG \"FIRST FLIGHT\"', 'Manufacturer : Nike\r\nCountry of Origin : China\r\nImported By : Nike India Private Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FD2596-400\r\n', 16995.00, 'This iteration of the AJ1 reimagines Mike\'s first signature model with a fresh mix of colors. Premium materials, soft cushioning and a padded ankle collar offer total support and celebrate the shoe that started it all.\r\n\r\nPremium construction delivers comfort and iconic appeal.\r\nEncapsulated Nike Air-Sole unit in the heel gives you soft cushioning.\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 110, 101, 'NIKE AIRFORCE 1 HIGH \'07', 'Manufacturer : Nike\r\nCountry of Origin : China\r\nImported By : Nike India Private Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FD2596-400\r\n', 14959.00, 'This iteration of the AJ1 reimagines Mike\'s first signature model with a fresh mix of colors. Premium materials, soft cushioning and a padded ankle collar offer total support and celebrate the shoe that started it all.\r\nPremium construction delivers comfort and iconic appeal.\r\nEncapsulated Nike Air-Sole unit in the heel gives you soft cushioning.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Nike', 111, 101, 'AIR FORCE 1 \'07 LV8', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoes\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FQ8714-003\r\n', 10795.00, 'Comfortable, durable and timeless—it’s number 1 for a reason. The classic ‘80s construction pairs with pristine materials for style that tracks whether you’re on court or on the go. A subtle platform gives you just the right amount of height.\r\n\r\nDurable real and synthetic leather with suede overlays ages to soft perfection.\r\nOriginally designed for performance hoops, Nike Air cushioning delivers lasting comfort.\r\nLow-cut, padded collar looks sleek and feels great.\r\nRubber sole has a full cupsole stitch for exceptional durability.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('nike', 112, 101, 'AIR MAX IMPACT 4', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin:Indonesia\r\n', 4247.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 113, 101, 'JORDAN LUKA 2 PF', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 9839.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 114, 101, 'JORDAN MAX AURA 5', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: Faux Leather\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 17456.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 115, 101, 'JORDAN MVP ', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 12542.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 116, 101, 'VOMERO 1', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 10796.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 117, 101, 'JOURNEY  RUN', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 6966.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 118, 101, 'MOTIVA', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 7465.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 119, 101, 'AIR ZOOM STRUCTURE', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 5591.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 120, 101, 'RUN SWIFT 3', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 5264.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('nike', 121, 101, 'AIR MAX SYSTEM', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin: Vietnam\r\n', 7114.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE ', 7, 'sports', '5', '2024-12-10', 0),
('Nike', 122, 101, 'WMNS BLAZER LOW 77 VINTAGE', 'manufacturer : Nike India Pvt. Ltd.\r\ncountry_of_origin : Vietnam\r\nimported_by : Nike India Pvt. Ltd.\r\nproduct_dimensions :\r\nweight : 0.95 KG\r\ngeneric_name : SHOE\r\nunit_of_measurement : 1 Pair\r\nmarketed_by : Superkicks India Pvt. Ltd.\r\narticle_code : DA6364-101\r\n', 6475.00, 'Praised by the streets for its classic simplicity and comfort, the Nike Blazer Low 77 Vintage returns with its low-profile style and heritage b-ball looks.Featuring luscious suede details, a retro Swoosh design and a super-soft collar, its the must-have wardrobe staple that will take you everywhere.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 123, 101, 'WMNS AIR FORCE 1 07', 'Manufacturer : NIKE\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FJ4146-101\r\n', 9695.00, 'Comfortable, durable and timeless—it’s number 1 for a reason. The ‘80s construction pairs with classic colors for style that tracks whether you’re on court or on the go.\r\n\r\nLeather upper softens and gains vintage character with wear.\r\nOriginally designed for performance hoops, the Nike Air cushioning adds all-day comfort.\r\nPadded, low-cut collar looks sleek and feels great.\r\n ', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 124, 101, 'WMNS AIR MAX 1 87', 'Manufacturer : Nike\r\nCountry of Origin : China\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FZ3598-299\r\n', 10236.00, 'Meet the leader of the pack. Walking on clouds above the noise, the Air Max 1 blends timeless design with cushioned comfort. Sporting a wavy mudguard and visible Nike Air, this icon hit the scene in ‘87 and continues to be the soul of the franchise today.\r\n\r\nMixed materials add durability thats made for everyday wear and city life. Plush and comfortable, Max Air cushioning has just the right amount of support .Padded, low-cut collar looks sleek and feels comfortable. Rubber outsole gives you durable traction\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 125, 101, 'WMNS AIR MAX EXCEE', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Mesh\r\nCountry of Origin:Vietnam\r\n', 7029.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 126, 101, 'WMNS W BLAZER LOW PLATFORM', 'Closure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Rubber\r\nCountry of Origin:Vietnam\r\n', 5818.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 127, 101, 'WMNS W COURT VIDSION LO', 'Closure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running Shoes\r\nOuter material:Rubber\r\nCountry of Origin:Vietnam\r\n', 6084.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 128, 101, 'WMNS W BLAZER LOW 77 JUMBO', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running\r\nOuter material:Faux Leather\r\nCountry of Origin:Vietnam\r\n', 6304.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 129, 101, 'WMNS AIR MAX 97', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running\r\nOuter material: Leather\r\nCountry of Origin:Vietnam\r\n', 7267.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 130, 101, 'WMNS W METCON 8', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:LOW TOP\r\nOuter material: NYLON\r\nCountry of Origin:Vietnam\r\n', 10459.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 131, 101, 'WMNS GAMMA FORCE', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle: WMNS GAMMA FORCE\r\nOuter material:Faux Leather\r\nCountry of Origin:Vietnam\r\n', 7354.00, 'Designed for comfortable wear for sports and street style, NIKE is always fun to wear. Upgrade in style with a wide range from the world’s leading and much-loved sports brand, NIKE.', 9, 'casuals', '5', '2024-12-10', 0),
('Nike', 132, 101, 'VICTORI ONE', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : CN9675-002\r\n', 2905.00, 'From the beach to the bleachers, the Victori One is a must-have slide for everyday activities. Subtle yet substantial updates like a wider strap and softer foam make lounging easy. Go ahead—enjoy endless comfort for your feet.\r\n\r\nSoft foam adds responsiveness and cushioning.\r\nTextured pattern on the contoured footbed adds grip to help your feet stay in place.\r\nRolled edges on the padded strap creates a smooth, comfortable feel.\r\nWider strap provides additional space to help accommodate more sizes.\r\nOutsole pattern is designed for multi-surface traction.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Nike', 133, 101, 'CALM', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : CN9675-002\r\n', 3895.00, 'From the beach to the bleachers, the Victori One is a must-have slide for everyday activities. Subtle yet substantial updates like a wider strap and softer foam make lounging easy. Go ahead—enjoy endless comfort for your feet.\r\n\r\nSoft foam adds responsiveness and cushioning.\r\nTextured pattern on the contoured footbed adds grip to help your feet stay in place.\r\nRolled edges on the padded strap creates a smooth, comfortable feel.\r\nWider strap provides additional space to help accommodate more sizes.\r\nOutsole pattern is designed for multi-surface traction.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Nike', 134, 101, 'CALM SANDALS', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : CN9675-002\r\n', 7095.00, 'From the beach to the bleachers, the Victori One is a must-have slide for everyday activities. Subtle yet substantial updates like a wider strap and softer foam make lounging easy. Go ahead—enjoy endless comfort for your feet.\r\n\r\nSoft foam adds responsiveness and cushioning.\r\nTextured pattern on the contoured footbed adds grip to help your feet stay in place.\r\nRolled edges on the padded strap creates a smooth, comfortable feel.\r\nWider strap provides additional space to help accommodate more sizes.\r\nOutsole pattern is designed for multi-surface traction.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Nike', 135, 101, 'OFFCOURT ADJUST', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : CN9675-002\r\n', 3895.00, 'From the beach to the bleachers, the Victori One is a must-have slide for everyday activities. Subtle yet substantial updates like a wider strap and softer foam make lounging easy. Go ahead—enjoy endless comfort for your feet.\r\n\r\nSoft foam adds responsiveness and cushioning.\r\nTextured pattern on the contoured footbed adds grip to help your feet stay in place.\r\nRolled edges on the padded strap creates a smooth, comfortable feel.\r\nWider strap provides additional space to help accommodate more sizes.\r\nOutsole pattern is designed for multi-surface traction.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Nike', 136, 101, 'AIR MORE UPTEMPO', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : FQ8699-200\r\n', 8495.00, 'Your favorite hoops look gets transformed into slides you can easily slip on and off. Keeping the graffiti-styled \"AIR\" graphics you love from the original, the Air More Uptempo combines a plush strap, airy perforations and soft cushioning—making it a perfect choice for courtside, beachside and beyond.\r\n\r\nPadded strap with perforations feels plush and airy.\r\nOriginally designed for performance sports, visible Nike Air cushioning delivers time-tested comfort.\r\nRubber outsole features the grip pattern from the original Uptempo for durable traction.\r\nFoam footbed is contoured to help keep your foot in place.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Nike', 137, 101, 'OFFCOURT', 'Manufacturer : Nike\r\nCountry of Origin : Vietnam\r\nImported By : Nike India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : CN9675-002\r\n', 2495.00, 'From the beach to the bleachers, the Victori One is a must-have slide for everyday activities. Subtle yet substantial updates like a wider strap and softer foam make lounging easy. Go ahead—enjoy endless comfort for your feet.\r\n\r\nSoft foam adds responsiveness and cushioning.\r\nTextured pattern on the contoured footbed adds grip to help your feet stay in place.\r\nRolled edges on the padded strap creates a smooth, comfortable feel.\r\nWider strap provides additional space to help accommodate more sizes.\r\nOutsole pattern is designed for multi-surface traction.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Puma', 201, 102, 'PUMA x ONE PIECE Suede Red-Haired Shanks Unisex Sneakers', 'Hairy suede upper combined with leather overlays\r\n • Co-branded suede tongue\r\n• Gold metal hangtag on lateral side\r\n• Debossed PUMA Cat logo on left heel and skull on right heel\r\n • Flat lace closure\r\nMATERIAL INFORMATION:\r\n• Sockliner: 100% Synthetic\r\n• utsole: 100% Rubber\r\n\r\n• Upper: 78.15% Leather, 18.04% Synthetic, 3.81% Textile\r\n • Lining: 69.95% Textile, 30.05% Synthetic\r\nMANUFACTURER\'S ADDRESS: P.T. HORN MING INDONESIA ID JL. RAYA SERANG KM. 18.8 DESA SUKANEGARA KEC.., CIKUPA TANGERANG BANTEN, 15710 -\r\n COUNTRY OF ORIGIN:Indonesia\r\n\r\n', 8999.00, 'PUMA x ONE PIECE combines the worlds of manga and sports, with streetwear-relevant styling. We\'ve taken our classic \r\n\r\nSuede sneaker and completely decked it out for anyone who\'s a child of the sea. Walk around in a fully unique design combining the iconic graphics of your favourite manga with the historic style of PUMA. Ready to go treasure-hunting?\r\n FEATURES & BENEFITS :PUMA\'s leather products support responsible manufacturing via the Leather Working Group. www.leatherworkinggroup\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 202, 102, 'RS-X Toys Unisex Sneakers', '• Comfortable style by PUMA\r\n• PUMA branding details\r\n• Signature PUMA design elements\r\nMATERIAL INFORMATION:\r\n• Midsole: 100% Synthetic\r\n• Sockliner: 100% Textile\r\n• Outsole:100% Rubber\r\n• Upper: 51% Textile, 36% Leather, 13% Synthetic\r\n • Lining: 100% Textile\r\nMANUFACTURER\'S ADDRESS: THIEN LOC SHOES CORPORATION VN 108 NGUYEN \r\n\r\nANH THU STREET HIEP THANH WARD.,DISTRICT 12, - HO CHI MINH\r\n COUNTRY OF ORIGIN:Vietnam\r\n\r\n', 10999.00, 'KS-A loys unIsex Sneakers Style: 369449_28\r\n Based on PUMA\'s innovative Running System technology, the RS-X line draws its design inspiration from the decade that had the best toys ever, hands down, bar none: the 1980s. Specifically, these sneakers play on the trend of the toys of our childhood ultimately becoming collector\'s items down the road The mesh upper on these shoes promote air flow, and features colours that would be at home in a crowded video arcade from 30 \r\n\r\nyears ago. A unique cushioning function provides support, and the rubber outsole offers supreme traction and grip\r\n FEATURES & BENEFITS:\r\n• Running System: PUMA\'s comfortable cushioning technology celebrates the reinvention of a unique moment and movement in culture\r\n\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 203, 102, 'RS-XK X one8 Res Unisex Sneakers', '• Midsole: 100% Synthetic\r\n• Sockliner: 100% Textile\r\n• Outsole: 100% Rubber\r\n• Upper: 47% Textile, 40% Synthetic, 13% Leather\r\n • Lining: 100% Textile\r\nMANUFACTURER\'S ADDRESS:\r\nDAI LOC SHOE CORPORATION VN LOT G5 \r\n\r\n(B2), D10 STREET, RACH BAP INDUSTRIAL PARK, BEN CAT TOWN, - BINH DUONG PROVINCE\r\n COUNTRY OF ORIGIN:\r\nVietnam\r\n', 11999.00, NULL, 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 204, 102, 'Suede XL Unisex Sneakers', 'Suede upper\r\n• Leather Formstrip\r\n• Suede tongue with mesh binding\r\n• Debossed and foil-printed PUMA branding on quarter panel\r\n • Mesh lining\r\n• Mesh sockliner\r\n• Rubber midsole\r\n• Rubber outsole\r\n• Lining: Textile, Other; Outsole: Rubber; Upper: Leather; Sockliner: Textile\r\n MATERIAL INFORMATION:\r\n• Sockliner: 100% Textile\r\n• Outsole:100% Rubber\r\n• Upper: 97.21% Leather, 2.79% Synthetic\r\n• Lining: 62.81% Textile, 37.19% Synthetic\r\nMANUFACTURER\'S ADDRESS: PUTIAN BAIHO FOOTWEAR CO.,LTD FOOTWEAR CO.,LTD FCNBH FUJIAN \r\n\r\nNO.1518,GUCHENG EAST ROAD HUANGSHI INDUSTRIAL PARK HUANGSHI TOWN 351144 PUTIAN\r\n COUNTRY OF ORIGIN: China\r\n\r\n', 8999.00, 'This fresh take on the classic Suede draws inspiratior from PUMA\'s heritage within breakdancing and ts influence on modern streetwear. The Suede XL retains the Suede\'s iconic DNA, but gives it a twist with an exaggerated padded collar and tongue, plus a chunkier sole. This execution features a full suede upper with a leather Formstrip.\r\n FEATURES & BENEFITS:\r\n• PUMA\'s leather products support responsible manufacturing via the Leather Working \r\n\r\nGroup.www.leatherworkinggroup\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 205, 102, 'PUMA x KIDSUPER Easy Rider Unisex Sneakers', 'Regular fit\r\n• Leather Formstrip\r\n• Cashmere lining\r\n• Cashmere suede overlays\r\n• PUMA branding details\r\nMATERIAL INFORMATION:\r\n• idsole: 100% Rubber\r\n• Sockliner: 100% Textile\r\n• Outsole: 100% Rubber\r\n• Upper: 65.88% Leather, 19.79% Textile 14.33% Synthetic\r\n • Lining: 100% Textile\r\nMANUFACTURER\'S ADDRESS: VMC ROYAL CO., LTD. VN 22B THANH PHUOC HAMLET, THANH DIEN WARD CHAU THANH DISTRICT, 840000 TAY NINH PROVINCE\r\n COUNTRY OF ORIGIN: Vietnam\r\n\r\n', 11999.00, 'KidSuper founder Colm Dillane is an ex-professional footballer, designer, and artist. The brand is known for their wildly inventive runway shows and even more inventive looks. The PUMA x KIDSUPER collaboration reinterprets PUMA classics through the lens of KidSuper - with pastel colours, dynamic lines, and bold prints featuring his art,.\r\n FEATURES & BENEFITS :PUMA\'s leather products support responsible manufacturing via the Leather Working Group. www.leatherworkinggroup.com\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 206, 102, 'Velophasis Born In The 2000s Unisex Sneakers', 'Regular fit\r\n• Open textile upper\r\n• Synthetic overlays on vamp, toe, and heel\r\n• Lace closure\r\n• CMEVA midsole\r\n• Rubber outsole\r\n• Synthetic PUMA Formstrip with silver and debossed details\r\n • Translucent TPU on quarter and medial \r\n', 12999.00, 'The Velophasis was created by blended references from a similar design aesthetic to create something new and authentic. Its silhouette is a 2000s hybrid loosely inspired by PUMA\'s heritage performance running range. This version features an \r\n\r\nopen textile upper, synthetic overlays, two-colour gradient lines and silver details\r\n FEATURES & BENEFITS:\r\n• The upper of the shoes is made with at least 20% recycled materials\r\n • Vegan certified product\r\n• SOFTFOAM+: Step-in comfort sockliner designed to provide soft cushioning thanks to its extra thick heel\r\n • CMEVA: PUMA\'s compression-moulded EVA material for lightweight performance\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 207, 102, 'PUMA x KidSuper Palermo Unisex Sneakers', '• Cashmere suede upper combined with padded foam and leather overlays\r\n • Cashmere suede tongue with printed co-branding on woven label and nylon pull tab\r\n • Mesh lining and printed co-branding on sockliner\r\n . Padded heel patch with printed PUMA loga on flat gel insert and printed KidSuper logo on nylon pull tab\r\n • Rubber midsole\r\n• Rubber outsole\r\n• PUMA x KidSuper co-branding\r\n\r\nMATERIAL INFORMATION:\r\n• utsole: 100% Leather\r\n• Upper: 73.25% Leather, 26.75% Textile\r\n• Lining: 100% Textile\r\nMANUFACTURER\'S ADDRESS :VMC ROYAL CO., LTD VN 22B THANH PHUOC HAMLET, THANH DIEN WARD, CHAU THANH DISTRICT, 840000 TAY NINH PROVINCE\r\n COUNTRY OF ORIGIN:\r\nVietnam\r\n\r\n', 7999.00, 'PUMA teams up once again with KidSuper for an exciting new collection, the KidSuper Sports Club Founder Colm Dillane is an ex professional footballer designer, artist, director, and much more. Inspired by his passion for football, the collection features elevated designs, athletic details and all the design hallmarks of KidSuper. This version of the Palermo. a legend from our \'80s archives and a staple amongst terrace crowds in British football stadiums, is complete with \r\n\r\nits signature tag on the cashmere suede upper, a T-toe construction, and a classic gum sole.\r\n FEATURES & BENEFITS:\r\n• PUMA\'s leather products support responsible manufacturing via the Leather Working Group.www.leatherworkinggroup\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 208, 102, 'Caven 2.0 Abrupt Unisex Sneakers', 'Make a statement in bold PUMA Caven 2.0\'s. Their redefined style and rugged outsole will elevate your street looks. Perforated uppers and metallic eyelets inject attitude. SOFTFOAM+ sockliners cushion your stride in ultimate comfort. Look sharp and make noves in a classic \'80s b-ball silhouette with a sharp twist.\r\n FEATURES & BENEFITS:\r\n• The upper of the shoes is made with at least 20% recycled materials and the bottom is made with at least 10% recycled materials\r\n • SOFTFOAM+: Step-in comfort sockliner \r\ndesigned to provide soft cushioning thanks to its extra thick heel\r\n', 4219.00, '• Regular fit\r\n• Synthetic upper with a mix of tumbled and clean texture\r\n • Lace closure\r\n• Rubber outsole\r\n• Perforation details on vamp\r\nMATERIAL INFORMATION:\r\n• Outsole: 100% Rubber\r\n• Upper: 100% Synthetic\r\n• Lining: 100% Textile\r\nMANUFACTURER\'S ADDRESS :FUJIAN PROVINCE GOOD BROTHER SPORTS EQUIPMENT CO. LTD FCNMZ\r\n NO.318 MEILING ROAD, MEISHAN C OMMUNITY, MEILING STREET 362200 JINJIANG\r\n COUNTRY OF ORIGIN :China\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 209, 102, 'BMW M Motorsport Neo Cat Mid 2.0 Unisex Sneakers', 'Synthetic upper\r\n• Lace closure with hook-and-loop strap\r\n• Rubber outsole\r\n• BMW M Motorsport branding details\r\n• PUMA branding details\r\nMATERIAL INFORMATION:\r\n• Sockliner: 100% Textile\r\n• utsole: 100% Rubber\r\n• Upper: 99.67% Synthetic, 0.33% Textile\r\n• Lining: 100% Textile\r\nMANUFACTURER\'S ADDRESS :BRIGHT FLUSHING CO., LTD KH TAKEO PROVINCE PHUM THNUNG ROLEUNG, KHUM LEAY BOR, SRUK TRAM KOK, 210204 SRUK TRAM KOK\r\nCOUNTRY OF ORIGIN :Cambodia\r\n \r\n', 4639.00, 'Inspired by Bellof\'s driving boots, the very first PUMA Motorsport boots created for legendary driver Stefan Bellof in the 80\'s, the Neo Cat has an impressive heritage. This mid-cut version brings the style to the streets for a sleek, motorsport-inspired look. They have a clean, synthetic upper \r\nand BMW\'s signature colours.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 210, 102, 'CA Pro Classic Unisex Sneakers', 'Leather upper\r\n• Rubber midsole and outsole\r\n• Lace closure for a snug fit\r\n• Debossed and foil printed PUMA No. 2 Logo at quarter\r\n • PUMA Formstrip at lateral sides\r\n• PUMA branding at heel\r\n• Lining: Textile; Outsole: Rubber; Midsole: Other; Upper: Leather, Other; Sockliner: Textile\r\n MATERIAL INFORMATION:\r\n• Sockliner: 100% Textile\r\n• Outsole: 100% Rubber\r\n• Upper: 81.13% Leather, 16.39% \r\n  Synthetic 2.48% Textile\r\n• Lining: 100% Textile\r\nMANUFACTURER\'S ADDRESS: PUTIAN MAX XIN FOOTWEAR CO. LTD. FCNMX FUJIAN NO.888, GUCHENG EAST RD. FENGSHAN VILLAGE HUANGSHI TOWN LICHENG DISTRICT 351144 PUTIAN\r\n COUNTRY OF ORIGIN:China\r\n\r\n', 7999.00, 'Elevate your casual sneaker game with the PUMA CA Pro Classic sneakers. These sleek and stylish sneakers are the perfect addition to any outfit, whether you\'re hitting the city streets or just chilling with friends. With PUMA\'s signature comfort and quality, these sneakers offer a supportive fit and durable construction that will keep you stepping out in style for years to come. Upgrade your footwear collection with the PUMA CA Pro Classic sneakers and experience the perfect blend of fashion and function.\r\n FEATURES & BENEFITS:\r\n\r\n• The upper of the shoes is made with at least 20% recycled materials\r\n • PUMA\'s leather products support responsible manufacturing via the Leather Working Group.www.leatherworkinggroup.com\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 211, 102, 'PUMA Morphic Unisex Sneakers', '\n• Mesh and synthetic upper with synthetic overlays\n • Laces closure\n• Rubber outsole\nMATERIAL INFORMATION:\n• Sockliner: 100% Textile\n• Outsole: 100% Rubber\n• U pper: 65.62% Synthetic, 34.38% Textile\n• Lining: 100% Textile\nMANUFACTURER\'S ADDRESS: PUTIAN \n', 7999.00, 'Meet PUMA Morphic, our new retro runner. This athletic silhouette stands out with a progressive dynamic look, bringing a trend-forward edge to any outfit.\r\n FEATURES & BENEFITS:\r\n• Recycled content: The upper of this shoe is made with at least 30% recycled materials as a step toward a better future\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Puma', 212, 102, 'WMNS MAYZE EMBROIDERY', '•Product Dimensions: 25.5 x 19.5 x 8 cm; 700 g\r\n•Date First Available ‏ : ‎ 12 June 2024\r\n•Manufacturer ‏ : ‎ Puma\r\n•ASIN ‏ : ‎ B0CMD6V6H6\r\n•Item model number ‏ : ‎ 399674\r\n•Country of Origin ‏ : ‎ Vietnam\r\n•Department ‏ : ‎ womens\r\n•Manufacturer ‏ : ‎ Puma, ALERON VIET NAM FOOTWEAR LIMITED HOANG LONG INDUSTRIAL ZONE TAO XUYEN WARD - THANH HOA CITY THANH HOA PROVINCE\r\n•Packer ‏ : ‎ Puma Sports India Pvt Ltd\r\n•Importer ‏ : ‎ Puma Sports India Pvt Ltd\r\n•Item Weight ‏ : ‎ 700 g\r\n•Item Dimensions LxWxH ‏ : ‎ 25.5 x 19.5 x 8 Centimeters\r\n•Net Quantity ‏ : ‎ 1 Pack\r\n•Name ‏ : ‎ Sneaker\r\n', 6749.00, 'Product Story: Make a street style statement in the Mayze Embroidery sneakers. With a stacked sole and 3D embroidered flowers, set trends and turn heads. Designed for the hype girls and fashion mavens, these sneakers deliver standout style inspired by the streets. Step into the spotlight and get ready to be noticed in every step. DETAILS Regular fit Synthetic upper Suede eyestay and bottom heel overlays Canvas lining Lace closure Rubber midsole and outsole Textile PUMA Formstrip 3D embroidered flowers on the quarter panel Platform style PUMA branding details', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 213, 102, 'WMNS MAYRA', 'Material type: Leather, Rubber\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: Rubber\r\nStyle: Sneaker\r\nCountry of Origin: China\r\n', 7999.00, 'Product Story: Mayra offers a fresh blend of cushioned comfort and fashion ability. The high collar and sharp details combine with a Soft Foam + sock liner for feelgood footwear that supports your foot while you step out in style. FEATURES & BENEFITS SOFTFOAM+: Step-in comfort sock liner designed to provide soft cushioning thanks to its extra thick heel The upper of this shoe is made with at least 20% recycled materials and the bottom is made with at least 10% recycled materials, as a step toward a better future. DETAILS Rubber midsole and outsole PUMA Form strip on lateral and medial sides PUMA branding details High boot', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 214, 102, 'WMNS RS-X SOFT SNEKERS', 'Material type: Leather\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: Rubber\r\nStyle: Sneaker\r\nCountry of Origin: Vietnam\r\n\r\n\r\n', 7499.00, 'Product Story: The RS-X returns for a new generation of consumers who live to express their individuality. The RS-X Soft features a textile base with leather and suede overlays along with a cool 3D-printed form strip and Lycra hits. FEATURES & BENEFITS The upper of this shoe is made with at least 20% recycled materials as a step toward a better future. DETAILS Textile base 3D printed form strip Leather toe and heel overlay Synthetic quarter panel and eye stay Suede vamp and eye stay underlays RS midsole Rubber outsole', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 215, 102, 'WMNS MAYZE LTH', 'Material type: Leather\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: Rubber\r\nStyle: Sneaker\r\nCountry of Origin: Vietnam\r\n', 7999.00, ' Product Story: Elevate your street style with the Puma Mayze Lth Wn s platform sneakers. These trendy platform trainers from Puma offer a bold and stylish look that will turn heads wherever you go. With a sleek leather upper and a chunky platform sole, these sneakers provide both fashion and comfort. Step up your shoe game with the Puma Mayze Lth Wn s and make a statement with every stride. DETAILS Leather upper with suede and synthetic overlays Glossy eyelets Elevated rubber midsole with textured tooling Rubber outsole Lace closure for a snug fit PUMA branding at tongue Foil-printed PUMA No.2 Logo at quarter PUMA form strip at medial and lateral sides PUMA Wordmark at tooling Foil-printed PUMA Cat Logo at heel', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 216, 102, 'WMNS CA PRO PRM', 'Product Story: Ever since the original PUMA California was released in the 1980s, the style made its mark on the streets. As new addition to the California family, the CA Pro is picking up on that heritage. Details like the toe perforations directly draw back to the original style, while the general design language is inspired by PUMA\'s classic range, including basketball. DETAILS Leather upper Rubber midsole Rubber outsole PUMA form strip on the lateral sides PUMA Cat Logo on the heel', 8999.00, 'Product Story: Ever since the original PUMA California was released in the 1980s, the style made its mark on the streets. As new addition to the California family, the CA Pro is picking up on that heritage. Details like the toe perforations directly draw back to the original style, while the general design language is inspired by classic range of Puma, including basketball. DETAILS Leather upper Rubber midsole Rubber outsole PUMA form strip on the lateral sides PUMA Cat Logo on the heel', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 217, 102, 'WMNS CARINA 2.0 LUX', 'Material type: Leather\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: Rubber\r\nStyle: Sneaker\r\n', 10999.00, 'PRODUCT STORY: Hit the street in retro-inspired kicks built for today. The Carina 2.0 Lux s perforated leather upper and Soft Foam+ sock liner provides instant comfort to roam beachside boulevards and city streets, while its classic 80s design ensures laid-back Californian cool with every stylish step. FEATURES & BENEFITS PUMA’s leather products support responsible manufacturing via the Leather Working Group. DETAILS Leather upper with perforated vamp EVA and TPU midsole Soft Foam+ sock liner provides cushioning and comfort for all-day wear Wider vertical lines and PUMA logo on the heel add a unique touch to the design PUMA form strip on the lateral sides', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 218, 102, 'WMNS BLSTR', 'Material type: Leather\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: MEVA\r\nStyle: Sneaker\r\n', 8999.00, 'Product Story: BLSTR is bringing the edge. With a design inspired by PUMA’s fashion collaborations from the past, this new silhouette features a disruptive platform tooling that’s ready to stand out from the crowd. The upper details and construction allow for bold colour blocking inspired by the latest trends. This version of the sneaker features a perforated synthetic base with nubuck overlays and TPU inserts with a glossy finish in the midsole. FEATURES & BENEFITS PUMA’s leather products support responsible manufacturing via the Leather Working Group.www.leatherworkinggroup.com DETAILS Perforated synthetic base upper Synthetic and leather overlays Nubuck heel cap, eye stay overlay and quarter panel overlay Perforated synthetic tongue Heel webbing loop Mesh lining Mesh sock liner Glossy TPU inserts in midsole IMEVA midsole IMEVA and rubber outsole', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 219, 102, 'WMNS KARMEN II MID', 'Material type: Leather\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: Rubber\r\nStyle: Sneaker\r\nCountry of Origin: China\r\n', 3704.00, 'Product Story: Strike a stylish stance in the Karmen II Mid. Its elevated platform sole and rugged outsole provide attitude with every step, while the mid-cut collar adds flair. Built for  everyday adventures of life, these sneakers inspire confidence for any destination. Go ahead, make a statement. FEATURES & BENEFITS The upper of the shoes is made with at least 30% recycled materials and the bottom is made with at least 10% recycled materials leather of puma products support responsible manufacturing via the Leather Working Group: SOFTFOAM+: Step-in comfort sockliner designed to provide soft cushioning thanks to its extra thick heel DETAILS Regular fit Coated leather and synthetic upper Mesh lining Lace closure Rugged rubber outsole Platform style Mid boot', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 220, 102, 'WMNS CALI COURT LTH', 'Material type: Leather\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: Ethylene Vinyl Acetate\r\nStyle: Sneaker\r\n', 7459.00, 'Product Story: Meet the PUMA Cali Court, your new favourite court classic. Standing at the intersection of sport, fashion, and streetwear, this sneaker brings the tennis vibes to any outfit and can be easily mixed and matched with other pieces to create an effortless look. This version features a full leather upper and fits in court side. FEATURES & BENEFITS PUMA’s leather products support responsible manufacturing via the Leather Working Group.www.leatherworkinggroup.com DETAILS Leather upper Tumbled leather vamp, heel overlay and eye stay overlay Leather quarter panel, tongue and form strip Perforated vamp and quarter panel details EVA midsole Rubber outsole.\r\n \r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 221, 102, 'WMNS MAYZE STACK ', 'Material type:Leather\r\nClosure type: Lace-Up\r\nHeel type: Flat\r\nWater resistance level: Not Water Resistant\r\nSole material: Rubber\r\nStyle: Sneaker\r\n', 8954.00, 'Product Story: You thought Mayze made enough of a statement? The Mayze Stack takes it to a whole new level, literally. It has a super-sized sole, and an upper inspired by some of our most iconic models. FEATURES & BENEFITS PUMA’s leather products support responsible manufacturing via the Leather Working Group.www.leatherworkinggroup.com DETAILS Leather upper Nubuck overlays PU-coated form strip Rubber midsole Rubber outsole', 9, 'casuals', '5', '2024-12-10', 0),
('Puma', 222, 102, 'AXELION REFRESH RUNNING WHITE', 'Material type:Mesh\r\nClosure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running\r\n', 2879.00, 'Product Story:Looking for a fresh new look for your runs? The PUMA Axelion Refresh Men s Running Shoes are just what you need! The breathable upper and SOFTFOAM+ sockliner provide ultimate comfort, the molded saddle piece on upper provide added dimension while the bold, exaggerated lacing ensure long-lasting support.Features & Benefits SoftFoam+: PUMA’s comfort sockliner for instant step-in and long-lasting comfort that provides soft cushioning every step of your dayDetails Textile upper Rubber outsole Heel type: Flat Shoe width: Regular fit Shoe pronation: Neutral Heel-to-toe-drop: 13 mm PUMA Cat logo on tongue and toe box PUMA Wordmark on heel.', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 223, 102, 'AXELION REFRESH RUNNING WHITE-FIZZY LIME-CLYDE ROYAL', 'Material type:Mesh\r\nClosure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Running\r\n', 2879.00, 'Product Story:Looking for a fresh new look for your runs? The PUMA Axelion Refresh Mens Running Shoes are just what you need! The breathable upper and SOFTFOAM+ sockliner provide ultimate comfort, the molded saddle piece on upper provide added dimension while the bold, exaggerated lacing ensure long-lasting support.Features & Benefits SoftFoam+: PUMA’s comfort sockliner for instant step-in and long-lasting comfort that provides soft cushioning every step of your dayDetails Textile upper Rubber outsole Heel type: Flat Shoe width: Regular fit Shoe pronation: Neutral Heel-to-toe-drop: 13 mm PUMA Cat logo on tongue and toe box PUMA Wordmark on heel.', 7, 'sports', '5', '2024-12-10', 0);
INSERT INTO `products` (`Brand_name`, `product_id`, `brand_id`, `model`, `description`, `original_price`, `about`, `category_id`, `type`, `stock`, `arrival_date`, `is_new`) VALUES
('Puma', 224, 102, 'ST RUNNER V4 L', 'Material type:Leather\r\nClosure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sneaker\r\nCountry of Origin:Indonesia\r\n', 2585.00, 'Product Story: Step into a classic and make a statement. These updated street-ready sneakers combine retro style with renewed details. The soft coated leather upper, new heel clip and SOFTFOAM+ sockliner deliver heritage looks with modern comfort for going places and getting things done. With a slightly higher midsole, make an impact with every stride. FEATURES & BENEFITS PUMAs leather products support responsible manufacturing via the Leather Working Group: SOFTFOAM+: Step-in comfort sockliner designed to provide soft cushioning thanks to its extra thick heel DETAILS Regular fit Soft coated leather upper Lace closure Synthetic midsole Rubber outsole', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 225, 102, 'HYPNOTIC LS RES', 'Material type:Textile\r\nClosure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sneaker\r\nCountry of Origin:India\r\n', 3320.00, 'Product Story: Crafted with fine technology and futuristic design, PUMA shoe is surely here to uplift your style and track games. Kick off on street and field in this shoe from the world’s leading and much loved sports brand, PUMA.', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 226, 102, 'SMASH SPRINT INDOOR SHOE', 'Closure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Indoor\r\nCare instructions:Wipe with Clean cloth\r\nCountry of Origin:India\r\n', 2499.00, 'PRODUCT STORY: Ready for the smash? Experience the revolution of Variofoam, offering a lightweight cushion that propels you to leap and lunge with ease. The Variomesh upper envelopes your feet in unparalleled breathability and comfort, keeping you cool as the match heats up. Designed with a non-marking outsole for flawless movement and a stability frame that delivers exceptional lateral and medial support, these shoes are the ultimate ally in every intense rally. Details: Heel type: Flat Shoe width: Regular fit Shoe pronation: Neutral Heel-to-toe-drop: 0 mm .\r\nTextile upper Non-marking rubber outsole. Suitable for use on indoor surfaces. Low boot Lace closure Variofoam for a lightweight cushioning sensation Variomesh provides superb breathability and comfort Stability frame for lateral and medial support PUMA cat logo branding\r\n', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 227, 102, 'ULTRARIDE WALKING', 'Closure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:WALKING\r\nCountry of Origin:India\r\n', 5399.00, 'PRODUCT STORYLight, airy and full of style, the UltraRide Running Shoes are a hit both on and off the track. Featuring a ProFoam midsole for a responsive ride and a PROPLATE plate for quick turnover, these shoes are poised to become your all-time faves.FEATURES & BENEFITSProFoam: PUMAs lightweight, high-rebound EVA midsole solution provides instant cushioning and a responsive ride PROPLATE: PUMA’s engineered propulsion plate provides a reflex toe-off and propels you faster through every stride DETAIL SLow boot Light and airy upper with underlay support structure Midsole plate with dynamic bridge design Rubber outsole with cutaways and visible under sock PUMA Wordmark at tongue Form strip at lateral side', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 228, 102, 'ULTRARIDE RUNNING', 'Closure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:WALKING\r\nCountry of Origin:India\r\n', 5399.00, 'PRODUCT STORYLight, airy and full of style, the UltraRide Running Shoes are a hit both on and off the track. Featuring a ProFoam midsole for a responsive ride and a PROPLATE plate for quick turnover, these shoes are poised to become your all-time faves.FEATURES & BENEFITSProFoam: PUMAs lightweight, high-rebound EVA midsole solution provides instant cushioning and a responsive ride PROPLATE: PUMA’s engineered propulsion plate provides a reflex toe-off and propels you faster through every stride DETAIL SLow boot Light and airy upper with underlay support structure Midsole plate with dynamic bridge design Rubber outsole with cutaways and visible under sock PUMA Wordmark at tongue Form strip at lateral side', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 229, 102, 'MIRAGE SPORT TECH ', 'Outer material:Rubber\r\nClosure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:WALKING\r\nCountry of Origin:India\r\n', 5999.00, 'Long celebrated for its lightweight stability and comfort, the Mirage Sport Tech Trainers are back from the 90s archives and redesigned for today. Inspired by DJ culture, with a futuristic design that explores progressive lines and supreme street edge, this eye-catching iteration features a mesh upper with synthetic and hotmelt overlays, standout stitching, bold brand elements and a sleek shape. A juxtaposition between classic and athletic, these trend-setting trainers will be the talk of the town. IMEVA: PUMAs material for a lightweight and comfortable feel Recycled Content: The upper of this shoe is made with at least 20% recycled materials as a step toward a better future Technical mesh upper with synthetic and hotmelt overlays Lycra collar IMEVA midsole Rubber outsole Lace closure for a snug fit PUMA Formstrip at medial and lateral sides PUMA branding at heel PUMA Wordmark at tongue Style: 383107_26 Color: Cool Dark Gray-Hot Heat', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 230, 102, 'ANZARUN FS 2.0', 'Material type:Mesh\r\nClosure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sneaker\r\nCountry of Origin:Cambodia\r\n\r\n', 2894.00, 'Product Story: The next generation of trainer is upon us. Enter Anzarun, the sleekest, comfiest ride yet. The mesh upper provides superior breathability and the SoftFoam+ sockliner means you re cushioned every step of the way. The sophisticated, low-profile design features discreet PUMA branding throughout and a sculpted, high-tech body.FEATURES & BENEFITSSoftFoam+: PUMA’s comfort sockliner for instant step-in and long-lasting comfort that provides soft cushioning every step of your day DETAILSLow boot Mesh upper with heat-pressed overlays Synthetic cage Contrast webbing EVA midsole for comfort Rubber outsole for grip PUMA Cat Logo at toe, tongue and heel PUMA Cat Logo at heel strap', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 231, 102, 'CLUB II YEAR OF SPORTS', 'Material type:Synthetic\r\nClosure type:Lace-Up\r\nHeel type:Flat\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sneaker\r\nCountry of Origin:China\r\n', 2585.00, 'Long celebrated for its lightweight stability and comfort, the Mirage Sport Tech Trainers are back from the 90s archives and redesigned for today. Inspired by DJ culture, with a futuristic design that explores progressive lines and supreme street edge, this eye-catching iteration features a mesh upper with synthetic and hotmelt overlays, standout stitching, bold brand elements and a sleek shape. A juxtaposition between classic and athletic, these trend-setting trainers will be the talk of the town. IMEVA: PUMAs material for a lightweight and comfortable feel Recycled Content: The upper of this shoe is made with at least 20% recycled materials as a step toward a better future Technical mesh upper with synthetic and hotmelt overlays Lycra collar IMEVA midsole Rubber outsole Lace closure for a snug fit PUMA Formstrip at medial and lateral sides PUMA branding at heel PUMA Wordmark at tongue Style: 383107_26 Color: Cool Dark Gray-Hot Heat', 7, 'sports', '5', '2024-12-10', 0),
('Puma', 232, 102, 'SHIBUI CAT', 'Manufacturer : Puma Spoarts india pvt. ltd\r\nCountry of Origin : China\r\nImported By : Puma Spoarts india pvt. ltd\r\nWeight : 0.95 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 38529605\r\n', 3299.00, 'Slip into extreme comfort and set the trend with the new Shibui Cat Sandals from PUMA. These cosy kicks come with a fully injected IMEVA slide for a perfectly snug feel at home or wherever your feet may carry you. Minimalist PUMA Cat Logo branding adds a smooth finish.', 7, 'slides', '5', '2024-12-10', 0),
('Puma', 233, 102, 'MB.03 SLIDE', 'Manufacturer : Puma\r\nCountry of Origin : China\r\nImported By : Puma Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 39422306\r\n', 3499.00, 'The MB.03 slides are part of the legendary line-up of LaMelo Ball and PUMA Hoops. So, whether you are wearing these pre-game or post-game, slide and go just like the star player.', 7, 'slides', '5', '2024-12-10', 0),
('Puma', 234, 102, 'LEADCAT 2.0 BB LAVA', 'manufacturer : Puma India Marketing Private Ltd.\r\ncountry_of_origin : CAMBODIA\r\nimported_by : Puma India Marketing Private Ltd.\r\nproduct_dimensions :\r\nweight : 0.95 KG\r\ngeneric_name : SHOE\r\nunit_of_measurement : 1 Pair\r\nmarketed_by : Superkicks India Pvt. Ltd.\r\narticle_code : 38670501\r\n', 3299.00, 'Stand out from the crowd in our Leadcat 2.0 Pop Art Slides. A new vision of our classic silhouette, this slide plays on dissimilarity and features a moulded footbed for comfort and basketball-inspired premium textile strap. Its outsole is a moulded EVA material to ensure grip and durability.', 7, 'slides', '5', '2024-12-10', 0),
('Puma', 235, 102, 'Marine Slide', 'Manufacturer : Puma Spoarts india pvt. ltd\r\nCountry of Origin : China\r\nImported By : Puma Spoarts india pvt. ltd\r\nWeight : 0.95 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 38529605\r\n', 1699.00, 'Feel fresh with the PUMA Footwear, designed for post-activity relaxation both in and outdoors. These plush footwear feature a water repellent strap and an anti-slippage textured bottom, as well as iconic PUMA Cat Logo branding. This is the post-training essential you did not know you needed. FEATURES & BENEFITS IMEVA: PUMAs material for a lightweight and comfortable feelDETAILS Water repellent IMEVA strap IMEVA outsole for additional softness and cushioning Anti-slippage texture at outsole PUMA Cat Logo on strap', 7, 'slides', '5', '2024-12-10', 0),
('Puma', 236, 102, 'MAPF1 Leadcat 2.0 Logo IN ', 'Manufacturer : Puma Spoarts india pvt. ltd\r\nCountry of Origin : China\r\nImported By : Puma Spoarts india pvt. ltd\r\nWeight : 0.95 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 38529605\r\n', 3499.00, 'Feel fresh with the PUMA Footwear, designed for post-activity relaxation both in and outdoors. These plush footwear feature a water repellent strap and an anti-slippage textured bottom, as well as iconic PUMA Cat Logo branding. This is the post-training essential you did not know you needed. FEATURES & BENEFITS IMEVA: PUMAs material for a lightweight and comfortable feelDETAILS Water repellent IMEVA strap IMEVA outsole for additional softness and cushioning Anti-slippage texture at outsole PUMA Cat Logo on strap', 7, 'slides', '5', '2024-12-10', 0),
('Puma', 237, 102, 'Royal Challengers Bangalore ', 'Manufacturer : Puma Spoarts india pvt. ltd\r\nCountry of Origin : China\r\nImported By : Puma Spoarts india pvt. ltd\r\nWeight : 0.95 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 38529605\r\n', 2499.00, 'Step up your game with the PUMA x Royal Challengers Bangalore Unisex Slides, the perfect blend of style and comfort. Whether you are lounging or hitting the streets, these slides are a must-have for any RCB fan. Get ready to slide into the cricket season in style. DETAILS: Synthetic strap Royal Challengers Bangalore logo footbed with patterned graphic No.1 logo on the strap PUMA Cat logo', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 301, 103, 'Crocs Unisex-Adult Clogs Baya Beige', 'Material type:Croslite\r\nClosure type:Pull-On\r\nHeel type:Flat\r\nWater resistance level:Water Resistant\r\nSole material:Ethylene Vinyl Acetate\r\n', 2697.00, 'Sizing: Crocs use US sizing worldwide on all footwear, with US size displayed on the sole, use size chart to translate to UK sizes and for further info; UK and EU sizes also located in the tag.Incredibly light and easy to wear. Iconic Crocs Comfort™: original Croslite™ foam cushion.Easy to clean and dries quickly.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 302, 103, 'CROCS UNISEX ADULT CROCBAND CLOGS BLACK', 'Material type:Croslite\r\nClosure type:Pull-On\r\nHeel type:Flat\r\nWater resistance level:Water Resistant\r\nSole material:Ethylene Vinyl Acetate\r\nStyle:Clogs\r\nCountry of Origin:Indonesia\r\n', 3399.00, 'Sizing: Crocs use US sizing worldwide on all footwear, with US size displayed on the sole, use size chart to translate to UK sizes and for further info; UK and EU sizes also located in the tag.Incredibly light and easy to wear. Iconic Crocs Comfort™: original Croslite™ foam cushion.Easy to clean and dries quickly.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 303, 103, 'CROCS UNISEX ADULT CROCBAND CLOGS CHARCOL OCEAN', 'Material type:Croslite\r\nClosure type:Pull-On\r\nHeel type:Flat\r\nWater resistance level:Water                                                                              Sole material:Ethylene Vinyl Acetate\r\nStyle:Clogs\r\nCountry of Origin:Indonesia', 3399.00, 'Sizing: Crocs use US sizing worldwide on all footwear, with US size displayed on the sole, use size chart to translate to UK sizes and for further info; UK and EU sizes also located in the tag.Incredibly light and easy to wear. Iconic Crocs Comfort™: original Croslite™ foam cushion.Easy to clean and dries quickly.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 304, 103, 'CROCS UNISEX ADULT CROCBAND CLOGS WHITE', 'Material type:Croslite\r\nClosure type:Pull-On\r\nHeel type:Flat\r\nWater resistance level:Water Resistant\r\nSole material:Ethylene Vinyl Acetate\r\nStyle:Clogs\r\nCountry of Origin:Indonesia', 3399.00, 'Sizing: Crocs use US sizing worldwide on all footwear, with US size displayed on the sole, use size chart to translate to UK sizes and for further info; UK and EU sizes also located in the tag.Incredibly light and easy to wear. Iconic Crocs Comfort™: original Croslite™ foam cushion.Easy to clean and dries quickly.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 305, 103, 'CROCS UNISEX BAYABAND CLOG ARMY GREEN COBBLESTONE', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 306, 103, 'CROCS UNISEX BAYABAND CLOG BALLERINA PINK CANDY PINK', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 307, 103, 'CROCS UNISEX BAYABAND CLOG BLUE GREY ORANGE', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 308, 103, 'CROCS UNISEX BAYABAND CLOG BRIGHT COBALT SLATE GREY', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 309, 103, 'CROCS UNISEX BAYABAND CLOG CHARCOAL VOLT GREEN', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 310, 103, 'CROCS UNISEX BAYABAND CLOG CITRUS SLATE GREY', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 311, 103, 'CROCS UNISEX BAYABAND CLOG DIGITAL VIOLET', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 312, 103, 'CROCS UNISEX BAYABAND CLOG ELECTRIC PINK', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 313, 103, 'CROCS UNISEX BAYABAND CLOG LEMON WHITE', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback \r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort. ', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 314, 103, 'CROCS UNISEX BAYABAND CLOG MINERAL BLUE PISTACHIO', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 315, 103, 'CROCS UNISEX BAYABAND CLOG NEON PUPLE WHITE', 'Product details\r\nMaterial type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 316, 103, 'CROCS UNISEX BAYABAND CLOG PEPPER NAVY', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 317, 103, 'CROCS UNISEX BAYABAND CLOG SLATE GREY', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 318, 103, 'CROCS UNISEX BAYABAND CLOG STUCCO BRIGHT COBALT', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 319, 103, 'CROCS UNISEX BAYABAND CLOG WHITE NAVY', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 320, 103, 'CROCS UNISEX BAYABAND CLOG WINTER WHITE MULTI', 'Material type:Ethylene Vinyl Acetate\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nSole material:Plastic\r\nStyle:Slingback\r\nCountry of Origin:Indonesia\r\n', 3299.00, 'Confidently comfortable what happens when you combine two of crocs most iconic clog silhouettes - the baya and the croc band -into one special pair? You get the bayaband clog, a style that takes the fashion-athletic spirit of the originals to another level. New graphic options include floral, camo, a tropical floral band, and a palm tree graphic band. Bayaband graphic ii clog details: incredibly light and easy to wear customizable with jibbitz charms pivoting heel straps for a more secure fit iconic crocs comfort: lightweight. Flexible. 360-degree comfort.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 321, 103, 'CROCS UNISEX OFF GRID CLOG BLACK', 'Material type:Thermoplastic Polyurethane\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Waterproof\r\nSole material:Croslite\r\nStyle:Clogs\r\nCountry of Origin:Vietnam\r\n\r\n', 3179.00, 'Digitally inspired and ever-changing, the Off Grid Collection embodies speed in a street-ready form. Its unique sculping and contouring offers a new look and feel while maintaining comfort that’s synonymous with Crocs.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 322, 103, 'CROCS UNISEX OFF GRID CLOG LIGHT GREY', 'Material type:Thermoplastic Polyurethane\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Waterproof\r\nSole material:Croslite\r\nStyle:Clogs\r\nCountry of Origin:Vietnam\r\n', 3179.00, 'Digitally inspired and ever-changing, the Off Grid Collection embodies speed in a street-ready form. Its unique sculping and contouring offers a new look and feel while maintaining comfort that’s synonymous with Crocs.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 323, 103, 'CROCS UNISEX OFF GRID CLOG WHITE', 'Material type:Thermoplastic Polyurethane\r\nClosure type:Pull-On\r\nHeel type:No Heel\r\nWater resistance level:Waterproof\r\nSole material:Croslite\r\nStyle:Clogs\r\nCountry of Origin:Vietnam', 3179.00, 'Digitally inspired and ever-changing, the Off Grid Collection embodies speed in a street-ready form. Its unique sculping and contouring offers a new look and feel while maintaining comfort that’s synonymous with Crocs.', 7, 'Clogs', '5', '2024-12-10', 0),
('Crocs', 324, 103, 'CROCS UNISEX BAYA II SLIDE BLACK', 'Material type:Croslite\r\nWater resistance level:Water Resistant\r\nStyle:Flat\r\nClosure type:Slip On\r\nHeel type:Flat\r\nCountry of Origin: China\r\n', 1797.00, 'Iconic Crocs Comfort™: Lightweight. Flexible. 360-degree comfort. Easy to clean and quick to dry Incredibly light and fun to wear', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 325, 103, 'CROCS UNISEX BAYA II SLIDE COBBLESTONE', 'Material type:Croslite\r\nWater resistance level:Water Resistant\r\nStyle:Flat\r\nClosure type:Slip On\r\nHeel type:Flat\r\nCountry of Origin: China\r\n', 1797.00, 'Iconic Crocs Comfort™: Lightweight. Flexible. 360-degree comfort. Easy to clean and quick to dry Incredibly light and fun to wear', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 326, 103, 'CROCS UNISEX BAYA II SLIDE NAVY', 'Material type:Croslite\r\nWater resistance level:Water Resistant\r\nStyle:Flat\r\nClosure type:Slip On\r\nHeel type:Flat\r\nCountry of Origin: China\r\n', 1797.00, 'Iconic Crocs Comfort™: Lightweight. Flexible. 360-degree comfort. Easy to clean and quick to dry Incredibly light and fun to wear', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 327, 103, 'CROCS UNISEX BAYA II SLIDE WHITE', 'Material type:Croslite\r\nWater resistance level:Water Resistant\r\nStyle:Flat\r\nClosure type:Slip On\r\nHeel type:Flat\r\nCountry of Origin: China\r\n', 1797.00, 'Iconic Crocs Comfort™: Lightweight. Flexible. 360-degree comfort. Easy to clean and quick to dry Incredibly light and fun to wear', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 328, 103, 'CROCS UNISEX BAYA SANDAL COBBLESTONE ', 'Material type:Croslite\r\nWater resistance level:Water Resistant\r\nStyle: Ankle-Strap\r\nClosure type:Pull On\r\nHeel type:Flat\r\nCountry of Origin: Vietnam\r\n', 1719.00, 'Crocs, Inc. is a world leader in innovative casual footwear for men, women and children with more than $1 billion in annual revenue. The company offers several distinct shoe collections with more than 300 four-season footwear styles. All Crocs shoes feature Croslite material, a proprietary, revolutionary technology that gives each pair of shoes the soft, comfortable, lightweight, non-marking and odor-resistant qualities that Crocs wearers know and love. Crocs celebrates the fun of being a little different and encourages fans to “Find Your Fun” in every colorful pair of shoes, from the iconic clog to loafers, sneakers, sandals, boots and heels. Since its inception in 2002, Crocs has sold more than 200 million pairs of shoes in more than 90 countries around the world. Crocs started its India operations in the year 2007. In India, Crocs products are also available in more than 300 multi-brand outlets and 34 exclusive stores (including 1 kiosk and 2 factory outlets).', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 329, 103, 'CROCS UNISEX BAYA SANDAL NAVY', 'Material type:Croslite\r\nWater resistance level:Water Resistant\r\nStyle: Ankle-Strap\r\nClosure type:Pull On\r\nHeel type:Flat\r\nCountry of Origin: Vietnam\r\n', 1719.00, 'Crocs, Inc. is a world leader in innovative casual footwear for men, women and children with more than $1 billion in annual revenue. The company offers several distinct shoe collections with more than 300 four-season footwear styles. All Crocs shoes feature Croslite material, a proprietary, revolutionary technology that gives each pair of shoes the soft, comfortable, lightweight, non-marking and odor-resistant qualities that Crocs wearers know and love. Crocs celebrates the fun of being a little different and encourages fans to “Find Your Fun” in every colorful pair of shoes, from the iconic clog to loafers, sneakers, sandals, boots and heels. Since its inception in 2002, Crocs has sold more than 200 million pairs of shoes in more than 90 countries around the world. Crocs started its India operations in the year 2007. In India, Crocs products are also available in more than 300 multi-brand outlets and 34 exclusive stores (including 1 kiosk and 2 factory outlets).', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 330, 103, 'CROCS UNISEX BAYA SANDAL WHITE', 'Material type:Croslite\r\nWater resistance level:Water Resistant\r\nStyle: Ankle-Strap\r\nClosure type:Pull On\r\nHeel type:Flat\r\nCountry of Origin: Vietnam\r\n', 1719.00, 'Crocs, Inc. is a world leader in innovative casual footwear for men, women and children with more than $1 billion in annual revenue. The company offers several distinct shoe collections with more than 300 four-season footwear styles. All Crocs shoes feature Croslite material, a proprietary, revolutionary technology that gives each pair of shoes the soft, comfortable, lightweight, non-marking and odor-resistant qualities that Crocs wearers know and love. Crocs celebrates the fun of being a little different and encourages fans to “Find Your Fun” in every colorful pair of shoes, from the iconic clog to loafers, sneakers, sandals, boots and heels. Since its inception in 2002, Crocs has sold more than 200 million pairs of shoes in more than 90 countries around the world. Crocs started its India operations in the year 2007. In India, Crocs products are also available in more than 300 multi-brand outlets and 34 exclusive stores (including 1 kiosk and 2 factory outlets).', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 331, 103, 'CROCS UNISEX BAYABAND MINERAL BLUE PISTACHIO', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 332, 103, 'CROCS UNISEX BAYABAND SLIDE BLACK AND WHITE', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 333, 103, ' CROCS UNISEX BAYABAND SLIDE BRIGHT COBALT', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 334, 103, 'CROCS UNISEX BAYABAND SLIDE CHARCOAL AND VOLT GREEN', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 335, 103, 'CROCS UNISEX BAYABAND SLIDE ELECTRIC PINK', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 336, 103, 'CROCS UNISEX BAYABAND SLIDE NAVY PEPPER', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 337, 103, 'CROCS UNISEX BAYABAND SLIDE SLATE GREY AND LIME PUNCH', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Crocs', 338, 103, 'CROCS UNISEX BAYABAND SLIDE WHITE AND NAVY', 'Material type:Croslite\r\nClosure type:Slip On\r\nHeel type:No Heel\r\nWater resistance level:Water Resistant\r\nStyle:Casual\r\nSole material:Croslite\r\nCountry of Origin:India\r\n', 2199.00, 'What happens when you combine two of Crocs’ most iconic silhouettes, the Baya and the Crocband™, into one special pair? You get these Bayaband slides, a style that takes the fashion-athletic spirit of the originals to another level. The result is a go-anywhere style staple that lets you slide in and stay cool while throwing off an extra pop of Crocs spirit. And of course, molded Croslite™ construction means you’ll stay comfortable all day long. Bayaband Slide Details: • Built on our sporty Crocband™silhouette • Incredibly light and fun to wear • Iconic Crocs Comfort™: original Croslite™ foam cushion', 7, 'slides', '5', '2024-12-10', 0),
('Adidas', 401, 104, 'SAMBA OG', 'Manufacturer : Adidas\r\nCountry of Origin : Vietnam\r\nImported By : adidas India Marketing Private Limited\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IH4882\r\n', 10999.00, 'HERITAGE TRAINERS WITH A MASTER MIX OF SUEDE AND LEATHER.\r\nInspired by the original indoor football training shoe, these Samba OG shoes still have it after more than 70 years. The leather upper, serrated 3-Stripes and reinforced toe stay true to the adidas original. Add in suede accents and heel patches, and you have a modern classic.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 402, 104, 'WMNS CAMPUS 00S', 'Manufacturer : Adidas\r\nCountry of Origin : India\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : GY0042\r\n', 10999.00, 'Campus 00s Shoes\r\nAn elevated take on the Campus legacy.\r\nThese adidas shoes blend heritage design with modern trends for a look that transcends the decades. The suede upper shapes an iconic court-inspired silhouette updated for today\'s style sensibilities. Serrated 3-Stripes add subtle grunge vibes while the gum rubber outsole keeps the look authentic.\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 403, 104, 'CRAZY 1', 'Manufacturer : Adidas\r\nCountry of Origin : Vietnam\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IF1142\r\n', 14999.00, 'Iconic adidas basketball shoes made for dynamic movement.\r\nOne of the most iconic basketball shoes around is back. The adidas Crazy 1 pays homage to its 2000 origins with premium materials inspired by vintage furniture. A suede upper, tumbled leather accents and embroidered details evoke best-in-class comfort. The EVA midsole and rubber outsole provide cushioning and traction from landing to push-off. A herringbone outsole signs off the style.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 404, 104, 'OZMILLEN', 'Manufacturer : Adidas\r\nCountry of Origin : India\r\nImported By : adidas India Marketing Private Limited\r\nWeight : 1.10Kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IF9597\r\n', 10999.00, 'Easy-wearing adidas OZMILLEN shoes with a standout look.\r\nSleek, stylish and eye-catching. These adidas OZMILLEN shoes merge bold \'90s energy with a sophisticated tonal design. Leather overlays add subtle texture to the mesh upper while an Adiplus midsole serves up undeniable comfort with every step.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 405, 104, 'KAIWA', 'Manufacturer : Adidas\r\nCountry of Origin : China\r\nImported By : Adidas Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IG4057\r\n', 34999.00, 'A MODERN RUNNER STYLE BY Y-3.\r\n\"Y-3 is a strong examination of the blend of sport and style and the tension caused by mixing tradition with all that is modern.\"  — Yohji Yamamoto Pulling from the archives, Y-3 returns a running silhouette to the streets with the progressive Kaiwa shoes. A minimalist design philosophy exposes the roots of the pioneering sport style. The sock-like construction is crafted with a premium leather and a neoprene upper. Enhanced comfort is provided by the lightweight midsole cushioning.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 406, 104, 'SUPERSTAR XLG', 'Manufacturer : Adidas\r\nCountry of Origin : Indonesia\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IF3001\r\n', 7199.00, 'ICONIC SHOES UPDATED WITH AN ELEVATED MIDSOLE.\r\nThe adidas Superstar shoes have continued to show off their timeless style since their debut more than 50 years ago. This pair takes core design elements like the shell toe and 3-Stripes but elevates the midsole for a touch of attitude. Energetic colours give you endless combinations to mix and match with your outfits.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 407, 104, 'YEEZY 700 V3 AZAEL', 'Manufacturer : Adidas\r\nCountry of Origin : Indonesia\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IF3001\r\n', 32999.00, 'THE YEEZY BOOST 700 MNVN METALLIC FEATURES AN UPPER COMPOSED OF LIGHTWEIGHT POLYESTER WITH NO-SEW OVERLAYS OFFERING ENHANCED BREATHABILITY, FLEXIBILITY AND COMFORT. NO-TIE BUNGEE LACES ALLOWS FOR EASY ON AND OFF WEAR, WHILE REFLECTIVE MATERIAL THROUGHOUT SPECIFIC AREAS OF THE MODEL ADDS UNIQUE DESIGN CUES AND VISUAL INTEREST. THE FULL-LENGTH DROP-IN BOOST MIDSOLE PROVIDES THE ULTIMATE UNDERFOOT CUSHIONING EXPERIENCE, WHILE THE PU MIDSOLE ADDS COMFORT AND DURABILITY.', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 408, 104, 'Yeezy Boost 700 WaveRunner', 'Manufacturer : Adidas\r\nCountry of Origin : Indonesia\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IF3001\r\n', 34599.00, 'Step into the world of comfort and style with the iconic Yeezy 700 \"Waverunner\". Designed by the creative genius Kanye West, this sneaker is more than just footwear, it\'s a statement. With its unique blend of retro and futuristic aesthetics, the Yeezy 700 \"Waverunner\" has become a must-have for sneaker enthusiasts and fashion-forward individuals alike.\r\nThe Yeezy 700 \"Waverunner\" boasts a multi-layered upper, combining suede, mesh and leather in a harmonious symphony of textures. The chunky midsole, a signature feature of the Yeezy 700 line, is accentuated by vibrant pops of orange, contrasting perfectly with the overall muted tones of the sneaker. The colorway is an eclectic mix of solid grey, chalk white, and black, making it versatile enough to be paired with any outfit.\r\nBut it\'s not all about looks. The Yeezy 700 \"Waverunner\" is also about performance. The sneaker features Adidas\' proprietary Boost technology, encapsulated within the midsole, ensuring ultimate comfort and support for all-day wear. The sneaker\'s SKU is B75571, a detail that sneakerheads will appreciate.\r\nWhether you\'re a sneaker collector, a Kanye West fan, or just someone who appreciates great design and comfort, the Yeezy 700 \"Waverunner\" is a must-have addition to your collection.\r\n', 6, 'casuals', '5', '2024-12-10', 0);
INSERT INTO `products` (`Brand_name`, `product_id`, `brand_id`, `model`, `description`, `original_price`, `about`, `category_id`, `type`, `stock`, `arrival_date`, `is_new`) VALUES
('Adidas', 409, 104, 'NMD_S1', 'Manufacturer : Adidas\r\nCountry of Origin : Vietnam\r\nImported By : adidas India Marketing Private Limited\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : GW4652\r\n', 11999.00, 'These adidas shoes keep you firmly planted, even though they feel like you\'re walking on clouds. A sock-like upper hugs your feet for ultimate comfort while encapsulated BOOST cushioning with midsole plugs returns energy with every step. This look is all about embracing what grounds you, even in the ever-changing city. Designed to inspire you to experience more, they\'re get-out-there-and-go ready. This shoe\'s upper is made with a high-performance yarn which contains at least 50% Parley Ocean Plastic — reimagined plastic waste, intercepted on remote islands, beaches, coastal communities and shorelines, preventing it from polluting our ocean. The other 50% of the yarn is recycled polyester.', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 410, 104, 'YEEZY 500 BONE WHITE', 'Manufacturer : Adidas\r\nCountry of Origin : China\r\nImported By : adidas India Marketing Private Limited\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : ID5114\r\n', 21999.00, 'The YEEZY 500 Bone white features an upper composed of cow suede, premium leather and mesh. A rubber wrap along the midsole of the foot provides support and abrasion resistance with reflective piping details around the lace eyelets that add visibility in low-light conditions. The adiPRENE+ cushioning absorbs impact and optimizes rebound while a light rubber outsole provides traction.', 6, 'casuals', '5', '2024-12-10', 0),
('Adidas', 411, 104, 'WMNS KANTANA', 'Material type:Leather, Rubber, Suede\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:Vietnam\r\n', 5049.00, 'Dare to be different. These adidas shoes bring a fresh take on a classic look that calls to your originality. With a rubber Badge of Sport and iconic forms, these trainers level up any outfit.', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 412, 104, 'ZX 2K BOOST 2.0', 'Manufacturer : Adidas\r\nCountry of Origin : China\r\nImported By : adidas India Marketing Private Limited\r\nProduct Dimensions :\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : GW8284\r\n', 6999.00, 'ZX SHOES MADE IN PART WITH RECYCLED CONTENT.\r\nLook good all season long in these adidas shoes with a mesh and neoprene upper. Bring your style into the future fresh from the past with iconic ZX details and a perfect palette, from neutrals to hot pops of colour. Step out in total comfort with a responsive BOOST midsole. Total winner. Made in part with recycled content generated from production waste, e.g., cutting scraps and post-consumer household waste, to avoid the larger environmental impact of producing virgin content.\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 413, 104, 'WMNS RACER TR21', 'Material type: Thermoplastic Polyure, Textile, Rubber\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:Vietnam\r\n', 4599.00, 'Dare to be different. These adidas shoes bring a fresh take on a classic look that calls to your originality. With a rubber Badge of Sport and iconic forms, these trainers level up any outfit.', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 414, 104, 'WMNS BRAVADA 2.0', 'Material type:Leather, Rubber, Suede\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:Vietnam\r\n', 7856.00, 'Theres something forever classic about a canvas shoe, and this adidas design makes the most of it. The thick platform sole kicks up your look with attitude and edge, but never at the expense of comfort. Cloudfoam gives you all-day cushioning for easy wear, and a rubber outsole steps a solid grip while rounding out the casually cool profile. \"We partner with Better Cotton to improve cotton farming globally. Better Cotton makes global cotton production better for the people who produce it, better for the environment it grows in, and better for the sectors future.  Better Cotton is sourced via a chain-of-custody model called mass balance. This means that Better Cotton is not physically traceable to end products. However, Better Cotton Farmers benefit from the demand for Better Cotton in equivalent volumes to those we \"source.\" Find out more here: bettercotton.org/learnmore', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 415, 104, 'WMNS GRAND COURT 2.0', 'Material type: Thermoplastic Polyure, Textile, Rubber\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:Vietnam\r\n', 5032.00, 'If you could only have one pair of sneakers, this could be them. These adidas Grand Court shoes with the classic 3-Stripes keep your sneaker game sharp and clean. Cloudfoam Comfort cushioning keeps the insides soft and pillowy. Pair them with any of your favourite pants because these will take you anywhere and everywhere. Made with a series of recycled materials, this upper features at least 50% recycled content. This product represents just one of our solutions to help end plastic waste', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 416, 104, 'WMNS ALPHARESPONSE', 'Material type: Thermoplastic Polyure, Textile, Rubber\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: Synthetic Resin\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 8999.00, 'Find your stride in these adidas running shoes. A mix of springy Bounce and ultra lightweight Lightstrike in the midsole fuels every step of your run. A mesh upper keeps the air flowing as the miles tick by. An Adiwear outsole delivers durable traction to help you go the distance. This product features at least 20% recycled materials. By reusing materials that have already been created, we help to reduce waste and our reliance on finite resources and reduce the footprint of the products we make.', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 417, 104, 'BREAKNET 2.0', 'Material type: Thermoplastic Polyure, Textile, Rubber\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 5899.00, 'These adidas sneakers take their cues from centre court, but theyll gain just as many admiring glances strolling along city streets. With their clean, smooth lines and hints of subtle colour, they team effortlessly with everything from workout shorts to chinos, track pants to jeans. Made with a series of recycled materials, this upper features at least 50% recycled content. This product represents just one of our solutions to help end plastic waste', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 418, 104, 'PURECOMFORT', 'Material type: Thermoplastic Polyure, Textile, Rubber\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:SNEKERS\r\nCountry of Origin:INDI', 7599.00, 'Adidas sells a range of clothing items, varying from mens and womens t-shirts, jackets, hoodies, pants and leggings. The adidas brand offers apparel for every sport, every fashion, every style, whether you are an athlete or fashionista.', 9, 'casuals', '5', '2024-12-10', 0),
('Adidas', 419, 104, 'FLUIDFLOW 3.0', 'Material type:MESH\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 4214.00, 'Life does not stand still. Now you would not have to either with these ultra-modern adidas sneakers in your lineup. The soft knit upper is lined for comfort, and lightweight Bounce cushioning keeps you going and going. Sporty yet refined, these sneakers transcend dress codes.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 420, 104, 'RESPONSE RUNNING', 'Material type:MESH\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 3727.00, 'Life does not stand still. Now you woould not have to either with these ultra-modern adidas sneakers in your lineup. The soft knit upper is lined for comfort, and lightweight Bounce cushioning keeps you going and going. Sporty yet refined, these sneakers transcend dress codes.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 421, 104, 'COURUN AVANT M RUNNING', 'Material type:MESH\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 3072.00, 'This Springy Bounce cushioning ensures comfort through even the most gruelling sessions. The tooling The Shank was created by using data from hundreds of runners. That data helped to design shank which offers different angles of support placed where you need it. It supports explosive movement in any direction. The higher degree of flexibility is one of the main benefits of this type of sole and provides better shock absorption. Non-marking rubber outsole for excellent grip and grooves on the sole make it flexible. Rubber at the forefoot and heel gives you the durability to keep going.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 422, 104, 'X_PLRBOOST', 'Material type:MESH\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 7065.00, 'Up the style. Up the energy. These BOOST sneakers are responsive and stylish. The soft upper is lined for comfort. It sits atop a BOOST midsole that gives you ultimate comfort with each step. Made with a series of recycled materials, this upper features at least 50% recycled content. This product represents just one of our solutions to help end plastic waste.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 423, 104, 'BARRICADE 13 M', 'Material type:MESH\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material:Rubber\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 8479.00, 'Take control of the court in these adidas Barricade tennis shoes. Torsion System provides match-turning stability, while the asymmetric lacing locks you in for quick cuts and slides. A REPETITOR midsole adds support and smooth transitions from one step to the next. Geofit Sensepods follow your heels natural shape, ensuring comfort and support that lasts through to match point. This product features at least 20% recycled materials. By reusing materials that have already been created, we help to reduce waste and our reliance on finite resources and reduce the footprint of the products we make.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 424, 104, 'IVP ULTRA BOOST OG', 'Material type:MESH\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: Thermoplastic Elastomers\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 19999.00, 'Take control of the court in these adidas Barricade tennis shoes. Torsion System provides match-turning stability, while the asymmetric lacing locks you in for quick cuts and slides. A REPETITOR midsole adds support and smooth transitions from one step to the next. Geofit Sensepods follow your heels natural shape, ensuring comfort and support that lasts through to match point. This product features at least 20% recycled materials. By reusing materials that have already been created, we help to reduce waste and our reliance on finite resources and reduce the footprint of the products we make.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 425, 104, 'SWITCH MOVE U', 'Material type: Textile\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: Thermoplastic Elastomers\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 9666.00, 'The easier your run feels, the farther you can go. These adidas running shoes cushion your stride with a lightweight EVA midsole. They are designed to deliver a smooth ride that enhances forward momentum so that every kilometre feels as good as the one before. The comfy mesh upper rides on an Adiwear outsole for optimum durability and grip. Made with a series of recycled materials, this upper features at least 50% recycled content. This product represents just one of our solutions to help end plastic waste.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 426, 104, 'SWITCH FWD M', 'Material type: Thermoplastic Polyure, Mesh, Rubber\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: Thermoplastic Elastomers\r\nStyle:Sports Shoes\r\nCountry of Origin:INDIA\r\n', 13545.00, '3D molded heel:Provides a more comfortable and secure lock-down fit | 3D molded heel:Provides a more comfortable and secure lock-down fit | Continental rubber outsole:Extraordinary grip. | Engineered Mesh Upper:COMFORT, FLEXIBILITY AND BREATHABILITY | Engineered Mesh Upper:COMFORT, FLEXIBILITY AND BREATHABILITY | Engineered Mesh Upper:Different structures are engineered in strategic zones for structure and stability where you need it while still maximizing breathability | Engineered Mesh Upper:Different structures are engineered in strategic zones for structure and stability where you need it while still maximizing breathability | RECYCLED MATERIALS PRIME - PRIMEGREEN:END PLASTIC WASTE. | RECYCLED MATERIALS PRIME - PRIMEGREEN:Upper contains a minimum of 50% recycled content | TPU plate:provides propulsion. | TPU plate:provides propulsion. | TPU plate:provides protection. | TPU plate:provides protection.', 7, 'sports', '5', '2024-12-10', 0),
('Adidas', 427, 104, 'ADIFOM IIINFINITY MULES', 'Manufacturer : Adidas\r\nCountry of Origin : India\r\nImported By : Adidas Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IH2814\r\n', 5999.00, 'Comfortable mules for effortless style.\r\nAfter a few hard-fought games on the hardwood, slip into comfort with these adidas mules. Foam construction cradles your feet while the reflective finish adds style after the buzzer. Their slip-on design means you can kick them off as easily as you kick back.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Adidas', 428, 104, 'ISLAND CLUB ADILETTE 22', 'Manufacturer : Adidas\r\nCountry of Origin : Vietnam\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : HQ4672\r\n', 5999.00, 'FUTURISTIC SLIDES INSPIRED BY TOPOGRAPHIC MAPS — SLEEK, SPORTY STYLE.\r\nThe Island Club collection conjures feelings of an endless summer. Poolside or not, everyday feels like a vacation in the playful yet chic collection that mixes pastel hues and vivid color-blocking with tonal head-to-toe fits. The collection is heavy on nostalgia and good vibes. Nothing says summer like the first day you officially slip on and step out in fresh slides. With their eye-catching design, The Island Club Adilette 22 Slides are a stylish addition to your seasonal rotation. A one-piece construction delivers ultimate comfort for all day lounging, while the 3D Topographic-inspired look adds an innovative edge.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Adidas', 429, 104, 'ADILETTE', 'Manufacturer : Adidas\r\nCountry of Origin : India\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IG9285\r\n', 3999.00, 'Flow through your day in style with these versatile slides.There are few styles that work for the pool, post-gym and casual hangouts with friends. Luckily, these adidas Adilette slides have you covered, with a minimalist yet versatile style thats always in fashion. This version of the iconic slip-on features a quick-drying polyurethane strap and soft rubber outsole for comfort that lasts.', 7, 'slides', '5', '2024-12-10', 0),
('Adidas', 430, 104, 'ADILETTE LITE', 'Manufacturer : Adidas\r\nCountry of Origin : India\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : GZ6196\r\n', 2999.00, 'Extra-soft Adilette slides all about comfort.\r\nKeep things light. This applies to your life and to your footwear. These adidas Adilette slides make everything easy. All you have to do is slip them on. They work just as well when you are out running around as they do when you are in the house. You can thank the lightweight cushioning for that.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Adidas', 431, 104, 'ADILETTE CLOGS', 'Manufacturer : Adidas\r\nCountry of Origin : Vietnam\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : GZ5314\r\n', 8599.00, 'SLIP-ON CLOGS FOR EVERYDAY COMFORT.\r\nBased on the iconic adidas slide, these clogs are as functional as they are comfortable. Whether you are walking to the gym or pool for an early-morning workout or just want to keep the slouchy-casual vibe going all through your day, slip your feet into the contoured footbeds and head for the door.\r\n', 7, 'slides', '5', '2024-12-10', 0),
('Adidas', 432, 104, 'Contaro ', 'Manufacturer : Adidas\r\nCountry of Origin : India\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IG9285\r\n', 1299.00, 'Flow through your day in style with these versatile slides.There are few styles that work for the pool, post-gym and casual hangouts with friends. Luckily, these adidas Adilette slides have you covered, with a minimalist yet versatile style thats always in fashion. This version of the iconic slip-on features a quick-drying polyurethane strap and soft rubber outsole for comfort that lasts.', 7, 'slides', '5', '2024-12-10', 0),
('Adidas', 433, 104, 'Adilette Boost', 'Manufacturer : Adidas\r\nCountry of Origin : India\r\nImported By : Adidas India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Slide\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IG9285\r\n', 2640.00, 'Flow through your day in style with these versatile slides.There are few styles that work for the pool, post-gym and casual hangouts with friends. Luckily, these adidas Adilette slides have you covered, with a minimalist yet versatile style thats always in fashion. This version of the iconic slip-on features a quick-drying polyurethane strap and soft rubber outsole for comfort that lasts.', 7, 'slides', '5', '2024-12-10', 0),
('Converse ', 501, 105, 'Chuck Taylor All Star', 'Product Dimensions:\r\nLength : 36.6 cm\r\nWidth: 14.8 cm\r\nHeight: 12.2 cm\r\n\r\nItem Weight: 0.8 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nAdora Footwear Limited Tam Diep Industrial Zone, Tam Diep City, Ninh Binh Province, Vietnam\r\n', 4299.00, 'ii)	We could tell you that it\'s the OG basketball shoe, created over 100 years ago. Or that the design has largely stayed the same, because why mess with a good thing. Or how it became the unofficial sneaker of all your favorite artists and musicians, who each made it their own. Yeah, we could share a lot of stories, but the one that matters most isn\'t ours it\'s yours. It\'s how and where you take your Chucks. The legacy is long, but what comes next is up to you. We just make the shoe. You make the stories.\r\niii)	High-top sneaker with canvas upper.\r\niv)	Iconic silhouette.\r\nv)	Branded star ankle patch.\r\nvi)	OrthoLite insole for comfort.\r\nvii)	Diamond outsole tread.\r\nviii)	OrthoLite is a trademark of O2 Partners, LLC.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse ', 503, 105, 'Converse All Star BB Shift CX', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd,\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nWeilina Vietnam Footwear Co. Ltd Vuc Phac Village, Dinh Lien Commune, Yen Dinh District Thanh Hoa, Vietnam\r\n', 9499.00, 'When the basketball court is your second home, the All Star BB Shift CX comes to play. It’s made for quick, responsive movement with extra bounce courtesy of an Air Zoom unit. This one arrives with colors inspired by those style icons who dominate the hardwood all over the world.\r\n•	Textile upper with 3D-print details give you a performance-ready look and feel\r\n•	CX cushioning with an Air Zoom unit in forefoot helps provide next-level comfort and responsiveness\r\n•	High CX foam midsole and a rubber outsole tread help provide traction\r\n•	Dynamic stretch collar with an ankle pad helps offer comfort\r\n•	Adjustable cable lacing system helps you find the right support\r\nItem Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse', 504, 105, 'Sean Green One Star Pro', 'Unit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nVinh Long Footwear Co., Ltd Hoa Phu Industrial Zone, Thanh Hung Hamlet, Hoa Phu Village, Long Ho District, Vinh Long Province, Vietnam\r\n', 6499.00, 'Converse CONS team rider Sean Greene’s leaves a groove on every San Francisco street, wall, and sidewalk in his path. For his debut One Star Pro colorway, Sean added details and materials that speak to his grit, all-in commitment, and perpetual need for speed. Using a canvas upper with suede paneling, the Sean Greene One Star Pro is stealthily designed to be seen, adding reflective materials in the Star and heel stripe, custom sock liner artwork, and an embossed homage to the homies. With rubber-backed durability in high abrasion areas, elastic tongue straps, CX Foam sock liner, and grippy traction rubber outsole, the Sean Greene One Star Pro mixes Converse heritage with ground-up enhancements for skateboarding.\r\n•	12oz canvas upper with suede paneling in high abrasion areas and traction rubber outsole\r\n•	CX Foam sock liner with Sean’s name called out\r\n•	Elastic tongue straps help keep tongue in place\r\n•	PSP26 embossed into the foxing tape in memory of Pablo Ramirez\r\n•	Reflective star and heel stripe\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse ', 505, 105, 'Run Star Trainer', 'Item Weight: 1.0 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nWeilina Vietnam Footwear Co. Ltd Vuc Phac Village, Dinh Lien Commune, Yen Dinh District Thanh Hoa, Vietnam\r\n', 6499.00, 'Meet the Run Star Trainer-a celebration of sports, style, and heritage. Sleek details and luxe cushioning pair well with all your favorite \'fits, day and night. The next step in the Star Chevron legacy is here.\r\n•	A durable nylon upper with suede overlays and leather accents for a luxe look and feel\r\n•	CX foam cushioning helps provide next-level comfort\r\n•	Traction rubber outsole helps provide grip\r\n•	Punched eyelets and waxed laces add a premium touch\r\n•	Iconic Star Chevron, All Star, and Converse logos\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse', 506, 105, 'Run Star Hike Platform Sketch', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nAurora Vietnam Industrial Footwear Co.,Ltd Thien Huong Ward, Thuy Nguyen District, Haiphong, Vietnam\r\n', 7499.00, 'A caricature-inspired take on the fan-favorite platform—this edition of the Run Star Hike exaggerates unmistakable All Star elements in an unexpected way. With signature Chuck Taylor style as its muse, these lifted high tops show off your creative side with oversized, undersized, and crooked design details. Punch up your palette in trendy pink, or keep it classic in goes-with-everything white.\r\n•	Durable canvas upper for that classic chucks look and feel\r\n•	Ortholite cushioning helps provide optimal comfort\r\n•	Crooked stitching and distorted design details for an unexpectedly playful look\r\n•	Exaggerated, saw-tooth outsole for expressive style\r\n•	Oversized chuck taylor ankle patch and 3d heel star branding\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse ', 507, 105, 'Chuck Taylor All Star Tailored Lines', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nAurora Vietnam Industrial Footwear Co.,Ltd Thien Huong Ward, Thuy Nguyen District, Haiphong, Vietnam\r\n', 5499.00, 'Dressing up your Chucks has never been easier. Drawing inspiration from the casual sophistication of blazers, these high tops blend unmistakable All Star styling with refined updates. Luxe, mixed materials and versatile, tonal colors come together with understated stitched details for an effortless, upscale look.\r\n•	Textile upper, with that classic chucks look\r\n•	Ortholite cushioning helps provide optimal comfort\r\n•	Leather overlays and ornate stitching adds a refined touch\r\n•	Heel loop for ease of entry\r\n•	Iconic chuck taylor ankle patch and all star license plate\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse', 508, 105, 'Chuck 70 Plus X-Hi', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nAurora Vietnam Industrial Footwear Co.,Ltd Thien Huong Ward, Thuy Nguyen District, Haiphong, Vietnam\r\n', 8999.00, 'An unexpected update on an all-time classic, the Chuck 70 Plus XHi distorts iconic Chuck Taylor DNA. Bold lines, sliced details, and an extra-high cut keep all eyes on you. Give your favorite looks a punk edge—from the pit to the park, these Chucks come ready to steal the show.\r\n•	Canvas upper, with that classic chucks look\r\n•	Ortholite cushioning helps provide optimal comfort\r\n•	Zipper entry for easy on and off\r\n•	An elongated tongue and split rubber outsole distort heritage chuck taylor details\r\n•	Iconic chuck taylor ankle patch and vintage all star license plate\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse ', 509, 105, 'Pro Blaze V2 \'90S Sport', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nWeilina Vietnam Footwear Co. Ltd Vuc Phac Village, Dinh Lien Commune, Yen Dinh District Thanh Hoa, Vietnam\r\n', 5499.00, 'Bring throwback style to every look with the Pro Blaze. Tonal leather blends with throwback \'90s color and detailing for a classic, easy-to-wear look.\r\n•	Premium faux leather gives you durability and a luxe look\r\n•	Lightweight eva foam helps provide optimal comfort\r\n•	Single ankle strap helps you adjust the fit\r\n•	Colors inspired by \'90s sport styles\r\n•	Pop-color iconic star chevron\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse', 510, 105, 'Chuck Taylor All Star Free Spirit Florals', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nAurora Vietnam Industrial Footwear Co.,Ltd Thien Huong Ward, Thuy Nguyen District, Haiphong, Vietnam\r\n', 5499.00, 'Crafted florals, bright pastels, and gold metallics take over these classic Chucks. Toss them on to bring a bit of boho flair to all your free-spirited \'fits.\r\n•	Canvas upper with screen-printed and embroidered floral details\r\n•	Ortholite cushioning helps provide optimal comfort\r\n•	Gold eyelets on the upper and gold shoelace caps for a luxe touch\r\n•	Iconic chuck taylor patch reps the converse legacy\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse ', 511, 105, 'Converse x Isabel Marant Chuck 70', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter\r\nBhaane Retail Pvt Ltd\r\nF-88, Okhla Phase 1, New Delhi 110020, IN\r\n\r\nCountry of Origin\r\nVietnam\r\n\r\nManufacturer\r\nAurora Vietnam Industrial Footwear Co.,Ltd Thien Huong Ward, Thuy Nguyen District, Haiphong, Vietnam\r\n', 11499.00, 'The French fashion designer puts her effortlessly elegant spin on the premium Chuck 70. Blending effortless luxury style cues with classic Converse details, the limited-edition design captures the essence of Isabel Marant\'s laid back but elevated aesthetic. Sophisticated materials, raw edge overlays and vibrant swirls of color create a distinctive carefree vibe.\r\n•	Limited-edition low-top sneaker designed by Isabel Marant\r\n•	Frayed cotton and polyester jacquard upper with multi-colored marble transfer print pinstripes\r\n•	Translucent outsole with matching multi-color print\r\n•	Isabel Marant branded tongue label\r\n•	Printed and debossed Chuck Taylor patch\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Converse ', 512, 105, 'Pro Blaze Classic', 'Item Weight: 1 kg\r\n\r\nGeneric Name: Footwear\r\n\r\nUnit of Measurement: 1 Pair\r\n\r\nImporter:Bhaane Retail Pvt LtdF-88, Okhla Phase 1, New Delhi 110020, IN\r\nManufacturer:Weilina Vietnam Footwear Co. Ltd Vuc Phac Village, Dinh Lien Commune, Yen Dinh District Thanh Hoa, Vietnam', 6999.00, 'Bring your sport-inspired style to every look with the Pro-Blaze Classic. Tonal leather blends with throwback \'90s details for a classic, easy-to-wear look.\r\nMix of leather, faux leather, and suede for durability\r\nLightweight eva foam helps provide optimal comfort\r\nColors inspired by \'90s sport styles\r\nIconic star chevron', 6, 'casuals', '5', '2024-12-10', 0),
('Converse', 513, 105, 'x TRANSFORMERS CHUCK TAYLOR ALL STAR AUTOBOTS', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : CAMP INDIA PVT LTD\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A11659C\r\n', 6499.00, '•	Autobots, Roll out! Celebrate the 40th anniversary of Transformers with an Optimus Prime edition of classic Chuck Taylor All Star high tops. The limited design features graphics and artwork from the original series, including the Autobots leader and a matching gradient treatment on the upper.\r\nWHY YOU SHOULD BE DOWN\r\no	Limited-edition high tops inspired by Transformers\r\no	Polyester canvas upper with digitally-printed graphics\r\no	Custom printed Chuck Taylor ankle patch and Transformers logo at front tongue\r\no	Energon Axe inspired molded rubber hangtag\r\no	Custom Transformers sock liner graphic\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 514, 105, 'WMNS CHUCK 70 PLUS X-HI', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : Converse India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A10361C\r\n', 8999.00, 'An unexpected update on an all-time classic, the Chuck 70 Plus XHi distorts iconic Chuck Taylor DNA. Bold lines, sliced details, and an extra-high cut keep all eyes on you. Give your favorite looks a punk edge—from the pit to the park, these Chucks come ready to steal the show.', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 515, 105, 'WMNS CHUCK 70 SEASONAL', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : Converse India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A06519C\r\n', 6399.00, 'The Chuck 70 stays true to its iconic elements while brining in fresh design details like a faux leather logo patch and spring-inspired colors that will amp up any outfit.\r\n•	High-top shoe with a canvas upper\r\n•	OrthoLite cushioning helps provide optimal comfort\r\n•	Faux leather Chuck Taylor patch\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 516, 105, 'WMNS CHUCK 70 AT-CX FUTURE COMFORT', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : CAMP INDIA PVT LTD\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A01682C\r\n', 7899.00, '•	Transforming the best ever into a style icon of the future, the Chuck 70 AT-CX delivers elevation like never before. A 50% recycled cotton canvas upper and tongue get a lift from a chunky CX foam midsole and sockliner for recycled, exaggerated comfort. Classic Chuck 70 details like a star ankle patch, aluminum eyelets, and cotton laces keep up the heritage look, while a diamond lugged outsole delivers additional traction.\r\no	High-top sneaker with 50% recycled cotton canvas upper\r\no	TPU Bosey toe for added durability\r\no	CX foam midsole and sockliner for added comfort\r\no	Chuck 70 details like star ankle patch and cotton laces\r\no	Diamond lugged outsole for additional traction\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 517, 105, 'WMNS CHUCK 70 SEASONAL COLOR', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : Converse India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A04592C\r\n', 5499.00, 'Just in time for cooler weather, your favorite Chuck 70 gets refreshed for the season. Fall-ready canvas in lush colors help you add lasting style to your rotation. On shorter days and longer nights, this timeless look is always ready for you to style your way.\r\n•	Low top with canvas upper.\r\n•	OrthoLite cushioning for all-day comfort.\r\n•	On-trend color palette.\r\n•	Durable, cotton laces.\r\n•	Iconic Converse egret midsole.\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 518, 105, 'WMNS RUN STAR LEGACY CX SEASONAL COLOR', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : CAMP INDIA PVT LTD\r\nProduct Dimensions :\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A00873C\r\n', 8999.00, 'The latest iteration of the fan-favorite Run Star Hike, the Run Star Legacy CX mixes bold platform styling with premium comfort. A lightweight CX midsole and sockliner help keep you light on your feet, while distorted Chuck Taylor design elements keep them guessing. A winged tongue and heel bumper allow for easy on and off, so nothing can slow you down.', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 519, 105, 'WMNS RUN STAR HIKE PLATFORM', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : CAMP INDIA PVT LTD\r\nProduct Dimensions :\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A01365C\r\n', 7854.00, 'A chunky platform and jagged rubber sole put an unexpected twist on your everyday Chucks. Details like an organic canvas build, rubber toe cap and Chuck Taylor ankle patch stay true to the original, while a molded platform, two-tone outsole and rounded heel give off futuristic vibes.', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 520, 105, 'WMNS CHUCK TAYLOR ALL STAR MOVE PLATFORM', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : CAMP INDIA PVT LTD\r\nProduct Dimensions :\r\nWeight : 0.95kg\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A01369C\r\n', 9899.00, 'A bold, angular platform brings new energy to classic Chucks without the bulky weight. Made with cotton canvas and finished with new hues, these platforms belong in heavy rotation. Stand tall and stand out.', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 521, 105, 'WMNS CHUCK TAYLOR ALL STAR RAVE', 'Manufacturer : Converse\r\nCountry of Origin : Vietnam\r\nImported By : Converse India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : A00832C\r\n', 3999.00, 'Designed for all-day comfort and versatility, the Chuck Taylor All Star Rave combines timeless design elements with an expressive, wavy forefoot overlay. Light padding at the tongue and collar offer additional support, while an elongated heel and tongue loop help you slide in and out of your sneakers with ease.', 9, 'casuals', '5', '2024-12-10', 0),
('New Balance', 601, 106, 'BB5500', '\r\nManufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : SOLEMATE India Pvt. Ltd.\r\nArticle Code : BB550NCN\r\n\r\n\r\n', 12999.00, 'The original 550 debuted in 1989 and made its mark on basketball courts from coast to coast. After its initial run, the 550 was filed away in the archives, before being reintroduced in limited-edition releases in late 2020, and returned to the full-time lineup in 2021, quickly becoming a global fashion favorite. The 550’s low top, streamlined silhouette offers a clean take on the heavy-duty designs of the late ‘80s, while the dependable leather upper construction is a classic look in any era.\r\n\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('New Balance', 602, 106, '327', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : SOLEMATE India Pvt. Ltd.\r\nArticle Code : MS327DC\r\n', 10999.00, 'New Balance sneakers. Made of suede and synthetic material. The lightweight and comfortable model perfect for everyday wear.\r\n- Soft toe.\r\n- Sturdy heel counter for excellent ankle and heel support.\r\n- Classic lacing allows for a better fit.\r\n- The rubber outsole is durable and damage-resistant.\r\n- A removable, easy-to-clean textile liner.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('New Balance', 603, 106, 'WMS’S 327', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : SOLEMATE India Pvt. Ltd.\r\nArticle Code : WS327FX\r\n', 10999.00, 'New Balance sneakers. Made of suede and synthetic material. The lightweight and comfortable model perfect for everyday wear.\r\n- Soft toe.\r\n- Sturdy heel counter for excellent ankle and heel support.\r\n- Classic lacing allows for a better fit.\r\n- The rubber outsole is durable and damage-resistant.\r\n- A removable, easy-to-clean textile liner.\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('New balance', 604, 106, '530', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : SOLEMATE India Pvt. Ltd.\r\nArticle Code : MR530CP\r\n', 10999.00, 'The 530 is a running classic from the late 1990s, whose career continues today as a retro-style boot for urban wear and as a complement to the best fashion models.\r\nSynthetic additions in the forefoot, instep and heel are responsible for maintaining the shape of the shoe while giving it a characteristic 90s aesthetic.\r\nCushioning and support is provided by the ABZORB sole , and proper ventilation is ensured by the breathable mesh.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('New Balance', 605, 106, 'WMN’S 574', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : SOLEMATE India Pvt. Ltd.\r\nArticle Code : WL574DP2\r\n\r\n', 10999.00, '\"The New Balance shoe of all time\" says it all, doesn\'t it? Not really. The 574 might be our most unlikely icon. The 574 was designed to be a reliable shoe that does lots of different things well, rather than a platform for revolutionary technology or a showcase for premium materials. This understated, unpretentious versatility put the 574 squarely in the ranks of the all-time greats. A hybrid road/trail design built on a wider last than the narrow racing silhouettes of the previous generation, the 574 offered a uniquely versatile blend of new, different, straightforward, tough, durable and comfortable that was adopted as a wardrobe staple around the world. Because of this, the 574 is now synonymous with New Balance\'s limitless style and is worn by everyone', 9, 'casuals', '5', '2024-12-10', 0),
('New balance', 606, 106, '574', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By :SOLEMATE India Pvt. Ltd.\r\nArticle Code : ML574DWW\r\n', 9999.00, 'Crafted in 1988 the New Balance 574 was the first of its kind, the model combined two of New Balance\'s best for an all-new mashup. The Men\'s New Balance 574 Casual Shoes look to continue that rich heritage. This edition adds a tough rubber outsole for durability and traction on any surface.', 6, 'casuals', '5', '2024-12-10', 0),
('New Balance', 608, 106, '574 LEGACY', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : U574LGBP\r\n', 11999.00, '\"The New Balance shoe of all time\" says it all, doesn\'t it? Not really. The 574 might be our most unlikely icon. The 574 was designed to be a reliable shoe that does lots of different things well, rather than a platform for revolutionary technology or a showcase for premium materials. This understated, unpretentious versatility put the 574 squarely in the ranks of the all-time greats. A hybrid road/trail design built on a wider last than the narrow racing silhouettes of the previous generation, the 574 offered a uniquely versatile blend of new, different, straightforward, tough, durable and comfortable that was adopted as a wardrobe staple around the world. Because of this, the 574 is now synonymous with New Balance\'s limitless style and is worn by everyone.', 6, 'casuals', '5', '2024-12-10', 0),
('New balance', 609, 106, 'WMNS BB550', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : BBW550DP\r\n', 12990.00, 'The original 550 debuted in 1989 and made its mark on basketball courts from coast to coast. After its initial run, the 550 was filed away in the archives, before being reintroduced in limited-edition releases in late 2020, and returned to the full-time lineup in 2021, quickly becoming a global fashion favorite. The familiar 550 silhouette is outfitted in premium leather uppers, rendered in monochromatic colorways, for an eye-catching take on a classic look.', 9, 'casuals', '5', '2024-12-10', 0),
('New balance', 610, 106, 'BB550', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : BB550SN1\r\n', 12999.00, 'The original 550 debuted in 1989 and made its mark on basketball courts from coast to coast. After its initial run, the 550 was filed away in the archives, before being reintroduced in limited-edition releases in late 2020, and returned to the full-time lineup in 2021, quickly becoming a global fashion favorite. The 550’s low top, streamlined silhouette offers a clean take on the heavy-duty designs of the late ‘80s, while the dependable leather upper construction is a classic look in any era.', 6, 'casuals', '5', '2024-12-10', 0),
('New balance', 611, 106, '997R', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : U997RRA\r\n\r\n', 11990.00, 'In the 997 model, New Balance has given the popular model a new look. Classic style and innovation come together to create an image that stands out from the crowd. Thanks to the light shock-absorbing ENCAP Reveal sole, your feet will always feel as comfortable as possible', 6, 'casuals', '5', '2024-12-10', 0),
('new balance', 612, 106, '1440', 'Material type:Synthetic\nClosure type:Lace-Up\nHeel type:No Heel\nWater resistance level:Not Water Resistant\nSole material:Rubber\nStyle:Walking\nCountry of Origin:Vietnam\n', 5965.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 613, 106, '574 S', 'Material type: Leather\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: Ethylene Vinyl Acetate\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 6476.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 614, 106, '1080 V13', 'Material type: Polyurethane\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 9919.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 615, 106, 'MORE TR MINDFUL', 'Material type: SYNTEHTIC\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 11899.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 616, 106, '880G', 'Material type: SYNTEHTIC\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 13964.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 617, 106, '997r', 'Material type: LEATHER\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: SWEDE\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 6839.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 618, 106, '327', 'Material type: SuedeMesh\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 7291.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 619, 106, '520', 'Material type: Textile\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 5302.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 620, 106, '430', 'Material type: Mesh\r\nClosure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nSole material: RUBBER\r\nStyle:Walking\r\nCountry of Origin:Vietnam\r\n', 4899.00, 'A versatile blend of premium comfort features and bold design details.', 7, 'sports', '5', '2024-12-10', 0),
('new balance', 622, 106, 'WMNS 997R', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : U997RMB\r\n', 11999.00, 'In the 997 model, New Balance has given the popular model a new look. Classic style and innovation come together to create an image that stands out from the crowd. Thanks to the light shock-absorbing ENCAP Reveal sole, your feet will always feel as comfortable as possible.', 9, 'casuals', '5', '2024-12-10', 0);
INSERT INTO `products` (`Brand_name`, `product_id`, `brand_id`, `model`, `description`, `original_price`, `about`, `category_id`, `type`, `stock`, `arrival_date`, `is_new`) VALUES
('new balance', 623, 106, 'WMNS 9060', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : U9060NRI\r\n', 17999.00, 'The 9060 is a new expression of the refined style and innovation-led design of the classic 99X series. The 9060 reinterprets familiar 99X elements with a warped sensibility inspired by the proudly futuristic, visible tech aesthetic of the Y2K era. Sway bars, taken from the 990, are expanded and utilized throughout the entire upper for a sense of visible motion, while wavy lines and scaled up proportions on a sculpted pod midsole place an exaggerated emphasis on the familiar cushioning platforms of ABZORB and SBS.', 9, 'casuals', '5', '2024-12-10', 0),
('new balance', 624, 106, 'WMNS 550', 'manufacturer : Brandman Retail Pvt. Ltd.\r\ncountry_of_origin : Vietnam\r\nimported_by : Brandman Retail Pvt. Ltd.\r\nproduct_dimensions :\r\nweight : 0.95 KG\r\ngeneric_name : SHOE\r\nunit_of_measurement : 1 Pair\r\nmarketed_by : Superkicks India Pvt. Ltd.\r\narticle_code : BBW550PB\r\n', 9499.00, 'The original 550 debuted in 1989 and made its mark on basketball courts from coast to coast. After its initial run, the 550 was filed away in the archives, before being reintroduced in limited-edition releases in late 2020, and returned to the full-time lineup in 2021, quickly becoming a global fashion favorite. The 550’s low top, streamlined silhouette offers a clean take on the heavy-duty designs of the late ‘80s, while the dependable suede and leather upper construction is a classic look in any era.', 9, 'casuals', '5', '2024-12-10', 0),
('new balance', 625, 106, 'WMNS BB550', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : BBW550DP\r\n', 12999.00, 'The original 550 debuted in 1989 and made its mark on basketball courts from coast to coast. After its initial run, the 550 was filed away in the archives, before being reintroduced in limited-edition releases in late 2020, and returned to the full-time lineup in 2021, quickly becoming a global fashion favorite. The familiar 550 silhouette is outfitted in premium leather uppers, rendered in monochromatic colorways, for an eye-catching take on a classic look', 9, 'casuals', '5', '2024-12-10', 0),
('new balance', 626, 106, 'WMNS 327', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : U327LL\r\n', 10999.00, 'New Balance sneakers. Made of suede and synthetic material. The lightweight and comfortable model perfect for everyday wear.\r\n- Soft toe.\r\n- Sturdy heel counter for excellent ankle and heel support.\r\n- Classic lacing allows for a better fit.\r\n- The rubber outsole is durable and damage-resistant.\r\n- A removable, easy-to-clean textile liner.\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('new balance', 627, 106, 'WMNS 574 OLIVE', 'Manufacturer : New Balance\r\nCountry of Origin : Vietnam\r\nImported By : New Balance Indida Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : SHOE\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : WL574DP2\r\n', 10999.00, '\"The New Balance shoe of all time\" says it all, does not it? Not really. The 574 might be our most unlikely icon. The 574 was designed to be a reliable shoe that does lots of different things well, rather than a platform for revolutionary technology or a showcase for premium materials. This understated, unpretentious versatility put the 574 squarely in the ranks of the all-time greats. A hybrid road/trail design built on a wider last than the narrow racing silhouettes of the previous generation, the 574 offered a uniquely versatile blend of new, different, straightforward, tough, durable and comfortable that was adopted as a wardrobe staple around the world. Because of this, the 574 is now synonymous with  limitless of New Balance style and is worn by everyone.', 9, 'casuals', '5', '2024-12-10', 0),
('Reebok', 701, 107, 'CLUB C REVENGE VINTAGE', 'Manufacturer : Reebok\r\nCountry of Origin : China\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100074206\r\n', 8999.00, 'CLUB C REVENGE VINTAGE SNEAKERS\r\nARCHIVE-INSPIRED SHOES MADE OF VINTAGE-STYLE LEATHER\r\nA blast from the past. Inspired by heritage tennis shoes, these sneakers are made in vintage-style leather for an old-school look. The contrast heel tab and side stripes complement the retro stylings.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 702, 107, 'BB 4000 II', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 1.10KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100072116\r\n', 9999.00, 'Designed for basketball and ready to hit the streets, these Reebok high-top sneakers provide that familiar look with an original touch. Subtle suede details complete the leather upper so you can pair them with your favorite basketball jersey or a pair of jeans.', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 703, 107, 'CLASSIC LEATHER', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100034258\r\n', 9999.00, 'Created in 1983, the Classic Leather is a Reebok icon, being one of the most popular silhouettes in the sneaker world. With its minimalist and elegant design, these sneakers have quickly become a fashion reference. The highlight of the Classic Leather Hemp is the upper entirely made from hemp, a sustainable, soft and super resistant material. Additionally, the lace-up closure provides a comfortable fit, while the textile lining ensures a cozy interior. Featuring a full rubber outsole, these sneakers offer reliable traction on a variety of surfaces, making them perfect for casual wear. Classic Leather Hemp not only combines style and versatility, but also embraces sustainability, making it a conscious choice for your everyday life. Experience Reebok comfort, durability and classic design with the Classic Leather Hemp.', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 704, 107, 'CLASSIC NYLON PLUS', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : ID1517\r\n', 7205.00, 'Sneakers from the Reebok collection are made of a combination of genuine leather, suede and textile material. Lightweight and comfortable, ideal for everyday wear.', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 705, 107, 'QUESTION MID', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : HR104\r\n', 12999.00, 'ALLEN IVERSON S SIGNATURE SHOES GET A FRESH COLOUR UPDATE\r\nWhen Allen Iverson had the ball in his hands, he kept his defenders guessing which way he d go next. He also kept everyone wondering what colour shoes rock during the game. These Reebok signature sneakers channel those memories with an orange glow-up on the toe and heel for a fresh look\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 706, 107, 'LT COURT', 'Manufacturer : Reebok\r\nCountry of Origin : China\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100033085\r\n', 13999.00, 'Crisp, sleek and quintessentially Reebok: theres no match for the LT Court. Rooted in tennis styles, the low-top design features a light-grey upper detailed with quilted panels, suede trims and logo stamps', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 708, 107, 'CLASSIC LEARHER HEXALITE +', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IG0718\r\n', 9599.00, 'Inspired by Reebok court shoes from the late 80s, these kicks have a retro look and a luxe feel thanks to delicate details on the upper. A net-shaped piece on the sidewall nods to tennis while giving it a look you can rock anywhere.', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 709, 107, 'PANINI QUESTION MID', 'manufacturer : Reebok India Pvt. Ltd.\r\ncountry_of_origin : Vietnam\r\nimported_by : Reebok India Pvt. Ltd.\r\nproduct_dimensions :\r\nweight : 0.95 KG\r\ngeneric_name : SHOE\r\nunit_of_measurement : 1 Pair\r\nmarketed_by : Superkicks India Pvt. Ltd.\r\narticle_code : HQ1097\r\n', 15999.00, 'ALLEN IVERSON SHOES THAT NOD TO ONE OF THE RAREST PANINI TRADING CARDS\r\nEvery dedicated collector dreams of pulling a sought-after card from a pack. These Reebok x Panini shoes honour Allen Iversons rookie season and one of the rarest parallels — the Tiger Prizm. The iridescent tiger stripe overlays add a luxe touch worthy of an MVP.\r\n', 6, 'casuals', '5', '2024-12-10', 0),
('Reebok', 710, 107, 'EAMES CLASSIC LEATHER', 'manufacturer : Reebok India Pvt. Ltd.\r\ncountry_of_origin : Vietnam\r\nimported_by : Reebok India Pvt. Ltd.\r\nproduct_dimensions :\r\nweight : 0.95 KG\r\ngeneric_name : SHOE\r\nunit_of_measurement : 1 Pair\r\nmarketed_by : Superkicks India Pvt. Ltd.\r\narticle_code : FZ5861\r\n', 12999.00, 'OLD-SCHOOL REEBOK SHOES DESIGNED IN COLLABORATION WITH EAMES\r\nMid-century aesthetic meets retro 80s Reebok style. The legendary designers who started Eames inspired the look of these Classic Leather shoes. The clean trainers get a bump ', 6, 'casuals', '5', '2024-12-10', 0),
('Converse', 711, 107, 'WMNS CLASSIC LEATHER', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\n', 7599.00, 'Reebok Mens Shoes Classic Leather is a shoe with a classic and stylish design. The leather material used on the upper part increases the durability of the shoe while maintaining its elegance. The textile lining on the inside of the shoe keeps the feet comfortable and prevents sweating. EVA technology in the midsole increases the comfort of the shoe while walking. The outsole of the shoe is made of rubber material and has anti-slip properties.Reebok Mens Shoes Classic Leather can be easily preferred while doing sports or for daily use. The lace-up design of the shoe ensures a tight fixation of the feet and prevents unwanted slipping. The quality and assurance of the Reebok brand is an indication that the shoes will have a long life. Reebok Mens Shoes Classic Leather is an ideal option for those who want to reflect their style and take a comfortable step.', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 712, 107, 'WMNS CLUB C 85', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 1.10 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100074237\r\n', 6599.00, 'Smooth is how you roll. Now, you have the kicks to match. Slip on these Classic Club C 85 sneakers and hit the scene. A simple style means these supple leather shoes pair up with anything. Because sometimes you dont have to say anything to make a statement.', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 713, 107, 'WMNS CL NYLON', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : IE2321\r\n', 6205.00, '•	Nylon and suede upper\r\n•	Padded foam insole\r\n•	Sleek, slim shape for a more feminine look and feel\r\n•	EVA midsole for shock absorption\r\n•	Rubber outsole for traction and grip\r\n•	The Reebok Classic Nylon Slim is imported.\r\nResurrect your commitment to the classics with the Womens Reebok Classic Nylon Slim Casual Shoes. Retro style and premium modern comfort collide in these sneakers, ensuring you feel good every step of the way.\r\n', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 714, 107, 'WMNS F/S HI CLASSICS', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 1.10KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : GV7041\r\n', 7805.00, 'F/S Hi - Vintage Pastels:Purple Oasis & Aura Orange Are Used To Ensure These Colorways Remain Wearable And Feminine. F/S Hi - Vintage Pastels:Softer, Pastel Color Bomb Execution.', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 715, 107, 'WMNS CLUB C GEO MID', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : GV7038\r\n', 11055.00, 'Club C Double Geo - Midsole/Outsole: Geometric Design Incorporated Into The Traditional Club C Double Midsole Club C Double Geo - Midsole/Outsole: Thicker Tread To Exaggerate The Outsole, Club C Geo Mid - Sun Washed:\"Shades Of\" Approach With The Lighter Upper Color And Slightly Darker Color For The Logos, Club C Geo Mid - Sun Washed: All Over Suede Upper To Incorporate A Soft, Worn-In Feel, Club C Geo Mid - Sun Washed: Lighter Gum Outsoles To Help Give A More Spring Vibe To This Pack, Club C Geo Mid - Upper: Slim Collar Construction To Flatter And Provide Maximum Style Versatility, Club C Geo Mid - Upper: Subtle Outdoor Design Details Brought Into The Upper Design With Mudguard, Piping, And Webbing Accent, Club C Geo Mid - Upper: Trend Right, Mid-Cut Silhouette With ', 9, 'casuals', '5', '2024-12-10', 0),
('Converse', 716, 107, 'WMNS CLASSIC LEATHER SP EXTRA', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : Shoe\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : HQ7187\r\n', 8505.00, 'Inspired by outdoor murals at rec centers, these womens Reebok shoes add subtle neon details to liven up your look. They have a custom sockliner full of colorful, asymmetrical lines to represent the artistry of local communities.', 9, 'casuals', '5', '2024-12-10', 0),
('Reebok', 717, 107, 'TRUE COURT', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nStyle:Mule\r\nOuter material:Canvas\r\nCountry of Origin:India\r\n', 5999.00, 'True court shoe is Designed for indoor Games • The non marking rubber outsole provide the necessary grip and stabi l ity for indoor sports • This shoe constructed with Synthetic PU Overlay that promote better support and stability ,While mesh give comfort and brethability and durability ', 7, 'Sports', '5', '2024-12-10', 0),
('Reebok', 718, 107, 'Craze Runner M Vectornavy Smokyindi ', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nStyle:Mule\r\nOuter material:Canvas\r\nCountry of Origin:India\r\n', 4599.00, 'Light Weight Air Mesh With Recycled Fibers Which Have Extremely Breathable Properties And Softness To The Touch , Superior Moisture Absorption And High Durability. Designer Eyestay With Super Quality Cord Laces .Full Vamp Is Covered With Fusible Pu Film Which Makes The Product Extremely Durable. And Helps In Multidirectional Movement.Molded Memorytech Sockliner Adds Durable Support For All-Day Comfort.Sole- The Injected Eva Midsole Is Lightweight And Provides Superior Cushioning, While The Rubber Outsole Will Ensure Firm Grip, Maximum Traction And Agility. Camouflage Effect In Rubber Outsole Makes The Product Much More Elegant & Attractive', 7, 'Sports', '5', '2024-12-10', 0),
('Reebok', 719, 107, 'COURTFLEX M White', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nStyle:Mule\r\nOuter material:Canvas\r\nCountry of Origin:India\r\n', 8999.00, 'Rule the court with Reebok Court sports shoes. Built for precision and control, these shoes offer the grip and support you need for your best game.', 7, 'Sports', '5', '2024-12-10', 0),
('Reebok', 720, 107, 'Rmsora1640 ', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nStyle:Mule\r\nOuter material:Canvas\r\nCountry of Origin:India\r\n', 6773.00, 'Rule the court with Reebok Court sports shoes. Built for precision and control, these shoes offer the grip and support you need for your best game.', 7, 'Sports', '5', '2024-12-10', 0),
('Reebok', 721, 107, 'MAINLAND M', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nStyle:Mule\r\nOuter material:Canvas\r\nCountry of Origin:India\r\n', 4599.00, 'A perfect combination of Mesh + PU & Film. Dual tone Mesh for enhaced & rich look. QTR Caging concept for better gripping & PU at Heel for great durabilty. Midsole made of softer EVA compound. Rubber Pods in Outsole gives better traction while running.', 7, 'Sports', '5', '2024-12-10', 0),
('Reebok', 722, 107, 'Zig Elusion Energy', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nStyle:Mule\r\nOuter material:Canvas\r\nCountry of Origin:India\r\n', 9999.00, 'FloatrideFuel: FloatrideFuel is an elevated foam platform that provides an energy return, high-rebound cushioning experience • Zig Energy Plate: The Zig Energy Plate is a heel to toe TPU shank that acts as a cup at the heel to provide lateral support and stability while providing acceleration and propulsion at the forefoot • Mesh Upper: provides breathability and comfort•.', 7, 'Sports', '5', '2024-12-10', 0),
('Reebok', 723, 107, 'Liquifect 90 ', 'Closure type:Lace-Up\r\nHeel type:No Heel\r\nWater resistance level:Not Water Resistant\r\nStyle:Mule\r\nOuter material:Canvas\r\nCountry of Origin:India\r\n', 7999.00, 'FloatrideFuel: FloatrideFuel is an elevated foam platform that provides an energy return, high-rebound cushioning experience • Zig Energy Plate: The Zig Energy Plate is a heel to toe TPU shank that acts as a cup at the heel to provide lateral support and stability while providing acceleration and propulsion at the forefoot • Mesh Upper: provides breathability and comfort•.', 7, 'Sports', '5', '2024-12-10', 0),
('Reebok', 724, 107, 'CLASSICS BEATNIK', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : sandal\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100034261\r\n', 8255.00, 'Reebok was founded in Bolton, England in 1958, by brothers Jeff and Joe Foster as a spin-off from their familys company, J.W. Foster and Sons. The brand quickly gained popularity with its innovative running spikes, and later, with the release of the Reebok Freestyle, a womens athletic shoe designed for aerobics, in 1982. The Freestyle, along with products like the Reebok Classic and the Instapump Fury, demonstrate Reeboks commitment to fitness and lifestyle. Over the years, Reebok has collaborated with various celebrities, such as Jay-Z and Cardi B, and high-profile fashion brands, like Vetements and Palace, solidifying its position at the intersection of sportswear, lifestyle, and pop culture.', 7, 'slides', '5', '2024-12-10', 0),
('Reebok', 725, 107, 'RBK Fulgere', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : sandal\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100034261\r\n', 2566.00, 'Reebok was founded in Bolton, England in 1958, by brothers Jeff and Joe Foster as a spin-off from their familys company, J.W. Foster and Sons. The brand quickly gained popularity with its innovative running spikes, and later, with the release of the Reebok Freestyle, a womens athletic shoe designed for aerobics, in 1982. The Freestyle, along with products like the Reebok Classic and the Instapump Fury, demonstrate Reeboks commitment to fitness and lifestyle. Over the years, Reebok has collaborated with various celebrities, such as Jay-Z and Cardi B, and high-profile fashion brands, like Vetements and Palace, solidifying its position at the intersection of sportswear, lifestyle, and pop culture.', 7, 'slides', '5', '2024-12-10', 0),
('Reebok', 726, 107, 'Rise Slide U Open', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : sandal\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100034261\r\n', 1599.00, 'Reebok was founded in Bolton, England in 1958, by brothers Jeff and Joe Foster as a spin-off from their familys company, J.W. Foster and Sons. The brand quickly gained popularity with its innovative running spikes, and later, with the release of the Reebok Freestyle, a womens athletic shoe designed for aerobics, in 1982. The Freestyle, along with products like the Reebok Classic and the Instapump Fury, demonstrate Reeboks commitment to fitness and lifestyle. Over the years, Reebok has collaborated with various celebrities, such as Jay-Z and Cardi B, and high-profile fashion brands, like Vetements and Palace, solidifying its position at the intersection of sportswear, lifestyle, and pop culture.', 7, 'slides', '5', '2024-12-10', 0),
('Reebok', 727, 107, 'Softnetic', 'Manufacturer : Reebok\r\nCountry of Origin : Vietnam\r\nImported By : Reebok India Pvt. Ltd.\r\nWeight : 0.95 KG\r\nGeneric Name : sandal\r\nUnit of Measurement : 1 Pair\r\nMarketed By : Superkicks India Pvt. Ltd.\r\nArticle Code : 100034261\r\n', 1899.00, 'Reebok was founded in Bolton, England in 1958, by brothers Jeff and Joe Foster as a spin-off from their familys company, J.W. Foster and Sons. The brand quickly gained popularity with its innovative running spikes, and later, with the release of the Reebok Freestyle, a womens athletic shoe designed for aerobics, in 1982. The Freestyle, along with products like the Reebok Classic and the Instapump Fury, demonstrate Reeboks commitment to fitness and lifestyle. Over the years, Reebok has collaborated with various celebrities, such as Jay-Z and Cardi B, and high-profile fashion brands, like Vetements and Palace, solidifying its position at the intersection of sportswear, lifestyle, and pop culture.', 7, 'slides', '5', '2024-12-10', 0),
('Nike', 735, 101, 'Travis Scott X Air Jordan 1 Low Mocha', '', 0.00, '', 6, 'Casuals ', 'In-Stock', '2024-12-16', 1),
('Adidas', 736, 104, 'adiFOM Q sneakers', '', 0.00, '', 6, 'Casuals ', 'In-Stock', '2024-12-16', 1),
('Nike', 737, 101, 'x Dior Air Jordan 1 Retro High sneakers', '', 0.00, '', 6, 'Casuals ', 'In-Stock', '2024-12-16', 1),
('Nike', 738, 101, 'Nike Alphafly 3 Premiums', '', 0.00, '', 6, 'Casuals ', 'In-Stock', '2024-12-16', 1),
('Nike', 739, 101, 'SB Dunk Low \"What The P-Rod\" sneakers', '', 0.00, '', 6, 'Casuals ', 'In-Stock', '2024-12-16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shopping-session`
--

CREATE TABLE `shopping-session` (
  `id` int(11) NOT NULL,
  `user-id` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `created-at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified-at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(8) NOT NULL,
  `first-name` varchar(30) NOT NULL,
  `last-name` varchar(20) NOT NULL,
  `phone-no` varchar(15) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `created-at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified-at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first-name`, `last-name`, `phone-no`, `email`, `address`, `password`, `created-at`, `modified-at`) VALUES
(12, 'anisha', 'kumari', '9523003682', 'anishakri03@gmail.com', 'manpur', '$2y$10$d6csRrxTvB.r.S9iN6yyX.SHl1bFsH6zED9R26nAA4zc2NN6flC7S', '2024-10-22 06:56:17', '2024-10-22 06:56:17');

-- --------------------------------------------------------

--
-- Table structure for table `user_address`
--

CREATE TABLE `user_address` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address_line  1` varchar(50) NOT NULL,
  `address_line 2` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `country` varchar(30) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `mobile` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin-user`
--
ALTER TABLE `admin-user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart_item`
--
ALTER TABLE `cart_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payment-details`
--
ALTER TABLE `payment-details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order-id` (`order-id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `product category`
--
ALTER TABLE `product category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productimages`
--
ALTER TABLE `productimages`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product inventory`
--
ALTER TABLE `product inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `shopping-session`
--
ALTER TABLE `shopping-session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user-id` (`user-id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `phone-no` (`phone-no`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone-no_2` (`phone-no`);

--
-- Indexes for table `user_address`
--
ALTER TABLE `user_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin-user`
--
ALTER TABLE `admin-user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `cart_item`
--
ALTER TABLE `cart_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payment-details`
--
ALTER TABLE `payment-details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `product category`
--
ALTER TABLE `product category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `productimages`
--
ALTER TABLE `productimages`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=981;

--
-- AUTO_INCREMENT for table `product inventory`
--
ALTER TABLE `product inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=740;

--
-- AUTO_INCREMENT for table `shopping-session`
--
ALTER TABLE `shopping-session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user_address`
--
ALTER TABLE `user_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_item`
--
ALTER TABLE `cart_item`
  ADD CONSTRAINT `cart_item_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `cart_item_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `payment-details`
--
ALTER TABLE `payment-details`
  ADD CONSTRAINT `payment-details_ibfk_1` FOREIGN KEY (`order-id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `productimages`
--
ALTER TABLE `productimages`
  ADD CONSTRAINT `productimages_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brand` (`brand_id`) ON DELETE CASCADE;

--
-- Constraints for table `shopping-session`
--
ALTER TABLE `shopping-session`
  ADD CONSTRAINT `shopping-session_ibfk_1` FOREIGN KEY (`user-id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
